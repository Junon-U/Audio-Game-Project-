extends Node2D
## An enemy robot. Walks from its gate towards the player. Uses an optional
## Kenney sprite if one was found, otherwise a drawn robot. Facing: +x.

var sprite: Sprite2D
var variant := 0
var bob := 0.0
var radius := 34.0
var tint := Color(1, 1, 1)


func setup(tex: Texture2D, size_px: float, p_variant: int, p_radius: float) -> void:
	variant = p_variant
	radius = p_radius
	if tex != null:
		sprite = Sprite2D.new()
		sprite.texture = tex
		sprite.scale = Vector2.ONE * size_px / float(max(tex.get_width(), tex.get_height()))
		add_child(sprite)


func face(target: Vector2) -> void:
	rotation = (target - global_position).angle()


func _process(delta: float) -> void:
	bob += delta * 9.0
	if sprite:
		sprite.position.y = sin(bob) * 1.5
	queue_redraw()


func _draw() -> void:
	if sprite != null:
		return
	var body := Color(0.55, 0.57, 0.60) if variant == 0 else Color(0.62, 0.50, 0.42)
	var dark := Color(0.18, 0.18, 0.20)
	var s := sin(bob)
	# treads / feet
	draw_rect(Rect2(-22 + s * 3, -30, 26, 10), dark)
	draw_rect(Rect2(-22 - s * 3, 20, 26, 10), dark)
	# body
	var pts := PackedVector2Array()
	for k in 6:
		var a := TAU * k / 6.0 + PI / 6.0
		pts.append(Vector2(cos(a), sin(a)) * 27.0)
	draw_colored_polygon(pts, body)
	pts.append(pts[0])
	draw_polyline(pts, dark, 3.0)
	# arms
	draw_rect(Rect2(8, -26, 22, 8), body.darkened(0.25))
	draw_rect(Rect2(8, 18, 22, 8), body.darkened(0.25))
	# visor and eye
	draw_rect(Rect2(6, -10, 14, 20), dark)
	draw_circle(Vector2(14, 0), 6.0, Color(1.0, 0.25, 0.2))
	draw_circle(Vector2(14, 0), 11.0, Color(1.0, 0.25, 0.2, 0.25))
