extends Node2D
## Motion tracker around the player: a faint ring (always the same) and a
## blip, a short glowing arc and a dot pointing at one gate. The blip's alpha
## sets the visibility level. The ring follows the player.

var radius := 130.0
var blip := 22.0
var dir := Vector2.UP
var alpha := 0.9


func show_blip(p_dir: Vector2, p_alpha: float) -> void:
	dir = p_dir
	alpha = p_alpha
	visible = true
	queue_redraw()


func _draw() -> void:
	draw_arc(Vector2.ZERO, radius, 0, TAU, 96, Color(0.25, 0.55, 0.45, 0.2), 2.0)
	var c := Color(0.35, 1.0, 0.7)
	var a0 := dir.angle()
	var span := deg_to_rad(28.0)
	draw_arc(Vector2.ZERO, radius, a0 - span, a0 + span, 24, Color(c.r, c.g, c.b, alpha), 6.0)
	var p := dir * radius
	draw_circle(p, blip * 0.9, Color(c.r, c.g, c.b, alpha * 0.25))
	draw_circle(p, blip * 0.45, Color(c.r, c.g, c.b, alpha))
