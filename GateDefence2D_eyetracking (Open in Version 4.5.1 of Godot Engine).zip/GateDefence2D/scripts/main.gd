extends Node2D
## Gate Defence: experiment controller (top-down 2D wave shooter).
##
## The player defends a deck with three gates (left, ahead, right). Every robot
## is one trial. Before it appears, two imperfect sources of evidence:
##   sound   a robot banging twice on a gate (valid / invalid / silent;
##           reliability set per level), 200 to 250 ms before the robot appears
##   vision  a motion tracker blip pointing at one gate (valid on
##           sensor_reliability of trials), clear or faded (screen brightness matched)
## Robots come in waves of 6; 6 waves make a level (one reliability epoch).
##
## Play is continuous: there is no dark screen or "get ready" phase between
## robots. Trial timeline ([timing] in config/experiment.cfg):
##   the previous robot is destroyed (or hits the shield) -> feedback -> the
##   tracker blip moves to the next robot's gate -> random gap -> sound onset
##   -> 200-250 ms -> the door opens and the robot walks in -> ...
## Optional ([movement] enabled=true): in live mode the player can walk (W A S D) within the inner deck. Each bang
## is played from the direction of its gate as seen from where the player
## stands at that moment (pre-rendered every 5 degrees).
## Each level ends with a Swarm bonus wave: several robots at once, each with
## its own bang (same reliability as the level), no tracker. Swarm robots are
## not trials; they are logged to *_swarm.csv and as events.
## The player can aim (and fire) at any time; shots before the sound are logged.
##
## Modes:
##   live          aim with the mouse, fire with the left button or SPACE
##   replay        press LEFT / UP / RIGHT (or A / W / D) to fire at that gate
##   localization  sounds only; press the direction they came from
##
## Command-line options (after "--"):
##   --autotest[-mode=replay|localization]  short simulated session, then quit
##   --autotest-pid=<ID>                    ID for the autotest
##   --make-schedule=<ID>                   write schedules/<ID>.csv and quit
##   --shots                                save screenshots to data/screenshots

const Schedule := preload("res://scripts/schedule.gd")
const DataLogger := preload("res://scripts/data_logger.gd")
const Arena := preload("res://scripts/arena.gd")
const Player := preload("res://scripts/player.gd")
const Robot := preload("res://scripts/robot.gd")
const Tracker := preload("res://scripts/tracker.gd")

const REF := Vector2(1920, 1080)
const GATE_NAMES := ["left", "ahead", "right"]
const GATE_DIRS := [Vector2.LEFT, Vector2.UP, Vector2.RIGHT]

var cfg := ConfigFile.new()
var logger: DataLogger
var rng := RandomNumberGenerator.new()

var centre := Vector2(960, 540)
var arena: Node2D
var player: Node2D
var tracker: Node2D
var fx: Node2D
var robot: Node2D
var crosshair: Node2D

var optional_files := {}     # lower-case file name -> res:// path
var found_assets: Array = []
var player_tex: Texture2D
var robot_texs: Array[Texture2D] = []

var cue_streams: Array[AudioStream] = []     # the three gates heard from the centre (localization test)
var dir_streams := {}                         # direction (deg, clockwise from up) -> AudioStream
var dir_step := 5.0
var cue_player: AudioStreamPlayer
var cue_pool: Array[AudioStreamPlayer] = []
var cue_pool_index := 0
var tracker_gate := -1
var amb_player: AudioStreamPlayer
var sfx_players: Array[AudioStreamPlayer] = []
var sfx_index := 0
var fb_player: AudioStreamPlayer
var sounds := {}

# UI
var ui: CanvasLayer
var blackout: ColorRect
var message: Label
var banner: Label
var hint: Label
var hud: Label
var hud_right: Label
var shield_bar: Control
var menu: Control
var pid_edit: LineEdit
var mode_select: OptionButton
var fullscreen_check: CheckBox
var menu_info: Label
var stage_title: Label
var stage_sub: Label
var stage_hint: Label
var val_target: Control
var rating_ui: Control
var rating_q: Label
var rating_fill: ColorRect
var rating_value: Label
var rating_left: Label
var rating_right: Label
var rating_hint: Label
var choice_label: Label
var text_edit: LineEdit

# Session state
var pid := ""
var mode := "live"
var stage_label := ""
var wave_label := ""
var time_scale := 1.0
var autotest := false
var aborting := false
var escape_presses := 0
var pause_requested := false
var score := 0
var streak := 0
var shield := 5
var kills_in_wave := 0
# Reliability estimate from the proposal: (a0 + previous valid cues) /
# (a0 + b0 + previous audio trials); silent trials do not update it.
var n_audio_prev := 0
var n_valid_prev := 0
# Aim (live mode): mouse position in reference pixels, aim angle.
var mouse_ref := Vector2(960, 700)
var aim_angle := PI / 2.0            # Godot radians; PI/2 = pointing down
var aim_locked := true
var warp_frames := 0
var mouse_was_down := false
var free_aim := false          # aim follows the mouse (live mode, during trials)
var last_free_shot_us := 0
var banner_token := 0
var config_source := ""
var last_robot_us := 0        # when the previous robot appeared (0 = none, e.g. after a break)
var moved_in_trial := 0.0


# ================================================================ setup

func _ready() -> void:
	# Settings: config/experiment.cfg next to the .exe (exported game) if it
	# exists, so it can be edited without re-exporting; otherwise the copy
	# packed into the game.
	var ext := OS.get_executable_path().get_base_dir().path_join("config/experiment.cfg")
	if not OS.has_feature("editor") and FileAccess.file_exists(ext) and cfg.load(ext) == OK:
		config_source = ext
	elif cfg.load("res://config/experiment.cfg") == OK:
		config_source = "res://config/experiment.cfg"
	else:
		config_source = "built-in defaults (config/experiment.cfg NOT FOUND)"
		push_warning("config/experiment.cfg not found; using defaults")
	centre = Vector2(_a("centre_x", 960.0), _a("centre_y", 540.0))
	_scan_optional(_optional_root())
	_setup_input()
	_build_world()
	_build_audio()
	_build_ui()

	var args := OS.get_cmdline_user_args()
	for a in args:
		if a.begins_with("--make-schedule="):
			_make_schedule_file(a.get_slice("=", 1))
			return
	if "--shots" in args:
		_take_screenshots()
		return
	for a in args:
		if a == "--autotest":
			autotest = true
		elif a.begins_with("--autotest-mode="):
			autotest = true
			mode = a.get_slice("=", 1)
	if autotest:
		time_scale = 0.1
		cfg.set_value("design", "trials_per_epoch", 12)
		cfg.set_value("design", "practice_trials", 3)
		cfg.set_value("design", "localization_reps", 2)
		pid = "AUTOTEST"
		for a in args:
			if a.begins_with("--autotest-pid="):
				pid = a.get_slice("=", 1)
		menu.visible = false
		_run_session()
	else:
		_show_menu()


func _a(key: String, default_value: float) -> float:
	return float(cfg.get_value("arena", key, default_value))


func _t(key: String, default_value: float) -> float:
	return float(cfg.get_value("timing", key, default_value))


func _optional_root() -> String:
	return "res://assets/optional"


## Indexes every file under assets/optional by its lower-case name, so the
## Kenney packs can be unzipped there with their own folder structure.
func _scan_optional(path: String) -> void:
	var d := DirAccess.open(path)
	if d == null:
		return
	d.list_dir_begin()
	var f := d.get_next()
	while f != "":
		if d.current_is_dir():
			if not f.begins_with("."):
				_scan_optional(path.path_join(f))
		else:
			var name := f.trim_suffix(".import").trim_suffix(".remap")
			var key := name.to_lower()
			if not optional_files.has(key):
				optional_files[key] = path.path_join(name)
		f = d.get_next()
	d.list_dir_end()


## Loads an optional file by exact name, or else the first file (sorted by
## name) whose name contains every keyword and has one of the extensions.
func _optional(file_name: String, keywords: Array = [], exts: Array = []) -> Resource:
	var key := file_name.to_lower()
	if not key.is_empty() and optional_files.has(key) and ResourceLoader.exists(optional_files[key]):
		found_assets.append(optional_files[key])
		return load(optional_files[key])
	if keywords.is_empty():
		return null
	var names := optional_files.keys()
	names.sort()
	for n in names:
		if not exts.is_empty() and not (n.get_extension() in exts):
			continue
		var ok := true
		for k in keywords:
			if not n.contains(k):
				ok = false
				break
		if ok and ResourceLoader.exists(optional_files[n]):
			found_assets.append(optional_files[n])
			return load(optional_files[n])
	return null


func _setup_input() -> void:
	var keys := {
		"gate_left": [KEY_A, KEY_LEFT], "gate_ahead": [KEY_W, KEY_UP], "gate_right": [KEY_D, KEY_RIGHT],
		"move_down": [KEY_S, KEY_DOWN],
		"walk_left": [KEY_A], "walk_right": [KEY_D], "walk_up": [KEY_W], "walk_down": [KEY_S],
		"fire": [KEY_SPACE], "continue": [KEY_SPACE, KEY_ENTER, KEY_KP_ENTER], "abort": [KEY_ESCAPE],
		"pause": [KEY_P], "validate": [KEY_V],
	}
	for action in keys:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for k in keys[action]:
			var ev := InputEventKey.new()
			ev.physical_keycode = k
			InputMap.action_add_event(action, ev)


func _build_world() -> void:
	arena = Arena.new()
	arena.setup(centre, _a("half_size_px", 440.0), _a("wall_px", 40.0), _a("gate_width_px", 190.0), _a("tracker_radius_px", 130.0))
	add_child(arena)

	tracker = Tracker.new()
	tracker.position = centre
	tracker.radius = _a("tracker_radius_px", 130.0)
	tracker.blip = _a("tracker_blip_px", 22.0)
	tracker.visible = false
	add_child(tracker)

	player_tex = _optional(str(cfg.get_value("assets", "player_sprite", "")), ["survivor", "gun"], ["png"]) as Texture2D
	for f in cfg.get_value("assets", "robot_sprites", []):
		var t := _optional(str(f)) as Texture2D
		if t:
			robot_texs.append(t)
	if robot_texs.is_empty():
		var t := _optional("", ["robot", "hold"], ["png"]) as Texture2D
		if t:
			robot_texs.append(t)

	fx = Node2D.new()
	add_child(fx)

	player = Player.new()
	player.position = centre
	player.shield_r = _a("breach_distance_px", 80.0)
	player.set_texture(player_tex, 64.0)
	add_child(player)

	crosshair = Node2D.new()
	crosshair.visible = false
	crosshair.draw.connect(func():
		var col := Color(0.6, 1.0, 1.0, 0.85)
		crosshair.draw_arc(Vector2.ZERO, 14.0, 0, TAU, 32, col, 2.0)
		for v in [Vector2.UP, Vector2.DOWN, Vector2.LEFT, Vector2.RIGHT]:
			crosshair.draw_line(v * 8.0, v * 20.0, col, 2.0))
	add_child(crosshair)


func _process(_delta: float) -> void:
	if free_aim and mode == "live" and not autotest:
		_read_mouse()
		var v := mouse_ref - player.position
		if v.length() >= float(cfg.get_value("controls", "first_aim_threshold_px", 40.0)):
			aim_angle = v.angle()
		crosshair.position = mouse_ref
	if player:
		player.set_aim(aim_angle)
		if tracker.visible:
			tracker.position = player.position
			if tracker_gate >= 0:
				tracker.dir = (door_point(tracker_gate) - player.position).normalized()
				tracker.queue_redraw()


func _load(path: String) -> AudioStream:
	if ResourceLoader.exists(path):
		return load(path)
	push_warning("Missing audio file: %s (run tools/make_stimuli.py)" % path)
	return null


func _sound(optional_key: String, keyword: String, fallback: String) -> AudioStream:
	var s := _optional(str(cfg.get_value("assets", optional_key, "")), [keyword], ["ogg", "wav"]) as AudioStream
	return s if s != null else _load(fallback)


func _build_audio() -> void:
	for e in 3:
		cue_streams.append(_load("res://audio/stimuli/cue_%02d.wav" % e))
	var deg := 0
	while deg < 360:
		var path := "res://audio/stimuli/dir/cue_dir_%03d.wav" % deg
		if ResourceLoader.exists(path):
			dir_streams[deg] = load(path)
		deg += int(dir_step)
	if dir_streams.size() < int(360.0 / dir_step):
		push_warning("Direction cues missing in audio/stimuli/dir (run tools/make_stimuli.py)")
	sounds["laser"] = _sound("laser_sound", "lasersmall", "res://audio/sfx/laser.wav")
	sounds["explosion"] = _sound("explosion_sound", "explosion", "res://audio/sfx/explosion.wav")
	sounds["shield"] = _load("res://audio/sfx/shield.wav")
	sounds["spark"] = _load("res://assets/kenney_audio/impactMetal_light_002.ogg")
	sounds["success"] = _load("res://assets/kenney_audio/confirmation_001.ogg")
	sounds["fail"] = _load("res://assets/kenney_audio/error_004.ogg")
	sounds["stage"] = _load("res://assets/kenney_audio/maximize_006.ogg")
	sounds["wave"] = _load("res://assets/kenney_audio/select_002.ogg")
	cue_player = _player("cue_volume_db", 0.0)
	for j in 6:
		cue_pool.append(_player("cue_volume_db", 0.0))
	for k in 4:
		sfx_players.append(_player("sfx_volume_db", -10.0))
	fb_player = _player("feedback_volume_db", -12.0)
	amb_player = _player("ambience_volume_db", -28.0)
	amb_player.stream = _load("res://audio/ambience_loop.wav")
	amb_player.finished.connect(amb_player.play)


func _player(key: String, default_db: float) -> AudioStreamPlayer:
	var p := AudioStreamPlayer.new()
	p.volume_db = float(cfg.get_value("audio", key, default_db))
	add_child(p)
	return p


## Effects are mono and centred, so they never carry a direction.
func _sfx(name: String) -> void:
	var s: AudioStream = sounds.get(name)
	if s == null:
		return
	var p := sfx_players[sfx_index]
	sfx_index = (sfx_index + 1) % sfx_players.size()
	p.stream = s
	p.play()


func _build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)
	blackout = ColorRect.new()
	blackout.color = Color.BLACK
	blackout.set_anchors_preset(Control.PRESET_FULL_RECT)
	blackout.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(blackout)

	message = _label("", 30, Vector4(0.12, 0.05, 0.88, 0.95))
	message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	banner = _label("", 32, Vector4(0, 0, 1, 0))
	banner.offset_top = 1024
	banner.offset_bottom = 1076
	hint = _label("", 24, Vector4(0, 1, 1, 1))
	hint.offset_top = -60
	hint.offset_bottom = -16
	# HUD panels left and right of the arena (outside the play area).
	hud = _label("", 30, Vector4(0, 0, 0, 0))
	hud.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	hud.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	hud.offset_left = 40
	hud.offset_top = 40
	hud.offset_right = 440
	hud.offset_bottom = 400
	hud_right = _label("", 30, Vector4(0, 0, 0, 0))
	hud_right.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	hud_right.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	hud_right.offset_left = 1480
	hud_right.offset_top = 40
	hud_right.offset_right = 1880
	hud_right.offset_bottom = 400
	shield_bar = Control.new()
	shield_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	shield_bar.position = Vector2(1880, 170)
	shield_bar.draw.connect(func():
		var smax := int(cfg.get_value("waves", "shield_max", 5))
		for k in smax:
			var r := Rect2(Vector2(-(smax - k) * 40.0, 0), Vector2(30, 22))
			if k < shield:
				shield_bar.draw_rect(r, Color(0.4, 0.85, 1.0))
			shield_bar.draw_rect(r, Color(0.7, 0.9, 1.0), false, 2.0))
	ui.add_child(shield_bar)
	_build_extra_ui()
	stage_title = _label("", 78, Vector4(0, 0.26, 1, 0.42))
	stage_sub = _label("", 36, Vector4(0, 0.42, 1, 0.52))
	stage_hint = _label("", 24, Vector4(0, 0.62, 1, 0.74))
	stage_title.add_theme_color_override("font_color", Color(0.55, 1.0, 0.85))
	for l in [stage_title, stage_sub, stage_hint]:
		l.visible = false
	for l in [banner, hint, hud, hud_right]:
		l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
		l.add_theme_constant_override("outline_size", 8)

	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	ui.add_child(center)
	menu = center
	var panel := PanelContainer.new()
	center.add_child(panel)
	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	panel.add_child(margin)
	var box := VBoxContainer.new()
	box.custom_minimum_size = Vector2(600, 0)
	box.add_theme_constant_override("separation", 14)
	margin.add_child(box)
	var title := Label.new()
	title.text = "Gate Defence - experimenter setup"
	title.add_theme_font_size_override("font_size", 26)
	box.add_child(title)
	pid_edit = LineEdit.new()
	pid_edit.placeholder_text = "Participant ID (e.g. P001)"
	box.add_child(pid_edit)
	# The reliability condition is not shown here (participants may see this
	# screen). It is saved in *_session.json and in every trial row.
	mode_select = OptionButton.new()
	mode_select.add_item("Live play (mouse + W A S D)" if bool(cfg.get_value("movement", "enabled", false)) else "Live play (mouse)")
	mode_select.add_item("Replay (keys)")
	mode_select.add_item("Localization test")
	box.add_child(mode_select)
	fullscreen_check = CheckBox.new()
	fullscreen_check.text = "Fullscreen"
	fullscreen_check.button_pressed = true
	box.add_child(fullscreen_check)
	var start := Button.new()
	start.text = "Start"
	start.pressed.connect(_on_start_pressed)
	box.add_child(start)
	menu_info = Label.new()
	menu_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	menu_info.custom_minimum_size = Vector2(600, 0)
	menu_info.add_theme_font_size_override("font_size", 14)
	var art := ("optional files in use: " + ", ".join(found_assets.map(func(x): return str(x).get_file()))) if not found_assets.is_empty() else "built-in drawings and sounds (no optional Kenney files found)"
	menu_info.text = "Data folder: %s\nSettings: %s\nSchedules: schedules/<ID>.csv is used if present, otherwise one is generated from the ID.\nArt and effects: %s" % [DataLogger.resolve_data_dir(), config_source, art]
	box.add_child(menu_info)


## Screens for ratings, multiple-choice questions, free text and gaze validation.
## Coordinates are in the 1920x1080 reference frame.
func _build_extra_ui() -> void:
	rating_ui = Control.new()
	rating_ui.set_anchors_preset(Control.PRESET_FULL_RECT)
	rating_ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rating_ui.visible = false
	ui.add_child(rating_ui)
	rating_q = Label.new()
	rating_q.add_theme_font_size_override("font_size", 34)
	rating_q.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	rating_q.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rating_q.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
	rating_q.position = Vector2(260, 160)
	rating_q.size = Vector2(1400, 260)
	rating_ui.add_child(rating_q)
	var bar := ColorRect.new()
	bar.color = Color(0.25, 0.25, 0.25)
	bar.position = Vector2(460, 560)
	bar.size = Vector2(1000, 36)
	bar.name = "bar"
	rating_ui.add_child(bar)
	rating_fill = ColorRect.new()
	rating_fill.color = Color(0.45, 0.95, 0.75)
	rating_fill.position = Vector2(460, 560)
	rating_fill.size = Vector2(500, 36)
	rating_ui.add_child(rating_fill)
	rating_value = Label.new()
	rating_value.add_theme_font_size_override("font_size", 48)
	rating_value.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rating_value.position = Vector2(760, 470)
	rating_value.size = Vector2(400, 70)
	rating_ui.add_child(rating_value)
	rating_left = Label.new()
	rating_left.add_theme_font_size_override("font_size", 24)
	rating_left.position = Vector2(460, 610)
	rating_left.size = Vector2(480, 80)
	rating_left.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	rating_ui.add_child(rating_left)
	rating_right = Label.new()
	rating_right.add_theme_font_size_override("font_size", 24)
	rating_right.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	rating_right.position = Vector2(980, 610)
	rating_right.size = Vector2(480, 80)
	rating_right.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	rating_ui.add_child(rating_right)
	choice_label = Label.new()
	choice_label.add_theme_font_size_override("font_size", 32)
	choice_label.position = Vector2(700, 470)
	choice_label.size = Vector2(1000, 380)
	rating_ui.add_child(choice_label)
	text_edit = LineEdit.new()
	text_edit.position = Vector2(360, 520)
	text_edit.size = Vector2(1200, 60)
	text_edit.add_theme_font_size_override("font_size", 28)
	text_edit.placeholder_text = "Type here (optional), then press ENTER"
	rating_ui.add_child(text_edit)
	rating_hint = Label.new()
	rating_hint.add_theme_font_size_override("font_size", 24)
	rating_hint.modulate = Color(1, 1, 1, 0.6)
	rating_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rating_hint.position = Vector2(260, 900)
	rating_hint.size = Vector2(1400, 60)
	rating_ui.add_child(rating_hint)

	val_target = Control.new()
	val_target.mouse_filter = Control.MOUSE_FILTER_IGNORE
	val_target.visible = false
	val_target.draw.connect(func():
		val_target.draw_circle(Vector2.ZERO, 18, Color.WHITE)
		val_target.draw_circle(Vector2.ZERO, 4, Color.BLACK))
	ui.add_child(val_target)


func _label(text: String, size: int, anchors: Vector4) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(l)
	l.anchor_left = anchors.x
	l.anchor_top = anchors.y
	l.anchor_right = anchors.z
	l.anchor_bottom = anchors.w
	l.offset_left = 0
	l.offset_top = 0
	l.offset_right = 0
	l.offset_bottom = 0
	return l


func _show_menu() -> void:
	blackout.visible = true
	menu.visible = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	pid_edit.grab_focus()


func _on_start_pressed() -> void:
	pid = pid_edit.text.strip_edges()
	if pid.is_empty():
		menu_info.text = "Please enter a participant ID."
		return
	mode = ["live", "replay", "localization"][mode_select.selected]
	if fullscreen_check.button_pressed:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	menu.visible = false
	_run_session()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause") and not menu.visible and logger != null:
		pause_requested = true
		hint.text = "Pausing after this robot..."
	if event.is_action_pressed("abort") and not menu.visible:
		escape_presses += 1
		hint.text = "Aborting after this robot..." if escape_presses >= 2 else "Press ESC again to abort the session."
		aborting = escape_presses >= 2


# ================================================================ helpers

func _ms(ms: float) -> float:
	return ms / 1000.0 * time_scale


func _wait(ms: float) -> void:
	if ms > 0.0:
		await get_tree().create_timer(_ms(ms)).timeout


func _wait_continue(text: String) -> void:
	blackout.visible = true
	message.text = text + "\n\n[Press SPACE to continue]"
	message.visible = true
	if autotest:
		await _wait(300)
	else:
		await get_tree().process_frame
		while not Input.is_action_just_pressed("continue"):
			await get_tree().process_frame
	message.visible = false


func _play(p: AudioStreamPlayer, s: AudioStream) -> void:
	if s != null:
		p.stream = s
		p.play()


func gate_point(g: int, dist: float) -> Vector2:
	return centre + GATE_DIRS[g] * dist


## Middle of gate g's doorway.
func door_point(g: int) -> Vector2:
	return gate_point(g, _a("half_size_px", 440.0) + _a("wall_px", 40.0) * 0.5)


## Direction of gate g from a position, degrees clockwise from straight up.
func gate_dir_deg(g: int, from: Vector2) -> float:
	return _cw_deg((door_point(g) - from).angle())


## Plays the bang of gate g as heard from the player's current position.
## Returns the rendered direction (degrees) that was played.
func _play_cue(g: int) -> float:
	var ang := gate_dir_deg(g, player.position)
	var k := int(fposmod(round(ang / dir_step) * dir_step, 360.0))
	var s: AudioStream = dir_streams.get(k)
	if s == null and player.position.distance_to(centre) < 1.0:
		s = cue_streams[g]
	if s != null:
		var p := cue_pool[cue_pool_index]
		cue_pool_index = (cue_pool_index + 1) % cue_pool.size()
		p.stream = s
		p.play()
	return float(k)


## Gate the aim points at from a position: the gate whose doorway is closest
## in angle, if within 60 degrees; -1 otherwise (e.g. at the bottom wall).
func _gate_of_aim(from: Vector2, angle_rad: float) -> int:
	var best := -1
	var bd := deg_to_rad(60.0)
	for g in 3:
		var d: float = abs(angle_difference(angle_rad, (door_point(g) - from).angle()))
		if d < bd:
			bd = d
			best = g
	return best


## Live mode: walk with W A S D. In the measured waves the player stays within
## [movement] trial_radius_px of the centre; in the swarm, anywhere on the deck.
## Returns the distance moved this frame.
func _move_player(swarm_mode: bool) -> float:
	if mode != "live" or not bool(cfg.get_value("movement", "enabled", false)):
		return 0.0
	var dir := Vector2.ZERO
	if autotest:
		dir = Vector2.from_angle(Time.get_ticks_msec() / 300.0)
	else:
		dir = Input.get_vector("walk_left", "walk_right", "walk_up", "walk_down")
	if dir.length() < 0.1:
		return 0.0
	var dt := get_process_delta_time() / time_scale
	var speed := float(cfg.get_value("movement", "speed_px_s", 380.0))
	var before: Vector2 = player.position
	var np := before + dir.normalized() * speed * dt
	if swarm_mode:
		var h := _a("half_size_px", 440.0) - 60.0
		np.x = clamp(np.x, centre.x - h, centre.x + h)
		np.y = clamp(np.y, centre.y - h, centre.y + h)
	else:
		var r := float(cfg.get_value("movement", "trial_radius_px", 240.0))
		var off := np - centre
		if off.length() > r:
			np = centre + off.normalized() * r
	player.position = np
	return before.distance_to(np)


## Angle in degrees, clockwise from straight up (screen), of a Godot angle.
static func _cw_deg(angle_rad: float) -> float:
	return fposmod(rad_to_deg(angle_rad) + 90.0, 360.0)


## Gate whose sector contains an aim angle; -1 for the bottom (no gate).
## Sectors are 90 degrees wide around each gate direction.
static func _gate_of_angle(angle_rad: float) -> int:
	var cw := _cw_deg(angle_rad)
	if cw >= 315.0 or cw < 45.0:
		return 1
	if cw >= 45.0 and cw < 135.0:
		return 2
	if cw >= 225.0 and cw < 315.0:
		return 0
	return -1


func _key_gate() -> int:
	if Input.is_action_just_pressed("gate_left"):
		return 0
	if Input.is_action_just_pressed("gate_ahead"):
		return 1
	if Input.is_action_just_pressed("gate_right"):
		return 2
	return -1


func _clear_fx() -> void:
	for c in fx.get_children():
		c.queue_free()
	if robot != null:
		robot.queue_free()
		robot = null


func _streak_mult() -> int:
	var steps: Array = cfg.get_value("score", "streak_steps", [3, 6, 10])
	var m := 1
	for s in steps:
		if streak >= int(s):
			m += 1
	return m


func _update_hud() -> void:
	var lines: PackedStringArray = []
	if bool(cfg.get_value("stages", "show_in_hud", true)) and not stage_label.is_empty():
		lines.append(stage_label)
	if not wave_label.is_empty():
		lines.append(wave_label)
	hud.text = "\n".join(lines)
	var mult := _streak_mult()
	hud_right.text = "Score  %d\n%s\nShield" % [score, ("Streak x%d" % mult) if mult > 1 else " "]
	shield_bar.queue_redraw()


# ================================================================ effects

func _laser(from: Vector2, to: Vector2) -> void:
	var l := Line2D.new()
	l.points = PackedVector2Array([from, to])
	l.width = 5.0
	l.default_color = Color(0.55, 1.0, 1.0, 0.95)
	fx.add_child(l)
	var core := Line2D.new()
	core.points = l.points
	core.width = 2.0
	core.default_color = Color(1, 1, 1)
	fx.add_child(core)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(l, "modulate:a", 0.0, _ms(90))
	tw.tween_property(core, "modulate:a", 0.0, _ms(90))
	tw.chain().tween_callback(func():
		l.queue_free()
		core.queue_free())


func _burst(pos: Vector2, color: Color, amount: int, speed: float, life_ms: float) -> void:
	var p := CPUParticles2D.new()
	p.position = pos
	p.one_shot = true
	p.explosiveness = 1.0
	p.amount = amount
	p.lifetime = _ms(life_ms)
	p.spread = 180.0
	p.initial_velocity_min = speed * 0.4
	p.initial_velocity_max = speed
	p.gravity = Vector2.ZERO
	p.damping_min = speed * 0.8
	p.damping_max = speed * 1.2
	p.scale_amount_min = 3.0
	p.scale_amount_max = 6.0
	p.color = color
	var ramp := Gradient.new()
	ramp.set_color(0, Color(1, 1, 1, 1))
	ramp.set_color(1, Color(1, 1, 1, 0))
	p.color_ramp = ramp
	fx.add_child(p)
	p.emitting = true
	get_tree().create_timer(_ms(life_ms) + 0.2).timeout.connect(p.queue_free)


func _explosion(pos: Vector2) -> void:
	var flash := Node2D.new()
	flash.position = pos
	flash.draw.connect(func():
		flash.draw_circle(Vector2.ZERO, 46.0, Color(1.0, 0.75, 0.3, 0.7))
		flash.draw_circle(Vector2.ZERO, 26.0, Color(1.0, 0.95, 0.8, 0.9)))
	fx.add_child(flash)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(flash, "scale", Vector2.ONE * 1.6, _ms(220))
	tw.tween_property(flash, "modulate:a", 0.0, _ms(220))
	_burst(pos, Color(1.0, 0.6, 0.2), 36, 420.0, 450)
	_burst(pos, Color(0.6, 0.62, 0.66), 14, 220.0, 600)


func _popup(pos: Vector2, text: String, color: Color) -> void:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 34)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	l.add_theme_constant_override("outline_size", 8)
	l.position = pos + Vector2(-60, -70)
	l.size = Vector2(120, 40)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	fx.add_child(l)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(l, "position:y", l.position.y - 40, _ms(500))
	tw.tween_property(l, "modulate:a", 0.0, _ms(500)).set_delay(_ms(200))


## Where a shot from the centre at this angle hits the arena boundary (walls or doors).
func _boundary_point(angle_rad: float, origin: Vector2 = Vector2.INF) -> Vector2:
	if origin == Vector2.INF:
		origin = centre
	var d := Vector2.from_angle(angle_rad)
	var h := _a("half_size_px", 440.0)
	var o := origin - centre
	var t := INF
	if abs(d.x) > 1e-6:
		t = min(t, ((h if d.x > 0 else -h) - o.x) / d.x)
	if abs(d.y) > 1e-6:
		t = min(t, ((h if d.y > 0 else -h) - o.y) / d.y)
	return origin + d * max(t, 0.0)


# ================================================================ session

func _run_session() -> void:
	logger = DataLogger.new()
	logger.open(pid, mode, cfg)
	rng.seed = hash(pid + mode)
	Input.mouse_mode = Input.MOUSE_MODE_CONFINED_HIDDEN if not autotest else Input.MOUSE_MODE_VISIBLE
	mouse_ref = centre + Vector2(0, 150)
	if not autotest:
		get_viewport().warp_mouse(mouse_ref)
		warp_frames = 3
	_play(amb_player, amb_player.stream)

	var rows: Array
	if mode == "localization":
		rows = Schedule.new().generate_localization(pid, cfg)
	else:
		rows = Schedule.load_csv(_schedule_dir().path_join(pid + ".csv"))
		if rows.is_empty():
			rows = Schedule.new().generate(pid, cfg)
	Schedule.save_csv(rows, logger.path_of("_schedule.csv"))
	# Let the fullscreen switch settle so the logged window size is the real one.
	await get_tree().process_frame
	await get_tree().process_frame
	_write_session_meta(rows.size())
	logger.event("session_start", -1, {"mode": mode, "n_trials": rows.size()})
	if not autotest:
		logger.eyetracker("c", cfg)

	if mode == "localization":
		await _run_localization(rows)
	else:
		await _run_main(rows)
		if bool(cfg.get_value("validation", "at_end", false)):
			await _run_validation("end")
		if bool(cfg.get_value("questionnaire", "enabled", true)):
			await _questionnaire()

	logger.event("session_end", -1, {"aborted": aborting, "score": score})
	if not autotest:
		logger.eyetracker("s", cfg)
	logger.close()
	amb_player.stop()
	if autotest:
		print("AUTOTEST finished: ", logger.path_of("_trials.csv"))
		get_tree().quit()
		return
	await _wait_continue("The session is complete. Thank you!\n\nFinal score: %d\n\nData saved to:\n%s" % [score, logger.data_dir])
	get_tree().quit()


func _schedule_dir() -> String:
	if OS.has_feature("editor"):
		return ProjectSettings.globalize_path("res://schedules")
	return OS.get_executable_path().get_base_dir().path_join("schedules")


func _make_schedule_file(sid: String) -> void:
	DirAccess.make_dir_recursive_absolute(_schedule_dir())
	var path := _schedule_dir().path_join(sid + ".csv")
	Schedule.save_csv(Schedule.new().generate(sid, cfg), path)
	print("Schedule written: ", path)
	get_tree().quit()


func _write_session_meta(n_rows: int) -> void:
	var win := Vector2(get_window().size)
	var scale_f: float = min(win.x / REF.x, win.y / REF.y)
	var gates := []
	var aoi := _a("gate_aoi_distance_px", 440.0)
	var tr := _a("tracker_radius_px", 130.0)
	for e in 3:
		var p := gate_point(e, aoi)
		var s := gate_point(e, tr)
		gates.append({"gate": e, "name": GATE_NAMES[e], "aoi_x": p.x, "aoi_y": p.y, "sensor_x": s.x, "sensor_y": s.y})
	var cfg_dump := {}
	for section in cfg.get_sections():
		var s := {}
		for key in cfg.get_section_keys(section):
			s[key] = cfg.get_value(section, key)
		cfg_dump[section] = s
	logger.write_json("_session.json", {
		"pid": pid, "mode": mode, "n_rows": n_rows, "autotest": autotest,
		"reliability_assignment": Schedule.assign_reliability(pid, cfg),
		"started": Time.get_datetime_string_from_system(),
		"godot_version": Engine.get_version_info()["string"],
		"reference_frame_px": [REF.x, REF.y],
		"window_px": [win.x, win.y],
		"screen_px": [DisplayServer.screen_get_size().x, DisplayServer.screen_get_size().y],
		"fullscreen": DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_FULLSCREEN,
		"reference_to_window_scale": scale_f,
		"reference_to_window_offset_px": [(win.x - REF.x * scale_f) / 2.0, (win.y - REF.y * scale_f) / 2.0],
		"screen_refresh_hz": DisplayServer.screen_get_refresh_rate(),
		"audio_output_latency_s": AudioServer.get_output_latency(),
		"audio_mix_rate": AudioServer.get_mix_rate(),
		"centre_px": [centre.x, centre.y],
		"gate_codes": {"0": "left", "1": "ahead", "2": "right", "-1": "none"},
		"gates": gates,
		"optional_assets_used": found_assets,
		"config_source": config_source,
		"exported_build": not OS.has_feature("editor"),
		"config": cfg_dump,
	})


func _instructions() -> String:
	var how := (("Move with  W A S D.  " if bool(cfg.get_value("movement", "enabled", false)) else "")
			+ "Aim with the MOUSE and fire with the LEFT BUTTON (or SPACE)."
			if mode == "live" else
			"Press  LEFT,  UP  or  RIGHT  (or A, W, D) to fire at that gate. Press again to fire again.")
	return ("You are guarding the deck of a space station.\n\n"
		+ "Robots break in through the three gates: left, ahead and right. Each robot bangs on its gate "
		+ "just before the door opens. Sound carries strangely on the station, so the bang may sometimes "
		+ "seem to come from the wrong gate, and sometimes there is no bang at all.\n"
		+ "Your motion tracker (the ring around you) also points to a gate. It is usually, but not always, "
		+ "right, and sometimes its signal is weak and hard to see.\n\n"
		+ how + "\nThe robot appears just after its bang. "
		+ "Destroy each robot before it reaches your shield. Robots come in waves, "
		+ "and each level ends with a swarm of robots at once.\n\n"
		+ "Between robots, keep your eyes on yourself.")


func _run_main(rows: Array) -> void:
	await _run_validation("start")
	await _wait_continue(_instructions())
	score = 0
	streak = 0
	shield = int(cfg.get_value("waves", "shield_max", 5))
	n_audio_prev = 0
	n_valid_prev = 0
	# Split the schedule into blocks (practice, level 1, level 2, ...).
	var blocks: Array = []
	for row in rows:
		if blocks.is_empty() or blocks[-1][0]["block"] != row["block"]:
			blocks.append([])
		blocks[-1].append(row)
	var g := 0
	for bi in blocks.size():
		if aborting:
			break
		var b: Array = blocks[bi]
		var epoch := int(b[0]["epoch"])
		var rel := float(b[0]["reliability"])
		logger.event("block_start", g + 1, {"block": b[0]["block"], "reliability": rel})
		if epoch > 0:
			await _stage_card(epoch, g + 1)
		else:
			stage_label = "Practice"
		_hud_visible(true)
		g = await _play_block(b, g)
		logger.event("block_end", g, {"block": b[0]["block"]})
		if epoch > 0 and not aborting:
			await _run_swarm(epoch, g, rel)
		_hud_visible(false)
		if epoch > 0 and not aborting:
			await _level_ratings(epoch, rel)
		if bi + 1 < blocks.size() and not aborting:
			await _wait_continue("Practice complete. The real defence starts now." if epoch == 0 else "Take a short rest.")
			if epoch > 0:
				if bool(cfg.get_value("validation", "after_each_level", false)):
					await _run_validation("rest_after_level_%d" % epoch)
	_hud_visible(false)


func _hud_visible(v: bool) -> void:
	hud.visible = v
	hud_right.visible = v
	shield_bar.visible = v
	free_aim = v and mode == "live"
	crosshair.visible = v and mode == "live" and not autotest
	if v:
		blackout.visible = false


## Shows a message at the bottom of the screen for a while, without pausing play.
func _flash_banner(text: String, ms: float) -> void:
	banner_token += 1
	var tok := banner_token
	banner.text = text
	get_tree().create_timer(_ms(ms)).timeout.connect(func():
		if banner_token == tok:
			banner.text = "")


func _waves_in_block(row: Dictionary) -> int:
	if int(row["epoch"]) == 0:
		return 1
	var n := int(cfg.get_value("design", "trials_per_epoch", 36))
	var w := int(cfg.get_value("design", "trials_per_wave", 6))
	return int(ceil(float(n) / float(w)))


func _wave_start(row: Dictionary, g: int) -> void:
	kills_in_wave = 0
	var smax := int(cfg.get_value("waves", "shield_max", 5))
	if shield <= 0:
		shield = smax
	else:
		shield = min(smax, shield + int(cfg.get_value("waves", "recharge_per_wave", 2)))
	wave_label = "Wave %d / %d" % [int(row["wave"]), _waves_in_block(row)] if int(row["epoch"]) > 0 else "Training wave"
	_update_hud()
	logger.event("wave_start", g, {"block": row["block"], "wave": row["wave"], "shield": shield})


## "Wave cleared" message at the bottom of the screen. Play does not pause.
func _wave_card(row: Dictionary, g: int, kills: int = -1) -> void:
	if kills >= 0:
		kills_in_wave = kills
	logger.event("wave_end", g, {"block": row["block"], "wave": row["wave"], "kills": kills_in_wave, "score": score})
	if not bool(cfg.get_value("waves", "announce", true)) or int(row["epoch"]) == 0:
		return
	_flash_banner("Wave %d:  %d of %d robots destroyed" % [int(row["wave"]), kills_in_wave, int(row["trial_in_wave"])],
			float(cfg.get_value("waves", "card_ms", 1400)))
	_play(fb_player, sounds["wave"])


func _counts_for_estimate(row: Dictionary) -> bool:
	return int(row["epoch"]) > 0 or bool(cfg.get_value("estimate", "include_practice", false))


## Adds the proposal's reliability estimate (state before this trial) to the row.
func _add_estimate(row: Dictionary) -> void:
	var cue: int = row["cue_gate"]
	var sg: int = row["sensor_gate"]
	row["cue_valid"] = "" if cue < 0 else (1 if cue == int(row["correct_gate"]) else 0)
	row["cue_sensor"] = "no_cue" if cue < 0 else ("agree" if cue == sg else "conflict")
	if not _counts_for_estimate(row):
		row["n_audio_prev"] = ""
		row["n_valid_prev"] = ""
		row["r_hat"] = ""
		return
	var a0 := float(cfg.get_value("estimate", "alpha0", 1.0))
	var b0 := float(cfg.get_value("estimate", "beta0", 1.0))
	row["n_audio_prev"] = n_audio_prev
	row["n_valid_prev"] = n_valid_prev
	row["r_hat"] = snappedf((a0 + n_valid_prev) / (a0 + b0 + n_audio_prev), 0.0001)


func _update_estimate(row: Dictionary) -> void:
	if _counts_for_estimate(row) and int(row["cue_gate"]) >= 0:
		n_audio_prev += 1
		if int(row["cue_gate"]) == int(row["correct_gate"]):
			n_valid_prev += 1


func _stage_title(epoch: int) -> String:
	var titles: Array = cfg.get_value("stages", "titles", [])
	return titles[epoch - 1] if epoch - 1 < titles.size() else ""


## Title card shown when a new level (reliability epoch) begins.
func _stage_card(epoch: int, g: int) -> void:
	stage_label = "Level %d  %s" % [epoch, _stage_title(epoch)]
	_update_hud()
	if not bool(cfg.get_value("stages", "announce", true)):
		return
	_hud_visible(false)
	blackout.visible = true
	stage_title.text = "Level %d" % epoch
	stage_sub.text = _stage_title(epoch)
	stage_hint.text = "Score so far: %d" % score
	for l in [stage_title, stage_sub, stage_hint]:
		l.visible = true
		l.modulate.a = 0.0
		create_tween().tween_property(l, "modulate:a", 1.0, _ms(500))
	_play(fb_player, sounds["stage"])
	if logger:
		logger.event("stage_card", g, {"epoch": epoch, "title": stage_sub.text})
	await _wait(float(cfg.get_value("stages", "card_min_ms", 1500)))
	if autotest:
		await _wait(200)
	else:
		stage_hint.text = "Score so far: %d\n\n[Press SPACE to continue]" % score
		await get_tree().process_frame
		while not Input.is_action_just_pressed("continue"):
			await get_tree().process_frame
	for l in [stage_title, stage_sub, stage_hint]:
		l.visible = false
		l.modulate.a = 1.0


# ================================================================ trial

func _reset_scene() -> void:
	_clear_fx()
	arena.close_all()
	tracker.visible = false
	aim_angle = PI / 2.0
	aim_locked = true
	crosshair.visible = false


func _now_ms() -> float:
	return Time.get_ticks_usec() / 1000.0 / time_scale


func _read_mouse() -> void:
	var m := get_global_mouse_position()
	if warp_frames > 0:
		warp_frames -= 1
		if m.distance_to(mouse_ref) > 4.0:
			return
		warp_frames = 0
	mouse_ref = m


func _fire_pressed() -> bool:
	var down := Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)
	var click := down and not mouse_was_down
	mouse_was_down = down
	return click or Input.is_action_just_pressed("fire")


## Sets blip, bang and robot times for robots from index `from` on, starting
## at t_start (experiment ms). Robot k appears robot_interval_ms after robot
## k-1; its bang comes soa before that; its tracker blip appears when robot
## k-1 appears (the first one at t_start, followed by a random gap).
func _schedule(T: Array, from: int, t_start: float) -> void:
	var interval := _t("robot_interval_ms", 1200)
	var first_gap := rng.randf_range(_t("gap_min_ms", 600), _t("gap_max_ms", 1000))
	var onset0: float = t_start + first_gap + T[from]["soa"]
	for k in range(from, T.size()):
		var on: float = onset0 + (k - from) * interval
		T[k]["onset"] = on
		T[k]["bang"] = on - T[k]["soa"]
		T[k]["blip"] = t_start if k == from else T[k - 1]["onset"]


func _alive(T: Array, except: int = -1) -> int:
	var c := 0
	for k in T.size():
		if k != except and T[k]["phase"] == 3:
			c += 1
	return c


## Plays one block (practice or a level) at a fixed beat: robot k appears
## robot_interval_ms after robot k-1, whether or not earlier robots are still
## on screen. Each robot is one trial row, written when that robot is
## destroyed or reaches the shield. Returns the last trial number.
func _play_block(block_rows: Array, g0: int) -> int:
	var n := block_rows.size()
	var emerge_d := _a("emerge_distance_px", 470.0)
	var breach_d := _a("breach_distance_px", 80.0)
	var rr := _a("robot_radius_px", 34.0)
	var tol := deg_to_rad(_a("hit_tolerance_deg", 3.0))
	var speed := (emerge_d - breach_d) / _t("robot_walk_ms", 1500)    # px per experiment ms
	var cooldown := float(cfg.get_value("controls", "fire_cooldown_ms", 180))
	var aim_thresh := float(cfg.get_value("controls", "first_aim_threshold_px", 40.0))
	var aoi := _a("gate_aoi_distance_px", 440.0)
	var live := mode == "live"
	_clear_fx()
	arena.close_all()
	last_robot_us = 0
	# phase: 0 waiting, 1 blip shown, 2 bang played, 3 robot on screen, 4 done
	var T: Array = []
	for k in n:
		var row: Dictionary = block_rows[k]
		var cue: int = row["cue_gate"]
		var auto_gate: int = cue if (cue >= 0 and rng.randf() < 0.7) else rng.randi_range(0, 2)
		T.append({"row": row, "g": g0 + k + 1, "phase": 0, "node": null, "res": {}, "shots": 0, "early": 0,
				"soa": rng.randf_range(_t("soa_min_ms", 300), _t("soa_max_ms", 300)),
				"t_blip": 0.0, "t_cue_us": 0, "t_emerge_us": 0, "auto_gate": auto_gate,
				"auto_react": rng.randf_range(150, 400), "auto_skip": rng.randf() < 0.05})
	_schedule(T, 0, _now_ms())
	var next := 0
	var done := 0
	var last_shot := -1.0e9
	var auto_next := 0.0
	var wave_kills := {}
	mouse_was_down = Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)
	while done < n:
		await get_tree().process_frame
		var now := _now_ms()
		var now_us := Time.get_ticks_usec()
		var dt := get_process_delta_time() / time_scale * 1000.0

		# Pause or abort: stop starting new robots; act once the screen is clear.
		var holding := pause_requested or aborting
		if holding and done == next:
			if aborting:
				break
			tracker.visible = false
			await _pause_screen(T[next - 1]["g"] if next > 0 else g0)
			_hud_visible(true)
			last_robot_us = 0
			_schedule(T, next, _now_ms())
			continue

		# 1. Tracker blip for the next robot.
		if next < n and not holding and now >= T[next]["blip"]:
			var st: Dictionary = T[next]
			var row: Dictionary = st["row"]
			var sg: int = row["sensor_gate"]
			if int(row["trial_in_wave"]) == 1:
				_wave_start(row, st["g"])
				wave_kills[int(row["wave"])] = 0
			var res: Dictionary = row.duplicate()
			res["pid"] = pid
			res["mode"] = mode
			res["trial_global"] = st["g"]
			var correct: int = row["correct_gate"]
			var cue: int = row["cue_gate"]
			res["correct_x"] = gate_point(correct, aoi).x
			res["correct_y"] = gate_point(correct, aoi).y
			res["cue_x"] = gate_point(cue, aoi).x if cue >= 0 else ""
			res["cue_y"] = gate_point(cue, aoi).y if cue >= 0 else ""
			var alpha := float(cfg.get_value("visibility", str(row["visibility"]) + "_sensor_alpha", 0.9))
			tracker_gate = sg
			tracker.position = player.position
			tracker.show_blip((door_point(sg) - player.position).normalized(), alpha)
			var sp: Vector2 = player.position + tracker.dir * _a("tracker_radius_px", 130.0)
			res["sensor_x"] = snappedf(sp.x, 0.1)
			res["sensor_y"] = snappedf(sp.y, 0.1)
			for f in ["first_aim_ms", "first_aim_angle_deg", "first_aim_gate", "first_aim_to_sound", "first_aim_to_target",
					"first_aim_to_sensor", "aim_gate_at_emerge", "choice_gate", "choice_device", "first_shot_ms",
					"first_shot_before_emerge", "kill_ms", "kill_after_emerge_ms", "kill_x", "kill_y",
					"t_emerge_us", "t_first_shot_us", "t_kill_us", "robot_interval_ms"]:
				res[f] = ""
			res["choice_gate"] = -1
			res["killed"] = 0
			res["breach"] = 0
			res["moved_px"] = 0.0
			res["t_scene_us"] = logger.event("scene_on", st["g"], {"visibility": row["visibility"], "sensor_gate": sg})
			st["res"] = res
			st["t_blip"] = now
			st["phase"] = 1
			next += 1

		# 2. Bangs.
		for st in T:
			if st["phase"] == 1 and now >= st["bang"]:
				var row: Dictionary = st["row"]
				var res: Dictionary = st["res"]
				var cue: int = row["cue_gate"]
				_add_estimate(row)
				for f in ["cue_valid", "cue_sensor", "n_audio_prev", "n_valid_prev", "r_hat"]:
					res[f] = row[f]
				res["player_x_cue"] = snappedf(player.position.x, 0.1)
				res["player_y_cue"] = snappedf(player.position.y, 0.1)
				res["cue_dir_deg"] = _play_cue(cue) if cue >= 0 else ""
				res["t_cue_us"] = logger.event("cue_on", st["g"], {"audio_cond": row["audio_cond"], "cue_gate": cue, "cue_dir_deg": res["cue_dir_deg"]})
				st["t_cue_us"] = res["t_cue_us"]
				res["gap_ms"] = snappedf(now - st["t_blip"], 0.1)
				res["soa_ms"] = snappedf(st["soa"], 0.1)
				res["early_inputs"] = st["early"]
				var aimed := live and (mouse_ref - player.position).length() >= aim_thresh
				res["aim_gate_at_cue"] = _gate_of_aim(player.position, aim_angle) if aimed else -1
				res["others_alive_at_cue"] = _alive(T)
				st["phase"] = 2

		# 3. Robots appear.
		for k in T.size():
			var st: Dictionary = T[k]
			if st["phase"] == 2 and now >= st["onset"]:
				var row: Dictionary = st["row"]
				var res: Dictionary = st["res"]
				var correct: int = row["correct_gate"]
				res["others_alive_at_emerge"] = _alive(T)
				var r := Robot.new()
				var tex: Texture2D = robot_texs[rng.randi_range(0, robot_texs.size() - 1)] if not robot_texs.is_empty() else null
				r.setup(tex, 72.0, rng.randi_range(0, 1), rr)
				r.position = gate_point(correct, emerge_d)
				add_child(r)
				move_child(r, fx.get_index())
				r.face(player.position)
				st["node"] = r
				var tw := create_tween()
				tw.tween_method(func(v: float): arena.set_door(correct, v), arena.door_open[correct], 1.0, _ms(120))
				tw.tween_interval(_ms(450))
				tw.tween_method(func(v: float): arena.set_door(correct, v), 1.0, 0.0, _ms(200))
				res["t_emerge_us"] = now_us
				st["t_emerge_us"] = now_us
				res["robot_interval_ms"] = snappedf((now_us - last_robot_us) / 1000.0, 0.1) if last_robot_us > 0 else ""
				last_robot_us = now_us
				var aimed: bool = (live and (mouse_ref - player.position).length() >= aim_thresh) or st["shots"] > 0
				res["aim_gate_at_emerge"] = _gate_of_aim(player.position, aim_angle) if aimed else -1
				logger.event("robot_on", st["g"], {"gate": correct})
				_update_estimate(row)
				st["phase"] = 3

		# 4. Robots walk towards the player.
		for k in T.size():
			var st: Dictionary = T[k]
			if st["phase"] != 3:
				continue
			var node: Node2D = st["node"]
			var to_p: Vector2 = player.position - node.position
			if to_p.length() <= breach_d:
				_finish_robot(st, false, now_us, wave_kills)
				done += 1
				continue
			node.position += to_p.normalized() * min(speed * dt, to_p.length())
			node.face(player.position)

		# 5. Aim.
		var shoot := false
		if live:
			if autotest:
				var tgt := _auto_target(T, now)
				if tgt != Vector2.INF:
					mouse_ref = mouse_ref.lerp(tgt, 0.5)
					if now >= auto_next:
						shoot = true
						auto_next = now + rng.randf_range(250, 450)
			else:
				_read_mouse()
				shoot = _fire_pressed()
			var v := mouse_ref - player.position
			if v.length() >= aim_thresh:
				aim_angle = v.angle()
			crosshair.position = mouse_ref
			var cur := _gate_of_aim(player.position, aim_angle) if v.length() >= aim_thresh else -1
			if cur >= 0:
				for st in T:
					if (st["phase"] == 2 or st["phase"] == 3) and st["res"]["first_aim_ms"] is String and cur != int(st["res"]["aim_gate_at_cue"]):
						_record_first_aim(st, cur, now_us)
		else:
			var kg := _key_gate()
			if kg < 0 and autotest:
				var tgt := _auto_target(T, now)
				if tgt != Vector2.INF and now >= auto_next:
					kg = _gate_of_aim(player.position, (tgt - player.position).angle())
					auto_next = now + rng.randf_range(250, 450)
			if kg >= 0:
				# Fire at the nearest robot on that gate's side, else at the doorway.
				var tp := door_point(kg)
				var bestd := INF
				for st in T:
					if st["phase"] == 3 and _gate_of_aim(player.position, (st["node"].position - player.position).angle()) == kg:
						var dd: float = (st["node"].position - player.position).length()
						if dd < bestd:
							bestd = dd
							tp = st["node"].position
				aim_angle = (tp - player.position).angle()
				shoot = true

		# 6. Fire.
		if shoot and now - last_shot >= cooldown:
			last_shot = now
			player.fire_flash()
			_sfx("laser")
			var sgate := _gate_of_aim(player.position, aim_angle)
			var target := -1
			var best_d := INF
			for k in T.size():
				if T[k]["phase"] != 3:
					continue
				var to_r: Vector2 = T[k]["node"].position - player.position
				var dist := to_r.length()
				var half_angle := asin(clamp(rr / max(dist, rr), 0.0, 1.0)) + tol
				if abs(angle_difference(aim_angle, to_r.angle())) <= half_angle and dist < best_d:
					best_d = dist
					target = k
			for st in T:
				if st["phase"] == 1:
					st["early"] += 1
				elif st["phase"] == 2 or st["phase"] == 3:
					st["shots"] += 1
					var res: Dictionary = st["res"]
					if res["first_shot_ms"] is String:
						var row: Dictionary = st["row"]
						res["choice_gate"] = sgate
						res["choice_device"] = "auto" if autotest else ("mouse" if live else "keys")
						res["first_shot_ms"] = snappedf((now_us - st["t_cue_us"]) / 1000.0, 0.01)
						res["first_shot_before_emerge"] = 1 if st["phase"] == 2 else 0
						res["t_first_shot_us"] = now_us
						if not live or res["first_aim_ms"] is String:
							_record_first_aim(st, sgate, now_us)
			logger.event("shot", T[target]["g"] if target >= 0 else -1, {"angle_deg": snappedf(_cw_deg(aim_angle), 0.1),
					"gate": sgate, "hit": target >= 0, "hit_trial": T[target]["g"] if target >= 0 else -1})
			var muzzle := player.position + Vector2.from_angle(aim_angle) * 62.0
			if target >= 0:
				_laser(muzzle, T[target]["node"].position)
				_finish_robot(T[target], true, now_us, wave_kills)
				done += 1
			else:
				var bp := _boundary_point(aim_angle, player.position)
				_laser(muzzle, bp)
				_burst(bp, Color(0.6, 1.0, 1.0), 10, 260.0, 220)
				_sfx("spark")

		# 7. Frame log: aim, mouse, and the newest robot on screen.
		var newest := -1
		for k in T.size():
			if T[k]["phase"] == 3:
				newest = k
		var rpos: Variant = null
		var gl: int = g0
		if newest >= 0:
			rpos = T[newest]["node"].position
			gl = T[newest]["g"]
		elif next > 0:
			gl = T[next - 1]["g"]
		logger.path_sample(gl, _cw_deg(aim_angle), mouse_ref, rpos, player.position)

	for st in T:
		if st["node"] != null and is_instance_valid(st["node"]):
			st["node"].queue_free()
	tracker.visible = false
	return g0 + n


func _record_first_aim(st: Dictionary, ga: int, now_us: int) -> void:
	var res: Dictionary = st["res"]
	var row: Dictionary = st["row"]
	var cue: int = row["cue_gate"]
	res["first_aim_ms"] = snappedf((now_us - st["t_cue_us"]) / 1000.0, 0.01)
	res["first_aim_angle_deg"] = snappedf(_cw_deg(aim_angle), 0.1)
	res["first_aim_gate"] = ga
	res["first_aim_to_sound"] = (1 if ga == cue else 0) if cue >= 0 else ""
	res["first_aim_to_target"] = 1 if ga == int(row["correct_gate"]) else 0
	res["first_aim_to_sensor"] = 1 if ga == int(row["sensor_gate"]) else 0
	logger.event("first_aim", st["g"], {"angle_deg": res["first_aim_angle_deg"], "gate": ga})


## A robot is destroyed (killed) or reaches the shield: score, feedback and
## the trial row.
func _finish_robot(st: Dictionary, killed: bool, now_us: int, wave_kills: Dictionary) -> void:
	var res: Dictionary = st["res"]
	var row: Dictionary = st["row"]
	var node: Node2D = st["node"]
	var pos: Vector2 = node.position
	res["n_shots"] = st["shots"]
	res["timeout"] = 1 if st["shots"] == 0 else 0
	var choice: int = res["choice_gate"]
	var cue: int = row["cue_gate"]
	res["correct"] = 1 if choice == int(row["correct_gate"]) else 0
	res["followed_sound"] = (1 if choice == cue else 0) if (cue >= 0 and choice >= 0) else ""
	res["followed_sensor"] = (1 if choice == int(row["sensor_gate"]) else 0) if choice >= 0 else ""
	if killed:
		res["killed"] = 1
		res["kill_ms"] = snappedf((now_us - st["t_cue_us"]) / 1000.0, 0.01)
		res["kill_after_emerge_ms"] = snappedf((now_us - st["t_emerge_us"]) / 1000.0, 0.01)
		res["kill_x"] = snappedf(pos.x, 0.1)
		res["kill_y"] = snappedf(pos.y, 0.1)
		res["t_kill_us"] = now_us
		var mult := _streak_mult()
		var after: float = (now_us - st["t_emerge_us"]) / 1000.0 / time_scale
		var bonus_ms := float(cfg.get_value("score", "speed_bonus_ms", 1200))
		var bonus := int(round(float(cfg.get_value("score", "speed_bonus", 60)) * clamp(1.0 - after / bonus_ms, 0.0, 1.0)))
		var pts := (int(cfg.get_value("score", "kill_points", 100)) + bonus) * mult
		score += pts
		streak += 1
		wave_kills[int(row["wave"])] = int(wave_kills.get(int(row["wave"]), 0)) + 1
		_explosion(pos)
		_sfx("explosion")
		_popup(pos, "+%d" % pts, Color(1.0, 0.9, 0.4))
		if _streak_mult() > mult:
			_flash_banner("Streak x%d!" % _streak_mult(), 1200)
		logger.event("kill", st["g"], {"gate": row["correct_gate"], "kill_ms": res["kill_ms"]})
	else:
		res["breach"] = 1
		streak = 0
		shield = max(0, shield - 1)
		score = max(0, score - int(cfg.get_value("score", "breach_penalty", 50)))
		player.hit_shield()
		_sfx("shield")
		_play(fb_player, sounds["fail"])
		_burst(pos, Color(1.0, 0.35, 0.3), 24, 300.0, 400)
		_flash_banner("Shield down! It recharges next wave." if shield == 0 else "Shield hit!", 900)
		logger.event("breach", st["g"], {"shield": shield})
	node.queue_free()
	st["node"] = null
	st["phase"] = 4
	res["t_feedback_us"] = logger.event("feedback_on", st["g"], {"killed": res["killed"], "breach": res["breach"]})
	res["score"] = score
	res["streak"] = streak
	res["shield"] = shield
	_update_hud()
	logger.trial(res)
	if int(row["trial_in_wave"]) == int(cfg.get_value("design", "trials_per_wave", 6)) or (int(row["epoch"]) == 0 and int(row["trial_in_block"]) == int(cfg.get_value("design", "practice_trials", 6))):
		_wave_card(row, st["g"], int(wave_kills.get(int(row["wave"]), 0)))


## Autotest only: where the simulated player aims. After a short reaction
## time it aims at the nearest robot on screen; otherwise, after a bang, at
## the gate it guessed (the bang's gate 70% of the time).
func _auto_target(T: Array, now: float) -> Vector2:
	var best := Vector2.INF
	var bd := INF
	for st in T:
		if st["phase"] == 3 and not st["auto_skip"] and now - st["onset"] >= st["auto_react"]:
			var d: float = (st["node"].position - player.position).length()
			if d < bd:
				bd = d
				best = st["node"].position
	if best != Vector2.INF:
		return best
	for st in T:
		if st["phase"] == 2 and not st["auto_skip"]:
			return door_point(st["auto_gate"])
	return Vector2.INF


# ================================================================ swarm bonus wave

const SWARM_COLUMNS := ["pid", "mode", "epoch", "reliability", "robots", "bangs", "valid_bangs", "kills", "breaches", "shots",
		"duration_ms", "distance_moved_px", "score_before", "score_after", "t_start_us", "t_end_us"]

## Bonus wave at the end of each level: several robots at once from random
## gates. Each robot bangs on its gate 200-250 ms before coming through, with
## the same reliability (and silent proportion) as the level, so the swarm
## never contradicts what the level teaches; overlapping bangs make it hard
## to tell which bang belongs to which robot. No tracker. In live mode the
## player can walk anywhere on the deck. Not trials: the bangs are not counted
## in r_hat; everything is logged as events and one row in *_swarm.csv.
func _run_swarm(epoch: int, g: int, reliability: float) -> void:
	if not bool(cfg.get_value("swarm", "enabled", true)):
		return
	var n := int(cfg.get_value("swarm", "robots", 10))
	var live := mode == "live"
	var can_move := live and bool(cfg.get_value("movement", "enabled", false))
	var emerge_d := _a("emerge_distance_px", 470.0)
	var breach_d := _a("breach_distance_px", 80.0)
	var rr := _a("robot_radius_px", 34.0)
	var robot_speed := (emerge_d - breach_d) / _t("robot_walk_ms", 1500)   # px per experiment ms
	var cooldown := float(cfg.get_value("controls", "fire_cooldown_ms", 180))
	var max_ms := float(cfg.get_value("swarm", "max_ms", 40000))

	# Bang validity for each robot: same proportions as the level.
	var sil := float(cfg.get_value("design", "silent_proportion", 0.125))
	var sil_levels: Array = cfg.get_value("design", "silent_levels", [4])
	if not (epoch in sil_levels or float(epoch) in sil_levels):
		sil = 0.0
	var n_silent := int(round(n * sil))
	var n_audio := n - n_silent
	var n_valid := int(round(n_audio * reliability))
	var conds: Array = []
	for j in n:
		conds.append("valid" if j < n_valid else ("invalid" if j < n_audio else "silent"))
	for i in range(conds.size() - 1, 0, -1):
		var j := rng.randi_range(0, i)
		var tmp = conds[i]
		conds[i] = conds[j]
		conds[j] = tmp
	# Spawn plan: groups of group_min..group_max robots from different gates.
	# Each entry: [bang time, robot gate, bang gate (-1 silent), robot time].
	var plan: Array = []
	var t_spawn := 0.0
	var left := n
	while left > 0:
		var k: int = min(left, rng.randi_range(int(cfg.get_value("swarm", "group_min", 1)), int(cfg.get_value("swarm", "group_max", 3))))
		var gates: Array = [0, 1, 2]
		gates.shuffle()
		for j in k:
			var rg: int = gates[j % 3]
			var c: String = conds[plan.size()]
			var bg := rg
			if c == "invalid":
				var others: Array = [0, 1, 2]
				others.erase(rg)
				bg = others[rng.randi_range(0, 1)]
			elif c == "silent":
				bg = -1
			var tb := t_spawn + j * 150.0
			plan.append([tb, rg, bg, tb + rng.randf_range(_t("soa_min_ms", 300), _t("soa_max_ms", 300))])
		left -= k
		t_spawn += rng.randf_range(float(cfg.get_value("swarm", "interval_min_ms", 1000)), float(cfg.get_value("swarm", "interval_max_ms", 1600)))
	var robot_order: Array = range(plan.size())
	robot_order.sort_custom(func(a, b): return plan[a][3] < plan[b][3])
	var bangs := 0
	var valid_bangs := 0
	var banged := 0

	tracker.visible = false
	wave_label = "Swarm!"
	_update_hud()
	_flash_banner("Swarm incoming!", float(cfg.get_value("swarm", "intro_ms", 800)) + 300.0)
	_play(fb_player, sounds["stage"])
	await _wait(float(cfg.get_value("swarm", "intro_ms", 800)))
	var t0 := Time.get_ticks_usec()
	logger.event("swarm_start", g, {"epoch": epoch, "robots": n})
	var score_before := score
	var robots: Array = []     # {node, alive}
	var spawned := 0
	var kills := 0
	var breaches := 0
	var shots := 0
	var moved := 0.0
	var last_shot := -1.0e9
	var auto_next := 0.0
	mouse_was_down = Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)
	while true:
		await get_tree().process_frame
		var now := Time.get_ticks_usec()
		var el := (now - t0) / 1000.0 / time_scale
		var dt := get_process_delta_time() / time_scale * 1000.0     # experiment ms

		# Bangs
		while banged < plan.size() and el >= plan[banged][0]:
			var bg: int = plan[banged][2]
			if bg >= 0:
				var dir_deg := _play_cue(bg)
				bangs += 1
				if bg == int(plan[banged][1]):
					valid_bangs += 1
				logger.event("swarm_cue", g, {"cue_gate": bg, "robot_gate": plan[banged][1], "cue_dir_deg": dir_deg})
			banged += 1
		# Robots
		while spawned < plan.size() and el >= plan[robot_order[spawned]][3]:
			var gate: int = plan[robot_order[spawned]][1]
			spawned += 1
			var r := Robot.new()
			var tex: Texture2D = robot_texs[rng.randi_range(0, robot_texs.size() - 1)] if not robot_texs.is_empty() else null
			r.setup(tex, 72.0, rng.randi_range(0, 1), rr)
			r.position = gate_point(gate, emerge_d)
			add_child(r)
			move_child(r, fx.get_index())
			robots.append({"node": r, "alive": true})
			var tw := create_tween()
			tw.tween_method(func(v: float): arena.set_door(gate, v), arena.door_open[gate], 1.0, _ms(120))
			tw.tween_interval(_ms(500))
			tw.tween_method(func(v: float): arena.set_door(gate, v), 1.0, 0.0, _ms(250))
			logger.event("swarm_robot_on", g, {"gate": gate})

		# Player movement (live mode)
		if can_move:
			moved += _move_player(true)

		# Robots walk towards the player
		var alive := 0
		for rb in robots:
			if not rb["alive"]:
				continue
			var node: Node2D = rb["node"]
			var to_p := player.position - node.position
			if to_p.length() <= breach_d:
				rb["alive"] = false
				breaches += 1
				streak = 0
				shield = max(0, shield - 1)
				score = max(0, score - int(cfg.get_value("score", "breach_penalty", 50)))
				player.hit_shield()
				_sfx("shield")
				_burst(node.position, Color(1.0, 0.35, 0.3), 24, 300.0, 400)
				node.queue_free()
				logger.event("swarm_breach", g, {"shield": shield})
				_update_hud()
				continue
			node.position += to_p.normalized() * min(robot_speed * dt, to_p.length())
			node.face(player.position)
			alive += 1

		# Aim and fire
		var shoot := false
		if live:
			if autotest:
				var tgt := _nearest_robot(robots)
				if tgt != null:
					mouse_ref = tgt.position
					if el >= auto_next:
						shoot = true
						auto_next = el + rng.randf_range(250, 450)
			else:
				shoot = _fire_pressed()
			var v := mouse_ref - player.position
			if v.length() >= 20.0:
				aim_angle = v.angle()
		else:
			var kg := _key_gate()
			if kg < 0 and autotest and el >= auto_next and alive > 0:
				var tgt := _nearest_robot(robots)
				if tgt != null:
					kg = _gate_of_aim(player.position, (tgt.position - player.position).angle())
					auto_next = el + rng.randf_range(250, 450)
			if kg >= 0:
				# Fire at the nearest robot coming from that gate's side, else at the doorway.
				var tp := door_point(kg)
				var bestd := INF
				for rb in robots:
					if rb["alive"] and _gate_of_aim(player.position, (rb["node"].position - player.position).angle()) == kg:
						var dd: float = (rb["node"].position - player.position).length()
						if dd < bestd:
							bestd = dd
							tp = rb["node"].position
				aim_angle = (tp - player.position).angle()
				shoot = true
		if shoot and el - last_shot >= cooldown:
			last_shot = el
			shots += 1
			player.fire_flash()
			_sfx("laser")
			var d := Vector2.from_angle(aim_angle)
			var muzzle := player.position + d * 62.0
			var best: Dictionary = {}
			var best_t := INF
			for rb in robots:
				if not rb["alive"]:
					continue
				var rel: Vector2 = rb["node"].position - player.position
				var along := rel.dot(d)
				if along <= 0.0:
					continue
				var perp: float = abs(rel.cross(d))
				if perp <= rr + 6.0 and along < best_t:
					best_t = along
					best = rb
			if not best.is_empty():
				var node: Node2D = best["node"]
				best["alive"] = false
				kills += 1
				var mult := _streak_mult()
				var pts := int(cfg.get_value("score", "kill_points", 100)) * mult
				score += pts
				streak += 1
				_laser(muzzle, node.position)
				_explosion(node.position)
				_popup(node.position, "+%d" % pts, Color(1.0, 0.9, 0.4))
				_sfx("explosion")
				node.queue_free()
				_update_hud()
				logger.event("swarm_kill", g, {"score": score})
			else:
				var bp := _boundary_point(aim_angle, player.position)
				_laser(muzzle, bp)
				_burst(bp, Color(0.6, 1.0, 1.0), 10, 260.0, 220)
				_sfx("spark")

		if (spawned >= plan.size() and alive == 0) or el >= max_ms or aborting:
			break

	for rb in robots:
		if rb["alive"]:
			rb["node"].queue_free()
	var t1 := Time.get_ticks_usec()
	logger.event("swarm_end", g, {"kills": kills, "breaches": breaches, "score": score})
	logger.append_csv("_swarm.csv", SWARM_COLUMNS, {"pid": pid, "mode": mode, "epoch": epoch, "reliability": reliability,
			"robots": n, "bangs": bangs, "valid_bangs": valid_bangs,
			"kills": kills, "breaches": breaches, "shots": shots,
			"duration_ms": snappedf((t1 - t0) / 1000.0, 0.1), "distance_moved_px": snappedf(moved, 0.1),
			"score_before": score_before, "score_after": score, "t_start_us": t0, "t_end_us": t1})
	_flash_banner("Swarm cleared:  %d of %d destroyed" % [kills, n], 1400)
	# Walk back to the centre for the next level.
	var tw2 := create_tween()
	tw2.tween_property(player, "position", centre, _ms(300))
	await _wait(float(cfg.get_value("swarm", "outro_ms", 900)))
	player.position = centre


func _nearest_robot(robots: Array) -> Node2D:
	var best: Node2D = null
	var bd := INF
	for rb in robots:
		if rb["alive"]:
			var d: float = (rb["node"].position - player.position).length()
			if d < bd:
				bd = d
				best = rb["node"]
	return best


# ================================================================ ratings, questionnaire, validation, pause

func _hold_step(action: String, held: Dictionary, dt: float) -> bool:
	## True on press, then repeatedly while held (after 0.35 s, every 0.07 s).
	if Input.is_action_just_pressed(action):
		held[action] = -0.35
		return true
	if Input.is_action_pressed(action):
		held[action] = held.get(action, 0.0) + dt
		if held[action] >= 0.07:
			held[action] = 0.0
			return true
	return false


func _show_rating_ui(question: String, mode_name: String) -> void:
	blackout.visible = true
	_hud_visible(false)
	rating_ui.visible = true
	rating_q.text = question
	var bar_mode := mode_name == "slider"
	for n in [rating_ui.get_node("bar"), rating_fill, rating_value, rating_left, rating_right]:
		n.visible = bar_mode
	choice_label.visible = mode_name == "choice"
	text_edit.visible = mode_name == "text"


## Slider from lo to hi. Returns [value, rt_ms, moved].
func _slider(question: String, lo: int, hi: int, step: int, start: int, left: String, right: String, suffix: String) -> Array:
	_show_rating_ui(question, "slider")
	rating_left.text = left
	rating_right.text = right
	rating_hint.text = "LEFT / RIGHT to change, SPACE to confirm"
	var v := start
	var held := {}
	var t0 := Time.get_ticks_usec()
	var moved := false
	while true:
		var frac := float(v - lo) / float(hi - lo)
		rating_fill.size.x = 1000.0 * frac
		rating_value.text = "%d%s" % [v, suffix]
		await get_tree().process_frame
		var dt := get_process_delta_time()
		if autotest:
			v = lo + step * rng.randi_range(0, (hi - lo) / step)
			break
		if _hold_step("gate_left", held, dt):
			v = max(lo, v - step)
			moved = true
		if _hold_step("gate_right", held, dt):
			v = min(hi, v + step)
			moved = true
		if Input.is_action_just_pressed("continue") and Time.get_ticks_usec() - t0 > 500000:
			break
	rating_ui.visible = false
	return [v, snappedf((Time.get_ticks_usec() - t0) / 1000.0, 0.1), moved]


## Multiple choice. Returns [index, rt_ms].
func _choice(question: String, options: Array) -> Array:
	_show_rating_ui(question, "choice")
	rating_hint.text = "UP / DOWN to choose, SPACE to confirm"
	var idx := -1
	var t0 := Time.get_ticks_usec()
	while true:
		var lines: PackedStringArray = []
		for k in options.size():
			lines.append(("> " if k == idx else "   ") + options[k])
		choice_label.text = "\n".join(lines)
		await get_tree().process_frame
		if autotest:
			idx = rng.randi_range(0, options.size() - 1)
			break
		if Input.is_action_just_pressed("move_down"):
			idx = 0 if idx < 0 else min(options.size() - 1, idx + 1)
		if Input.is_action_just_pressed("gate_ahead"):
			idx = 0 if idx < 0 else max(0, idx - 1)
		if Input.is_action_just_pressed("continue") and idx >= 0:
			break
	rating_ui.visible = false
	return [idx, snappedf((Time.get_ticks_usec() - t0) / 1000.0, 0.1)]


## Free text, submitted with ENTER. Returns [text, rt_ms].
func _free_text(question: String) -> Array:
	_show_rating_ui(question, "text")
	rating_hint.text = "Press ENTER when done (you can leave it empty)"
	var t0 := Time.get_ticks_usec()
	if autotest:
		rating_ui.visible = false
		return ["", 0.0]
	text_edit.text = ""
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	text_edit.grab_focus()
	var txt: String = await text_edit.text_submitted
	text_edit.release_focus()
	Input.mouse_mode = Input.MOUSE_MODE_CONFINED_HIDDEN
	rating_ui.visible = false
	return [txt, snappedf((Time.get_ticks_usec() - t0) / 1000.0, 0.1)]


const RATING_COLUMNS := ["pid", "mode", "epoch", "actual_reliability", "item", "value", "moved", "rt_ms", "t_us"]

## Explicit trust ratings at the end of each level.
func _level_ratings(epoch: int, actual: float) -> void:
	if not bool(cfg.get_value("ratings", "enabled", true)):
		return
	var t := logger.event("ratings_start", -1, {"epoch": epoch})
	var r1 := await _slider("Level %d is complete.\n\nIn this level, how often did the bang come from the gate the robot then came through?" % epoch,
			0, 100, 5, 50, "Never", "Always", "%")
	logger.append_csv("_ratings.csv", RATING_COLUMNS, {"pid": pid, "mode": mode, "epoch": epoch,
			"actual_reliability": actual, "item": "estimated_sound_accuracy", "value": r1[0], "moved": int(r1[2]), "rt_ms": r1[1], "t_us": t})
	var r2 := await _slider("In this level, when the bang and the motion tracker pointed to different gates, which did you follow?",
			1, 7, 1, 4, "Always the tracker", "Always the bang", "")
	logger.append_csv("_ratings.csv", RATING_COLUMNS, {"pid": pid, "mode": mode, "epoch": epoch,
			"actual_reliability": actual, "item": "reliance_sound_vs_tracker", "value": r2[0], "moved": int(r2[2]), "rt_ms": r2[1], "t_us": t})
	logger.event("ratings_end", -1, {"epoch": epoch, "estimated_sound_accuracy": r1[0], "reliance": r2[0]})


const Q_COLUMNS := ["pid", "mode", "item", "question", "response", "response_index", "rt_ms"]

## Short end-of-session questionnaire (gaming experience is the proposal's covariate).
func _questionnaire() -> void:
	logger.event("questionnaire_start")
	var items := [
		["gaming_hours", "About how many hours per week do you play video games?",
			["None", "Less than 2 hours", "2 to 5 hours", "5 to 10 hours", "More than 10 hours"]],
		["shooter_experience", "How often do you play shooting games?",
			["Never", "Rarely", "Sometimes", "Often"]],
		["noticed_change", "Did the bang seem more trustworthy in some levels than in others?",
			["Yes", "No", "Not sure"]],
		["strategy", "Overall, what did you rely on most to aim?",
			["Mostly the bang", "Mostly the motion tracker", "Both about equally", "Neither, I waited to see the robot"]],
		["localization", "Could you tell which gate the bang came from?",
			["Always", "Usually", "Sometimes", "Rarely"]],
	]
	for it in items:
		var r := await _choice(it[1], it[2])
		logger.append_csv("_questionnaire.csv", Q_COLUMNS, {"pid": pid, "mode": mode, "item": it[0],
				"question": it[1], "response": it[2][r[0]], "response_index": r[0], "rt_ms": r[1]})
	var skill := await _slider("How skilled are you at video games?", 1, 7, 1, 4, "Not at all skilled", "Very skilled", "")
	logger.append_csv("_questionnaire.csv", Q_COLUMNS, {"pid": pid, "mode": mode, "item": "gaming_skill",
			"question": "How skilled are you at video games? (1-7)", "response": skill[0], "response_index": skill[0], "rt_ms": skill[1]})
	var fun := await _slider("How enjoyable was the game?", 1, 7, 1, 4, "Not at all", "Very enjoyable", "")
	logger.append_csv("_questionnaire.csv", Q_COLUMNS, {"pid": pid, "mode": mode, "item": "enjoyment",
			"question": "How enjoyable was the game? (1-7)", "response": fun[0], "response_index": fun[0], "rt_ms": fun[1]})
	var txt := await _free_text("Anything else you noticed, or how you decided where to aim?")
	logger.append_csv("_questionnaire.csv", Q_COLUMNS, {"pid": pid, "mode": mode, "item": "comments",
			"question": "Anything else you noticed, or how you decided where to aim?", "response": txt[0], "response_index": "", "rt_ms": txt[1]})
	logger.event("questionnaire_end")


## Gaze validation: dots at known positions, each logged as a marker, so
## calibration accuracy and drift can be computed offline from the gaze stream.
func _run_validation(tag: String) -> void:
	if not bool(cfg.get_value("validation", "enabled", true)):
		return
	var margin := float(cfg.get_value("validation", "margin", 0.1))
	var ms := float(cfg.get_value("validation", "point_ms", 1200))
	var pts: Array = []
	for fy in [margin, 0.5, 1.0 - margin]:
		for fx_ in [margin, 0.5, 1.0 - margin]:
			pts.append(Vector2(REF.x * fx_, REF.y * fy))
	var order: Array = range(pts.size())
	var r := RandomNumberGenerator.new()
	r.seed = hash(pid + tag)
	for i in range(order.size() - 1, 0, -1):
		var j := r.randi_range(0, i)
		var tmp = order[i]
		order[i] = order[j]
		order[j] = tmp
	_hud_visible(false)
	blackout.visible = true
	message.text = "Look at each dot until it disappears."
	message.visible = true
	await _wait(1500)
	message.visible = false
	logger.event("validation_start", -1, {"tag": tag})
	for k in order:
		val_target.position = pts[k]
		val_target.visible = true
		val_target.queue_redraw()
		logger.event("validation_point", -1, {"tag": tag, "index": k, "x": pts[k].x, "y": pts[k].y})
		await _wait(ms)
	val_target.visible = false
	logger.event("validation_end", -1, {"tag": tag})


## Experimenter pause (P). V runs a gaze validation before continuing.
func _pause_screen(g: int) -> void:
	pause_requested = false
	hint.text = ""
	_hud_visible(false)
	logger.event("pause_start", g)
	blackout.visible = true
	message.text = "Paused.\n\nSPACE: continue\nV: gaze validation, then continue"
	message.visible = true
	while true:
		await get_tree().process_frame
		if Input.is_action_just_pressed("continue"):
			break
		if Input.is_action_just_pressed("validate"):
			message.visible = false
			await _run_validation("pause_before_%d" % (g + 1))
			break
	message.visible = false
	logger.event("pause_end", g)


# ================================================================ localization test

func _run_localization(rows: Array) -> void:
	await _wait_continue("Sound check.\n\nYou will hear a bang from one of the three gates.\n"
		+ "Press  LEFT,  UP  or  RIGHT  (or A, W, D) for the gate it came from.\n\n"
		+ "Look at yourself in the centre.")
	_reset_scene()
	var hits := [0, 0, 0]
	var counts := [0, 0, 0]
	var g := 0
	for row in rows:
		if aborting:
			break
		g += 1
		var e: int = row["cue_gate"]
		var res: Dictionary = row.duplicate()
		res["pid"] = pid
		res["mode"] = mode
		res["trial_global"] = g
		blackout.visible = false
		res["t_start_us"] = logger.event("start_on", g)
		await _wait(_t("start_ms", 500) + rng.randf_range(0, 500))
		if cue_streams[e] != null:
			cue_player.stream = cue_streams[e]
			cue_player.play()
		var t_cue := logger.event("cue_on", g, {"cue_gate": e})
		res["t_cue_us"] = t_cue
		var choice := -1
		var end_us := t_cue + int(_ms(_t("response_window_ms", 2600)) * 1e6)
		var auto_at := t_cue + int(_ms(rng.randf_range(250, 700)) * 1e6)
		while Time.get_ticks_usec() < end_us:
			await get_tree().process_frame
			choice = _key_gate()
			if choice < 0 and autotest and Time.get_ticks_usec() >= auto_at:
				choice = e if rng.randf() < 0.9 else rng.randi_range(0, 2)
			if choice >= 0:
				res["first_shot_ms"] = snappedf((Time.get_ticks_usec() - t_cue) / 1000.0, 0.01)
				res["t_first_shot_us"] = Time.get_ticks_usec()
				res["choice_device"] = "auto" if autotest else "keys"
				break
		res["choice_gate"] = choice
		res["timeout"] = 1 if choice < 0 else 0
		res["correct"] = 1 if choice == e else 0
		res["followed_sound"] = res["correct"]
		logger.event("response" if choice >= 0 else "timeout", g, {"choice_gate": choice})
		logger.trial(res)
		counts[e] += 1
		hits[e] += res["correct"]
		blackout.visible = true
		await _wait(_t("iti_ms", 500))
	var lines: PackedStringArray = []
	for e in 3:
		lines.append("%s: %d / %d" % [GATE_NAMES[e], hits[e], counts[e]])
	var total: int = hits[0] + hits[1] + hits[2]
	var n: int = counts[0] + counts[1] + counts[2]
	var summary := "Localization: %d / %d correct (%.0f%%)\n\n%s" % [total, n, 100.0 * total / max(n, 1), "\n".join(lines)]
	logger.event("localization_summary", -1, {"hits": hits, "counts": counts})
	print(summary)
	await _wait_continue(summary)


# ================================================================ screenshots

func _shot(path: String) -> void:
	for f in 8:
		await get_tree().process_frame
	get_viewport().get_texture().get_image().save_png(path)
	print("Saved ", path)


func _take_screenshots() -> void:
	var out := DataLogger.resolve_data_dir().path_join("screenshots")
	DirAccess.make_dir_recursive_absolute(out)
	mode = "live"
	pid_edit.text = "P004"
	await _shot(out.path_join("ui_menu.png"))
	menu.visible = false
	message.text = _instructions() + "\n\n[Press SPACE to continue]"
	message.visible = true
	await _shot(out.path_join("ui_instructions.png"))
	message.visible = false
	score = 2340
	streak = 4
	shield = 4
	autotest = true
	time_scale = 0.01
	await _stage_card(2, 0)
	autotest = false
	time_scale = 1.0
	blackout.visible = true
	for l in [stage_title, stage_sub, stage_hint]:
		l.visible = true
		l.modulate.a = 1.0
	stage_hint.text = "Score so far: %d\n\n[Press SPACE to continue]" % score
	await _shot(out.path_join("stage_card.png"))
	for l in [stage_title, stage_sub, stage_hint]:
		l.visible = false
	wave_label = "Wave 3 / 6"
	_update_hud()
	_hud_visible(true)
	blackout.visible = false
	_reset_scene()
	await _shot(out.path_join("trial_start.png"))
	for level in ["clear", "faded"]:
		tracker.show_blip(GATE_DIRS[0], float(cfg.get_value("visibility", level + "_sensor_alpha", 0.9)))
		await _shot(out.path_join("preview_%s.png" % level))
	# Robot coming through the right gate, player aiming at it.
	tracker.show_blip(GATE_DIRS[2], 0.9)
	arena.set_door(2, 1.0)
	robot = Robot.new()
	robot.setup(robot_texs[0] if not robot_texs.is_empty() else null, 72.0, 0, 34.0)
	robot.position = gate_point(2, 330.0)
	add_child(robot)
	move_child(robot, fx.get_index())
	robot.face(centre)
	aim_angle = (robot.position - centre).angle() - 0.25
	crosshair.position = centre + Vector2.from_angle(aim_angle) * 240.0
	crosshair.visible = true
	await _shot(out.path_join("robot_incoming.png"))
	aim_angle = (robot.position - centre).angle()
	crosshair.position = robot.position
	player.fire_flash()
	_laser(centre + Vector2.from_angle(aim_angle) * 62.0, robot.position)
	_explosion(robot.position)
	_popup(robot.position, "+148", Color(1.0, 0.9, 0.4))
	robot.queue_free()
	robot = null
	for f in 3:
		await get_tree().process_frame
	get_viewport().get_texture().get_image().save_png(out.path_join("robot_destroyed.png"))
	await get_tree().create_timer(0.8).timeout
	_reset_scene()
	tracker.show_blip(GATE_DIRS[1], 0.9)
	arena.set_door(0, 1.0)
	robot = Robot.new()
	robot.setup(robot_texs[0] if not robot_texs.is_empty() else null, 72.0, 1, 34.0)
	robot.position = gate_point(0, 82.0)
	add_child(robot)
	robot.face(centre)
	aim_angle = -PI / 2.0
	player.hit_shield()
	banner.text = "Shield hit!"
	shield = 3
	_update_hud()
	for f in 2:
		await get_tree().process_frame
	get_viewport().get_texture().get_image().save_png(out.path_join("shield_hit.png"))
	_reset_scene()
	_hud_visible(true)
	crosshair.visible = false
	tracker.show_blip(GATE_DIRS[0], 0.9)
	banner.text = "Wave 3 cleared:  5 of 6 robots destroyed"
	await _shot(out.path_join("wave_cleared.png"))
	banner.text = ""
	# Swarm: several robots, player off-centre.
	free_aim = false
	tracker.visible = false
	wave_label = "Swarm!"
	_update_hud()
	player.position = centre + Vector2(-160, 120)
	var extra: Array = []
	for spec in [[0, 300.0], [1, 220.0], [2, 360.0]]:
		var r := Robot.new()
		r.setup(robot_texs[0] if not robot_texs.is_empty() else null, 72.0, spec[0] % 2, 34.0)
		r.position = gate_point(spec[0], spec[1])
		add_child(r)
		r.face(player.position)
		extra.append(r)
	arena.set_door(2, 1.0)
	aim_angle = (extra[1].position - player.position).angle()
	crosshair.position = extra[1].position
	crosshair.visible = true
	banner.text = "Swarm incoming!"
	await _shot(out.path_join("swarm.png"))
	for r in extra:
		r.queue_free()
	player.position = centre
	arena.close_all()
	banner.text = ""
	wave_label = "Wave 3 / 6"
	_show_rating_ui("Level 2 is complete.\n\nIn this level, how often did the bang come from the gate the robot then came through?", "slider")
	rating_left.text = "Never"
	rating_right.text = "Always"
	rating_hint.text = "LEFT / RIGHT to change, SPACE to confirm"
	rating_fill.size.x = 650.0
	rating_value.text = "65%"
	await _shot(out.path_join("rating_level_end.png"))
	rating_ui.visible = false
	val_target.position = Vector2(REF.x * 0.1, REF.y * 0.1)
	val_target.visible = true
	await _shot(out.path_join("validation_dot.png"))
	get_tree().quit()
