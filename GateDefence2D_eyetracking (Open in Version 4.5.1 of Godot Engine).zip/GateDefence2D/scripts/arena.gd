extends Node2D
## Draws the arena: a square deck with gates in the left, top and right walls
## (none at the bottom), the space outside, and the sliding gate doors.
## Lighting is constant, so screen brightness is identical on every trial.

const GATE_DIRS := [Vector2.LEFT, Vector2.UP, Vector2.RIGHT]

var centre := Vector2(960, 540)
var half := 440.0
var wall := 40.0
var gate_w := 190.0
var tracker_r := 130.0
var door_open := [0.0, 0.0, 0.0]   # 0 closed .. 1 open
var stars: Array = []

const FLOOR := Color(0.12, 0.14, 0.18)
const FLOOR_LINE := Color(0.17, 0.19, 0.24)
const WALL := Color(0.30, 0.33, 0.39)
const WALL_EDGE := Color(0.42, 0.46, 0.53)
const SPACE := Color(0.03, 0.035, 0.06)
const HAZARD_A := Color(0.85, 0.66, 0.16)
const HAZARD_B := Color(0.12, 0.12, 0.13)


func setup(p_centre: Vector2, p_half: float, p_wall: float, p_gate_w: float, p_tracker_r: float) -> void:
	centre = p_centre
	half = p_half
	wall = p_wall
	gate_w = p_gate_w
	tracker_r = p_tracker_r
	var r := RandomNumberGenerator.new()
	r.seed = 7
	stars.clear()
	for k in 260:
		var p := Vector2(r.randf_range(0, 1920), r.randf_range(0, 1080))
		if abs(p.x - centre.x) < half + wall + 140 and abs(p.y - centre.y) < half + wall + 140:
			continue
		stars.append([p, r.randf_range(0.8, 2.0), r.randf_range(0.25, 0.7)])
	queue_redraw()


func set_door(g: int, amount: float) -> void:
	door_open[g] = amount
	queue_redraw()


func close_all() -> void:
	for g in 3:
		door_open[g] = 0.0
	queue_redraw()


## Point at distance d from the centre towards gate g.
func gate_point(g: int, d: float) -> Vector2:
	return centre + GATE_DIRS[g] * d


func _draw() -> void:
	draw_rect(Rect2(0, 0, 1920, 1080), SPACE)
	for s in stars:
		draw_circle(s[0], s[1], Color(0.8, 0.85, 1.0, s[2]))

	var outer := half + wall
	# Corridors leading out of each gate (the robots come along them).
	for g in 3:
		var d: Vector2 = GATE_DIRS[g]
		var side := Vector2(-d.y, d.x)
		var a: Vector2 = centre + d * half + side * gate_w * 0.5
		var b: Vector2 = centre + d * (outer + 170.0) - side * gate_w * 0.5
		var rect := Rect2(Vector2(min(a.x, b.x), min(a.y, b.y)), (a - b).abs())
		draw_rect(rect, Color(0.09, 0.10, 0.13))
		for k in 5:
			var p: Vector2 = centre + d * (outer + 20.0 + 34.0 * k)
			draw_line(p + side * gate_w * 0.5, p - side * gate_w * 0.5, Color(0.13, 0.15, 0.19), 2.0)
		# Corridor walls
		for sgn in [-1.0, 1.0]:
			var q1: Vector2 = centre + d * outer + side * sgn * (gate_w * 0.5 + 6.0)
			var q2: Vector2 = centre + d * (outer + 170.0) + side * sgn * (gate_w * 0.5 + 6.0)
			draw_line(q1, q2, WALL, 12.0)

	# Deck floor with plates.
	var top_left := centre - Vector2(half, half)
	draw_rect(Rect2(top_left, Vector2(half, half) * 2.0), FLOOR)
	var step := 88.0
	var n := int(round(2.0 * half / step))
	for i in range(1, n):
		var x := top_left.x + i * step
		draw_line(Vector2(x, top_left.y), Vector2(x, top_left.y + 2 * half), FLOOR_LINE, 2.0)
		var y := top_left.y + i * step
		draw_line(Vector2(top_left.x, y), Vector2(top_left.x + 2 * half, y), FLOOR_LINE, 2.0)
	for i in range(1, n):
		for j in range(1, n):
			draw_circle(top_left + Vector2(i, j) * step, 2.5, Color(0.2, 0.22, 0.27))
	# Central pad (where the player starts each level).
	draw_circle(centre, 64.0, Color(0.16, 0.18, 0.23))
	draw_arc(centre, 64.0, 0, TAU, 64, Color(0.24, 0.27, 0.33), 3.0)

	# Walls with gate openings (left, top, right) and a solid bottom wall.
	var o := outer
	var h := half
	var gw := gate_w * 0.5
	var c := centre
	var rects := [
		# top wall: two pieces around the gate
		Rect2(c.x - o, c.y - o, o - gw, wall), Rect2(c.x + gw, c.y - o, o - gw, wall),
		# bottom wall: solid
		Rect2(c.x - o, c.y + h, 2 * o, wall),
		# left wall
		Rect2(c.x - o, c.y - h, wall, h - gw), Rect2(c.x - o, c.y + gw, wall, h - gw),
		# right wall
		Rect2(c.x + h, c.y - h, wall, h - gw), Rect2(c.x + h, c.y + gw, wall, h - gw),
	]
	for r in rects:
		draw_rect(r, WALL)
		draw_rect(r, WALL_EDGE, false, 2.0)

	# Doors: two halves that slide into the wall.
	for g in 3:
		_draw_door(g)


func _draw_door(g: int) -> void:
	var d: Vector2 = GATE_DIRS[g]
	var side := Vector2(-d.y, d.x)
	var mid: Vector2 = centre + d * (half + wall * 0.5)
	var gw := gate_w * 0.5
	var leaf: float = gw * (1.0 - door_open[g])
	if leaf <= 2.0:
		return
	for sgn in [-1.0, 1.0]:
		# Each leaf spans from the gate edge towards the middle.
		var edge: Vector2 = mid + side * sgn * gw
		var inner: Vector2 = mid + side * sgn * (gw - leaf)
		var thick := wall * 0.42
		var pts := PackedVector2Array([
			edge + d * thick, inner + d * thick, inner - d * thick, edge - d * thick])
		draw_colored_polygon(pts, HAZARD_B)
		# hazard stripes
		var nstripes := int(leaf / 18.0) + 1
		for k in nstripes:
			var t0 := float(k) * 18.0
			if t0 > leaf:
				break
			var t1: float = min(t0 + 9.0, leaf)
			if t1 - t0 < 1.0:
				break
			var p0: Vector2 = inner + side * sgn * t0
			var p1: Vector2 = inner + side * sgn * t1
			draw_colored_polygon(PackedVector2Array([
				p0 + d * thick, p1 + d * thick, p1 - d * thick, p0 - d * thick]), HAZARD_A)
		draw_polyline(PackedVector2Array([pts[0], pts[1], pts[2], pts[3], pts[0]]), Color(0.05, 0.05, 0.05), 2.0)
