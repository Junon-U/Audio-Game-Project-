extends Node2D
## The player at the centre. Rotates to the aim direction. Uses the optional
## Kenney sprite if it was found, otherwise a drawn figure. Facing: +x.

var sprite: Sprite2D
var flash := 0.0
var shield_flash := 0.0
var shield_r := 80.0


func set_texture(tex: Texture2D, size_px: float) -> void:
	if tex == null:
		return
	sprite = Sprite2D.new()
	sprite.texture = tex
	sprite.scale = Vector2.ONE * size_px / float(max(tex.get_width(), tex.get_height()))
	add_child(sprite)


## Aim angle in Godot radians (0 = right, clockwise positive on screen).
func set_aim(angle_rad: float) -> void:
	rotation = angle_rad


func fire_flash() -> void:
	flash = 0.06
	queue_redraw()


func hit_shield() -> void:
	shield_flash = 0.35
	queue_redraw()


func _process(delta: float) -> void:
	if flash > 0.0 or shield_flash > 0.0:
		flash = max(0.0, flash - delta)
		shield_flash = max(0.0, shield_flash - delta)
		queue_redraw()


func _draw() -> void:
	if shield_flash > 0.0:
		var a := shield_flash / 0.35
		draw_circle(Vector2.ZERO, shield_r, Color(1.0, 0.3, 0.25, 0.22 * a))
		draw_arc(Vector2.ZERO, shield_r, 0, TAU, 64, Color(1.0, 0.4, 0.3, 0.9 * a), 4.0)
	if sprite == null:
		# body
		draw_circle(Vector2(-4, 0), 25.0, Color(0.20, 0.42, 0.62))
		draw_arc(Vector2(-4, 0), 25.0, 0, TAU, 40, Color(0.08, 0.16, 0.25), 3.0)
		# shoulders / arms holding the blaster
		draw_rect(Rect2(6, -12, 30, 9), Color(0.85, 0.7, 0.55))
		draw_rect(Rect2(6, 4, 22, 9), Color(0.85, 0.7, 0.55))
		draw_rect(Rect2(18, -5, 34, 10), Color(0.25, 0.27, 0.30))
		draw_rect(Rect2(46, -3, 10, 6), Color(0.45, 0.85, 0.95))
		# helmet
		draw_circle(Vector2(-6, 0), 13.0, Color(0.85, 0.88, 0.92))
		draw_circle(Vector2(-1, 0), 6.0, Color(0.15, 0.35, 0.5))
	if flash > 0.0:
		draw_circle(Vector2(62, 0), 13.0, Color(0.7, 1.0, 1.0, 0.9))
		draw_circle(Vector2(62, 0), 7.0, Color(1, 1, 1, 1))
