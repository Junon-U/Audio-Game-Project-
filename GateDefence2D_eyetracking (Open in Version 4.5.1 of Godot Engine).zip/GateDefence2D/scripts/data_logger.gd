extends RefCounted
## Writes trial, event and movement-path CSV files and sends event markers over UDP.
## Timestamps: t_us = Time.get_ticks_usec() (monotonic, microseconds since start).
## tools/lsl_bridge.py re-stamps each marker on the LSL clock when it arrives.

const TRIAL_COLUMNS := [
	"pid", "mode", "block", "epoch", "wave", "trial_global", "trial_in_block", "trial_in_wave",
	"reliability", "reliability_condition", "audio_cond", "visibility",
	"correct_gate", "cue_gate", "sensor_gate", "sensor_valid",
	"robot_interval_ms", "others_alive_at_cue", "others_alive_at_emerge", "gap_ms", "soa_ms", "early_inputs", "player_x_cue", "player_y_cue", "cue_dir_deg", "moved_px",
	"first_aim_ms", "first_aim_angle_deg", "first_aim_gate",
	"first_aim_to_sound", "first_aim_to_target", "first_aim_to_sensor", "aim_gate_at_cue", "aim_gate_at_emerge",
	"choice_gate", "choice_device", "first_shot_ms", "first_shot_before_emerge",
	"correct", "followed_sound", "followed_sensor", "n_shots",
	"killed", "kill_ms", "kill_after_emerge_ms", "kill_x", "kill_y", "breach", "timeout",
	"score", "streak", "shield",
	"cue_valid", "cue_sensor", "n_audio_prev", "n_valid_prev", "r_hat",
	"correct_x", "correct_y", "cue_x", "cue_y", "sensor_x", "sensor_y",
	"t_scene_us", "t_cue_us", "t_emerge_us", "t_first_shot_us", "t_kill_us", "t_feedback_us",
]

var data_dir := ""
var base_name := ""
var trials_file: FileAccess
var events_file: FileAccess
var path_file: FileAccess
var extra_files := {}     # suffix -> FileAccess (ratings, questionnaire)
var udp := PacketPeerUDP.new()
var udp_enabled := false
var tracker_udp := PacketPeerUDP.new()
var pid := ""


## data/ next to the project (editor) or next to the .exe (exported game).
## If that folder cannot be written (e.g. the .exe is in Program Files), the
## game falls back to its user folder (%APPDATA%/Godot/app_userdata/Gate Defence/data).
## The menu screen shows which folder is in use.
static func resolve_data_dir() -> String:
	var base: String
	if OS.has_feature("editor"):
		base = ProjectSettings.globalize_path("res://")
	else:
		base = OS.get_executable_path().get_base_dir()
	var d := base.path_join("data")
	DirAccess.make_dir_recursive_absolute(d)
	var probe := d.path_join(".write_test")
	var f := FileAccess.open(probe, FileAccess.WRITE)
	if f == null:
		d = OS.get_user_data_dir().path_join("data")
		DirAccess.make_dir_recursive_absolute(d)
	else:
		f.close()
		DirAccess.remove_absolute(probe)
	return d


func open(p_pid: String, mode: String, cfg: ConfigFile) -> void:
	pid = p_pid
	data_dir = resolve_data_dir()
	var stamp := Time.get_datetime_string_from_system().replace(":", "-").replace("T", "_")
	base_name = "%s_%s_%s" % [pid, mode, stamp]
	trials_file = FileAccess.open(path_of("_trials.csv"), FileAccess.WRITE)
	events_file = FileAccess.open(path_of("_events.csv"), FileAccess.WRITE)
	path_file = FileAccess.open(path_of("_paths.csv"), FileAccess.WRITE)
	if trials_file == null or events_file == null or path_file == null:
		push_error("Cannot write data files in %s" % data_dir)
		return
	trials_file.store_line(",".join(TRIAL_COLUMNS))
	events_file.store_line("t_us,unix_time,event,trial_global,details")
	path_file.store_line("trial_global,t_us,aim_deg,mouse_x_px,mouse_y_px,robot_x_px,robot_y_px,player_x_px,player_y_px")

	udp_enabled = bool(cfg.get_value("network", "udp_enabled", true))
	if udp_enabled:
		var host := str(cfg.get_value("network", "udp_host", "127.0.0.1"))
		var port := int(cfg.get_value("network", "udp_port", 12345))
		if udp.set_dest_address(host, port) != OK:
			push_warning("UDP marker output disabled")
			udp_enabled = false


## Sends a command to eyeTrack.exe (Tobii Eye Tracker 5): "c" starts
## recording, "s" stops it. Logged as an eyetracker_command event.
func eyetracker(cmd: String, cfg: ConfigFile) -> void:
	if not bool(cfg.get_value("eyetracker", "enabled", false)):
		return
	var host := str(cfg.get_value("eyetracker", "host", "127.0.0.1"))
	var port := int(cfg.get_value("eyetracker", "port", 1234))
	if tracker_udp.set_dest_address(host, port) == OK:
		tracker_udp.put_packet(cmd.to_ascii_buffer())
		event("eyetracker_command", -1, {"command": cmd})


func path_of(suffix: String) -> String:
	return data_dir.path_join(base_name + suffix)


## Logs an event, sends it as a marker, returns its timestamp.
func event(name: String, trial_global: int = -1, details: Dictionary = {}) -> int:
	var t := Time.get_ticks_usec()
	var det := JSON.stringify(details) if not details.is_empty() else ""
	if events_file:
		events_file.store_line("%d,%.6f,%s,%d,\"%s\"" % [t, Time.get_unix_time_from_system(),
				name, trial_global, det.replace("\"", "\"\"")])
	if udp_enabled:
		var msg := {"event": name, "trial": trial_global, "t_us": t, "pid": pid}
		msg.merge(details)
		udp.put_packet(JSON.stringify(msg).to_utf8_buffer())
	return t


## One row per frame of the response window: aim angle (degrees clockwise
## from up), the mouse position, the robot position (empty before it appears)
## and the player position.
func path_sample(trial_global: int, aim_deg: float, mouse: Vector2, robot: Variant, player_pos: Vector2) -> void:
	if path_file:
		var rx := ""
		var ry := ""
		if robot is Vector2:
			rx = "%.1f" % robot.x
			ry = "%.1f" % robot.y
		path_file.store_line("%d,%d,%.1f,%.1f,%.1f,%s,%s,%.1f,%.1f" % [trial_global, Time.get_ticks_usec(), aim_deg, mouse.x, mouse.y, rx, ry, player_pos.x, player_pos.y])


func trial(row: Dictionary) -> void:
	if trials_file == null:
		return
	var vals: PackedStringArray = []
	for c in TRIAL_COLUMNS:
		var v = row.get(c, "")
		var s := str(v)
		if s.contains(","):
			s = "\"" + s + "\""
		vals.append(s)
	trials_file.store_line(",".join(vals))
	trials_file.flush()
	events_file.flush()
	path_file.flush()


## Appends one row to an extra CSV file (created with a header on first use).
func append_csv(suffix: String, columns: Array, row: Dictionary) -> void:
	if not extra_files.has(suffix):
		var f := FileAccess.open(path_of(suffix), FileAccess.WRITE)
		if f == null:
			return
		f.store_line(",".join(columns))
		extra_files[suffix] = f
	var vals: PackedStringArray = []
	for c in columns:
		var s := str(row.get(c, ""))
		if s.contains(",") or s.contains("\"") or s.contains("\n"):
			s = "\"" + s.replace("\"", "\"\"").replace("\n", " ") + "\""
		vals.append(s)
	extra_files[suffix].store_line(",".join(vals))
	extra_files[suffix].flush()


func write_json(suffix: String, data: Dictionary) -> void:
	var f := FileAccess.open(path_of(suffix), FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(data, "  "))
		f.close()


func close() -> void:
	for f in [trials_file, events_file, path_file]:
		if f:
			f.close()
	for f in extra_files.values():
		f.close()
	extra_files.clear()
	trials_file = null
	events_file = null
	path_file = null
	udp.close()
	tracker_udp.close()
