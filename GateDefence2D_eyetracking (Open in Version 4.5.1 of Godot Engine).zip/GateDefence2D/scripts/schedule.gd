extends RefCounted
## Trial schedule generation and CSV import/export for Gate Defence.
##
## Gates: 0 = left, 1 = ahead, 2 = right (-1 = none).
## Each row is a Dictionary:
##   block                  "practice", "epoch1" ... "epochN" or "localization"
##   epoch                  0 for practice / localization, 1..N for levels
##   trial_in_block         1-based index within the block
##   wave, trial_in_wave    wave number within the block and position in it (1-based)
##   reliability            sound-cue validity of the epoch (practice = 1.0)
##   reliability_condition  1-based index of the participant's (epoch 2, epoch 3) pair
##   audio_cond             "valid", "invalid" or "silent"
##   visibility             "clear" or "faded" motion tracker blip
##   correct_gate           gate the robot comes through
##   cue_gate               gate the bang comes from (-1 when silent)
##   sensor_gate            gate marked by the tracker blip
##   sensor_valid           1 if the blip marks the correct gate

const COLUMNS := ["block", "epoch", "trial_in_block", "wave", "trial_in_wave", "reliability", "reliability_condition",
		"audio_cond", "visibility", "correct_gate", "cue_gate", "sensor_gate", "sensor_valid"]
const N_GATES := 3

var rng := RandomNumberGenerator.new()


func _shuffle(arr: Array) -> void:
	for i in range(arr.size() - 1, 0, -1):
		var j := rng.randi_range(0, i)
		var tmp = arr[i]
		arr[i] = arr[j]
		arr[j] = tmp


func _other_gate(e: int) -> int:
	var opts: Array = [0, 1, 2]
	opts.erase(e)
	return opts[rng.randi_range(0, 1)]


## All reliability conditions: list of [epoch2, epoch3] pairs.
static func reliability_conditions(cfg: ConfigFile) -> Array:
	var o2: Array = cfg.get_value("design", "epoch_reliability_2_options", [0.4, 0.55, 0.7])
	var o3: Array = cfg.get_value("design", "epoch_reliability_3_options", [0.4, 0.55, 0.7])
	var differ := bool(cfg.get_value("design", "epoch3_must_differ", true))
	var out: Array = []
	for a in o2:
		for b in o3:
			if differ and is_equal_approx(float(a), float(b)):
				continue
			out.append([float(a), float(b)])
	return out


## Reliability per level for a participant. [design] level_pattern lists the
## levels in order, "full" (epoch_reliability_full, 100%) or "low". The low
## levels take the participant's condition: the first low level a value from
## epoch_reliability_2_options, the second from epoch_reliability_3_options
## (different from the first when epoch3_must_differ). Returns
## {"levels": [r per level], "r1".."rN", "condition" (1-based), "n_conditions", "method"}.
static func assign_reliability(pid: String, cfg: ConfigFile) -> Dictionary:
	var conds := reliability_conditions(cfg)
	var method := str(cfg.get_value("design", "reliability_assignment", "id_number"))
	var re := RegEx.new()
	re.compile("(\\d+)\\D*$")
	var m := re.search(pid)
	var idx: int
	if method == "id_number" and m != null:
		idx = posmod(int(m.get_string(1)) - 1, conds.size())
	else:
		method = "random"
		var r := RandomNumberGenerator.new()
		r.seed = hash(pid + "_reliability")
		idx = r.randi_range(0, conds.size() - 1)
	var pattern: Array = cfg.get_value("design", "level_pattern", ["full", "full", "low", "low"])
	var full := float(cfg.get_value("design", "epoch_reliability_full", 1.0))
	var levels: Array = []
	var low_i := 0
	for lv in pattern:
		if str(lv) == "full":
			levels.append(full)
		else:
			levels.append(conds[idx][min(low_i, 1)])
			low_i += 1
	var out := {"levels": levels, "condition": idx + 1, "n_conditions": conds.size(), "method": method, "pattern": pattern}
	for i in levels.size():
		out["r%d" % (i + 1)] = levels[i]
	return out


func _make_block(block: String, epoch: int, n: int, reliability: float, silent_prop: float,
		sensor_rel: float, condition: int, per_wave: int) -> Array:
	var n_silent := int(round(n * silent_prop))
	var n_audio := n - n_silent
	var n_valid := int(round(n_audio * reliability))
	var n_invalid := n_audio - n_valid

	# Visibility balanced within each audio condition.
	var trials: Array = []
	for pair in [["valid", n_valid], ["invalid", n_invalid], ["silent", n_silent]]:
		var levels: Array = []
		for k in pair[1]:
			levels.append("clear" if k % 2 == 0 else "faded")
		_shuffle(levels)
		for k in pair[1]:
			trials.append({"audio_cond": pair[0], "visibility": levels[k]})
	_shuffle(trials)

	# Correct gate balanced across the three gates.
	var correct: Array = []
	for k in n:
		correct.append(k % N_GATES)
	_shuffle(correct)

	# Tracker validity: exact proportion overall (round(n * sensor_rel)), split
	# as evenly as possible between the two visibility levels.
	var sensor := {}
	var total_ok := int(round(n * sensor_rel))
	var ok_left := total_ok
	for level in ["clear", "faded"]:
		var idxs: Array = []
		for k in n:
			if trials[k]["visibility"] == level:
				idxs.append(k)
		var n_ok := int(round(idxs.size() * sensor_rel)) if level == "clear" else ok_left
		n_ok = clampi(n_ok, 0, idxs.size())
		ok_left -= n_ok
		var flags: Array = []
		for k in idxs.size():
			flags.append(1 if k < n_ok else 0)
		_shuffle(flags)
		for k in idxs.size():
			sensor[idxs[k]] = flags[k]

	var rows: Array = []
	for k in n:
		var c: int = correct[k]
		var cond: String = trials[k]["audio_cond"]
		var cue := -1
		if cond == "valid":
			cue = c
		elif cond == "invalid":
			cue = _other_gate(c)
		var sv: int = sensor[k]
		rows.append({
			"block": block, "epoch": epoch, "trial_in_block": k + 1,
			"wave": k / per_wave + 1, "trial_in_wave": k % per_wave + 1,
			"reliability": reliability, "reliability_condition": condition,
			"audio_cond": cond, "visibility": trials[k]["visibility"],
			"correct_gate": c, "cue_gate": cue,
			"sensor_gate": c if sv == 1 else _other_gate(c), "sensor_valid": sv,
		})
	return rows


## Full session: practice + one block per level in level_pattern. Same ID -> same schedule.
func generate(seed_text: String, cfg: ConfigFile) -> Array:
	rng.seed = hash(seed_text)
	var n_epoch := int(cfg.get_value("design", "trials_per_epoch", 36))
	var per_wave := int(cfg.get_value("design", "trials_per_wave", 6))
	var silent := float(cfg.get_value("design", "silent_proportion", 0.125))
	var silent_levels: Array = cfg.get_value("design", "silent_levels", [4])
	var n_prac := int(cfg.get_value("design", "practice_trials", 6))
	var sensor := float(cfg.get_value("design", "sensor_reliability", 0.75))
	var rel := assign_reliability(seed_text, cfg)
	var rows: Array = []
	if n_prac > 0:
		rows.append_array(_make_block("practice", 0, n_prac, 1.0, 0.0, 1.0, rel["condition"], max(n_prac, 1)))
	var levels: Array = rel["levels"]
	for i in levels.size():
		var e := i + 1
		var r := float(levels[i])
		var sp := silent if (e in silent_levels or float(e) in silent_levels) else 0.0
		rows.append_array(_make_block("epoch%d" % e, e, n_epoch, r, sp, sensor, rel["condition"], per_wave))
	return rows


## Localization pre-test: each gate direction repeated `reps` times.
func generate_localization(seed_text: String, cfg: ConfigFile) -> Array:
	rng.seed = hash(seed_text + "_loc")
	var reps := int(cfg.get_value("design", "localization_reps", 8))
	var order: Array = []
	for e in N_GATES:
		for r in reps:
			order.append(e)
	_shuffle(order)
	var rows: Array = []
	for k in order.size():
		rows.append({
			"block": "localization", "epoch": 0, "trial_in_block": k + 1, "wave": 0, "trial_in_wave": 0,
			"reliability": 1.0, "reliability_condition": 0, "audio_cond": "valid",
			"visibility": "none", "correct_gate": order[k], "cue_gate": order[k],
			"sensor_gate": -1, "sensor_valid": 0,
		})
	return rows


static func save_csv(rows: Array, path: String) -> void:
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		push_error("Cannot write schedule: %s" % path)
		return
	f.store_line(",".join(COLUMNS))
	for r in rows:
		var vals: PackedStringArray = []
		for c in COLUMNS:
			vals.append(str(r[c]))
		f.store_line(",".join(vals))
	f.close()


## Loads a schedule written by save_csv (or edited by hand). [] if missing.
static func load_csv(path: String) -> Array:
	if not FileAccess.file_exists(path):
		return []
	var f := FileAccess.open(path, FileAccess.READ)
	var header := f.get_csv_line()
	var rows: Array = []
	while not f.eof_reached():
		var line := f.get_csv_line()
		if line.size() < header.size():
			continue
		var r := {}
		for i in header.size():
			r[header[i]] = line[i]
		for k in ["epoch", "trial_in_block", "wave", "trial_in_wave", "reliability_condition", "correct_gate", "cue_gate", "sensor_gate", "sensor_valid"]:
			r[k] = int(r[k])
		r["reliability"] = float(r["reliability"])
		rows.append(r)
	return rows
