# Gate Defence

Top-down 2D wave shooter for "Learning When to Trust Sound". Godot 4.5. Built on the Cave Maze code (schedules, reliability conditions, logging, LSL markers, ratings, validation, questionnaire, analysis).

The player guards the deck of a space station. Robots break in through three gates: left, ahead and right (the bottom wall has no gate, so sounds never come from behind). Every robot is one trial. Before it appears there are two imperfect sources of evidence:

- **Sound:** the robot slams once on a gate, a loud, low metal-plate slam with a thump underneath, 300 ms before the door opens (valid, invalid or silent). Other game sounds are kept quieter so the slam stands out.
- **Vision:** the motion tracker ring around the player shows a blip toward one gate, right on 75% of trials, either clear or faded.

The robot then walks toward the player and has to be shot before it reaches the shield.

## Why this design

- **Sound before sight.** The slam leads the robot by exactly 300 ms. That is just longer than it takes for a first eye movement to a sound to start (about 200 to 250 ms), so players can start looking and aiming at the slam's gate before the robot appears. Following a valid slam pays off; an invalid one sends them the wrong way.
- **Fixed beat.** There is no dark screen or "get ready" phase between robots. A robot appears every 1.2 s, whether or not the previous one has been destroyed, so a slow player faces two robots at once. Wave messages appear at the bottom of the screen without pausing play.
- **Clean trials.** One robot at a time, so every gaze shift and shot belongs to one cue. Waves are runs of 6 robots.
- **No game over.** Robots that reach the player cost a shield pip and points; the shield recharges each wave. Everyone plays every trial.
- **Matched brightness.** Lighting is identical on every trial; only the tracker blip differs between clear and faded (measured: screen mean 26.83 vs 26.75; blip contrast 4.4 vs 0.9).
- **Identical scenes.** Same arena, gate positions and robot speed on every trial; difficulty does not change across waves or levels, so it cannot be confused with reliability.
- **Full feedback.** The robot always comes through its real gate, so players see on every trial whether the bang was right.

## Trial timeline

| Phase | Duration | What happens |
|---|---|---|
| Tracker blip | from the previous robot's appearance | The blip points to this robot's gate (for the first robot of a level: blip, then a random 600 to 1000 ms). |
| Sound | 300 ms file | One slam from one gate (or silence), 300 ms before the robot. |
| Robot appears | every 1200 ms | Door opens silently; robot appears in the doorway. |
| Robot walk | about 1500 ms | Robot walks toward the player unless destroyed. Because this is longer than the beat, the next robot can appear while it is still coming. |
| Feedback | immediate | Explosion and points, or shield hit. Play never pauses. |

The screen never goes dark between robots; it only goes dark for the level cards and rests between levels. Settings are in `[timing]` of `config/experiment.cfg`.

## Controls

- **Live play:** the player stays at the centre; aim with the mouse, fire with the left button or SPACE, at any time. The aim carries over from one robot to the next, so the aim at the bang is logged (`aim_gate_at_cue`), and the first aim is the first time after the bang that the aim points at a different gate (or the first shot, if that comes first).
- **Replay:** LEFT / UP / RIGHT (or A / W / D) fires at that gate. Press again to fire again.
- **Localization test:** sounds only; press the direction they came from.
- Experimenter: P pauses after the current robot (V runs a gaze validation), ESC twice aborts.
- Gaze validation (nine dots) runs once at the start. `[validation] after_each_level` and `at_end` add more for drift checks.

## Moving around (off by default)

The player stays at the centre. Movement can be switched on with `[movement] enabled=true`; then in live play the player walks with W A S D in every level and aims with the mouse. In the measured waves the player stays within 240 px of the centre (`trial_radius_px`), so robots always have a similar distance to cover; in the swarm the whole deck is open. Robots walk toward wherever the player is.

The bang is played from the direction of its gate as heard from where the player stands at that moment. `tools/make_stimuli.py` renders it for every direction in 5 degree steps (`audio/stimuli/dir/`), and the game picks the nearest file. Each trial row logs the player's position at the bang (`player_x_cue`, `player_y_cue`), the direction played (`cue_dir_deg`) and the distance walked (`moved_px`); `_paths.csv` has the player position every frame. Gate AOIs stay fixed on screen; the tracker ring moves with the player, and `sensor_x/y` gives the blip's position when it appeared.

Replay mode has no movement (A, W and D fire at the gates). `[movement] enabled=false` keeps the player at the centre.

## Fixed beat and overlapping robots

Robots appear every `robot_interval_ms` (1200 ms), to within one screen frame, whatever the player does. A robot walks for 1500 ms before reaching the shield, so if it is not destroyed within 1.2 s the next one appears while it is still on screen. The bang comes exactly 300 ms before each robot, so both bang and robot times follow the fixed beat. The first robot of each level (and after a pause) starts with a random 600 to 1000 ms wait.

Each robot is still one trial row, written when it is destroyed or reaches the shield. With overlap, the first aim and first shot after a robot's bang may be aimed at an earlier robot that is still coming. Each row therefore records `others_alive_at_cue` and `others_alive_at_emerge` (other robots on screen at that robot's bang and appearance), and `tools/analyze.py` marks trials with neither as `clean`. Use the clean trials for the gaze and first-response analyses, and report how many there were. Every shot event in `_events.csv` records which robot it hit (`hit_trial`).

Players know when the next robot will come (though not where), so their eyes may move with the beat as well as with the bang. That applies to every condition equally; report it in the methods.

## The tracker is wrong on purpose

The tracker blip points from wherever the player stands to one gate. On 25% of robots (`sensor_reliability=0.75`) that is not the robot's gate: the tracker is the imperfect visual cue that players weigh against the bang. The instructions tell players it is "usually, but not always, right".

## Swarm bonus wave

Each level ends with a Swarm: 10 robots in groups of 1 to 3 from random gates, coming at the player together. Each robot bangs on its gate 300 ms before it comes through, so the bangs overlap. The bangs have the same reliability and silent proportion as the level, so the swarm never contradicts what the level teaches, but with several bangs at once it is hard to tell which belongs to which robot. The tracker is off.

Swarm robots are not trials and their bangs are not counted in r_hat. Each swarm is one row in `*_swarm.csv` (level reliability, bangs, valid bangs, kills, breaches, shots, duration, distance walked, score) plus `swarm_cue`, `swarm_robot_on`, `swarm_kill` and `swarm_breach` events. The player walks back to the centre before the next level. Settings are in `[swarm]`; `enabled=false` removes it.

## Levels, waves, score

There are four levels, each a reliability epoch: Level 1 "Outer Ring" and Level 2 "Cargo Bay" at 100%, then Level 3 "Reactor Deck" and Level 4 "Command Bridge" at lower reliability. The two lower levels take 40%, 55% or 70%, assigned by participant number (6 conditions; Level 4 always differs from Level 3). Players build trust in the slam over two full levels before it starts to fail; `level_pattern=["full", "low", "full", "low"]` in `[design]` gives a high-low-high-low order instead. Silent robots (no slam) appear only in Level 4, 5 of its 36 robots, so the silence catches players off guard rather than teaching them early that the slam can be missing (`silent_levels` in `[design]`). Each level is 6 waves of 6 robots (36 trials), with a neutral title card at the start of each level. A session is 6 practice + 4 x 36 = 150 robots plus four swarms, about 5 minutes of play.

There are no questions inside the game: the level-end ratings and the end questionnaire are switched off (`[ratings]` and `[questionnaire]` `enabled=false`) because they are asked in person. Turning them back on restores `_ratings.csv` and `_questionnaire.csv`.

Score: 100 per robot plus a speed bonus (up to 60, falling to 0 at 1.2 s after the robot appears), times a streak multiplier (x2 after 3 kills in a row, x3 after 6, x4 after 10). A breach costs 50 points and a shield pip.

## Assets

The game runs without downloading anything: the player, robots and arena are drawn in code, and the laser and explosion sounds are synthesized by `tools/make_stimuli.py`. The Kenney sounds it needs (cue, interface sounds) are already included.

For nicer art and effects, download these free CC0 packs and unzip them anywhere inside `assets/optional/`, keeping their folders. Then open the project in Godot once so it imports them. The menu screen lists which optional files are in use.

| Pack | Link | Used for |
|---|---|---|
| Kenney Top-down Shooter | https://kenney.nl/assets/top-down-shooter | Player (survivor with gun) and robot sprites |
| Kenney Sci-fi Sounds | https://kenney.nl/assets/sci-fi-sounds | Laser and explosion sounds |
| Kenney Impact Sounds (included) | https://kenney.nl/assets/impact-sounds | Robot slam (the cue: `impactPlate_light_001` pitched down a fourth, with a low thump and soft saturation for loudness) and shot sparks |
| Kenney Interface Sounds (included) | https://kenney.nl/assets/interface-sounds | Level, wave and error sounds |
| SADIE II HRTF database (optional) | https://www.york.ac.uk/sadie-project/database.html | Measured-HRTF cues for data collection |

Files are found by the names in `[assets]` of the config. If a name is not found, the first file whose name contains a keyword is used (player: "survivor" and "gun"; robot: "robot" and "hold"; sounds: "lasersmall", "explosion"). Effects are always played mono, so they never carry direction. Doors open without a sound, so nothing but the bang tells where a robot is coming from.

## Mapping to the proposal

| Proposal | Here |
|---|---|
| Avatar at screen centre | Player at the centre of the deck (optional movement within 240 px of it) |
| Target among distractors | The robot's gate among three |
| Visual uncertainty (proposal: clutter) | Clear vs faded tracker blip; brightness matched |
| Spatialized sound from target or distractor | Binaural bang from the robot's gate or another gate |
| Reliability epochs (80 / 50 / 80%), 10 to 15% silent | Four levels, 100% / 100% / low / low, low levels assigned per participant; silent robots (5 of 36) in Level 4 only |
| Live play vs replay | Mouse aim and fire vs key presses |
| Sound 300 to 500 ms, response 2 to 3 s | 300 ms bang; robot appears 300 ms after it and reaches the player about 1.8 s after it; a new robot every 1.2 s |
| 500 ms start + 1000 to 1500 ms scene + 500 ms ITI | One continuous 600 to 1000 ms gap with the tracker blip visible (no dark ITI); shorter than the proposal's scene time, for pace |

## Before data collection

1. **Run the localization test** in the pilot (should be near 100% with three directions; the cues are about 26 just-noticeable differences apart by `tools/check_cues.py`).
2. **Tune the faded blip.** `faded_sensor_alpha` sets how hard it is to see. After changing it, run with `-- --shots` and `python tools/measure_visibility.py` to check contrast and that brightness stays matched.
3. **Decide the tracker's reliability.** At 75% the tracker is more reliable than the bang in both low levels (at most 70%), so following the tracker on conflict trials is always the better strategy. Lowering `sensor_reliability` to 0.6 makes the bang the better cue at 70% and the tracker the better cue at 40%.
4. **Validate timing** once with a loopback recording of the headphone output against the `cue_on` and `robot_on` markers. Audio output latency shortens the real bang-to-robot interval: check that the measured interval is close to 300 ms and stable.
5. Optional: `python tools/make_stimuli.py --sofa <file>` renders the cues with a measured HRTF.

## Exporting as an .exe

The project includes a Windows export preset (`export_presets.cfg`).

1. In Godot: Editor > Manage Export Templates > Download and Install (once).
2. Project > Export > "Windows Desktop" > Export Project. This writes `export/GateDefence.exe` (one file; the game data is embedded).
3. Copy the .exe to a folder the participant account can write to (Desktop or Documents, not Program Files).

Data is the same as in the editor. Differences to know:

- **Data folder:** `data/` next to the .exe. If that folder cannot be written, the game uses `%APPDATA%/Godot/app_userdata/Gate Defence/data` instead. The start screen shows which folder is in use.
- **Settings:** the preset packs `config/experiment.cfg` into the .exe. To change settings without re-exporting, put an edited copy at `config/experiment.cfg` next to the .exe; it is used instead. The start screen and `_session.json` (`config_source`) show which file was used.
- **Schedules:** `schedules/<ID>.csv` next to the .exe, if present.
- **LSL:** still run `python tools/lsl_bridge.py` on the lab PC; the .exe sends the same markers. Allow it through Windows Firewall if asked (it only sends to 127.0.0.1).
- **Command-line options** work the same: `GateDefence.exe -- --autotest`.

## Start screen

The experimenter enters the participant ID and chooses the mode. The reliability condition is not shown (participants may see this screen); it is assigned from the ID number and saved in `_session.json` and in every trial row (`reliability`, `reliability_condition`). To look up a participant's condition beforehand, run with `-- --make-schedule=P001` and open `schedules/P001.csv`.

## Session procedure

### With the Tobii Eye Tracker 5 (enhanced-tobii-eyetracker)

1. Calibrate in Tobii Experience.
2. Start `eyeTrack.exe` from its `bin` folder and leave it running.
3. Start the game, fullscreen. At session start the game sends `c` to eyeTrack.exe (UDP 127.0.0.1:1234) to start a new recording, and `s` at session end to stop it (`[eyetracker]` in the config; logged as `eyetracker_command` events). The game's nine-dot validation runs first.
4. After the session: `python tools/merge_gaze.py` (newest session) or `python tools/merge_gaze.py data/<session>_events.csv`. Set the screen size and distance with `--screen-cm 34.5 21.5 --distance-cm 50`, and the gaze folder with `--gaze-dir` if it is not `Documents/enhanced-tobii-eyetracker/data`.

The merge lines up both PC clocks (gaze `human_time`, game `unix_time`), converts gaze to game pixels (the 1920x1080 frame, allowing for black bars on 16:10 screens) and scores the in-game validation (accuracy, precision, how long the eyes took to reach each dot). Gate areas are the left, top and right quarters around the player beyond `--centre-radius` (200 game pixels), wide enough for the ET5's 2 to 3 degree accuracy. The ET5 gives about 33 samples per second, so gaze times are accurate to about 30 ms.

Gaze columns added to every robot (`_trials_gaze.csv`; full definitions at the top of `tools/merge_gaze.py`):

| Question | Columns |
|---|---|
| Data quality | `gaze_coverage`, `gaze_ok` |
| Did they act on the blip before the bang? | `pre_cue_centre_pct`, `pre_cue_sensor_gate_pct`, `at_cue_on_sensor_gate` |
| Where did the eyes go first after the bang, and when? | `first_gaze_gate`, `first_gaze_ms`, `first_gaze_before_emerge`, `first_gaze_to_sound` / `_target` / `_sensor` |
| How long until the eyes found the robot? (cost of a wrong bang) | `gaze_to_target_ms`, `target_after_emerge_ms` |
| Where did the eyes stay? (bang to 600 ms) | `dwell_sound_pct`, `dwell_target_pct`, `dwell_sensor_pct`, `dwell_centre_pct` |
| How much did they search? | `n_gate_switches`, `visited_wrong_gate` |
| Did the eyes lead the aim? (live) | `gaze_aim_lead_ms`, `gaze_aim_same_gate` |

`_gaze_timecourse.csv` has the share of gaze on the bang's, robot's and blip's gate in 50 ms bins from 300 ms before to 1500 ms after the bang.

After all sessions are merged, `python tools/gaze_group.py` writes `analysis/gaze_participants.csv` (validation accuracy, precision, coverage, exclusion: mean accuracy above 3 degrees or coverage below 75%), `gaze_trials_all.csv` (all robots, for mixed-effects models), `gaze_timecourse_all.csv`, `gaze_participant_means.csv` (per participant, reliability and bang condition) and group plots by reliability: first gaze to the bang (with conflict trials), cost of a wrong bang, time course, and following the bang against `r_hat`.

The ET5 does not give pupil size, blinks (eyeTrack.exe drops invalid samples, so blinks and tracking loss look the same) or saccade velocities (too few samples per second), so those measures are not available.

### With an LSL eye tracker

1. Start the eye tracker and its LSL outlet; calibrate.
2. `python tools/lsl_bridge.py`
3. Start LabRecorder; record the gaze stream and `GateDefenceMarkers`.
4. Run the localization test, then Replay and Live play.

Set `[eyetracker] enabled=false` when not using eyeTrack.exe.

Run fullscreen. On a 1920x1080 monitor logged positions equal screen pixels; on other screens the scaling is saved in `_session.json` (`screen_px`, `reference_to_window_scale`).

## Data (`data/`)

Files are named `<ID>_<mode>_<date-time>_*`: `_trials.csv` (one row per robot), `_events.csv` (every marker), `_paths.csv` (aim angle, mouse and robot position every frame of the response window), `_swarm.csv` (and `_ratings.csv`, `_questionnaire.csv` if those are turned on), `_schedule.csv`, `_session.json`.

Gate codes: 0 left, 1 ahead, 2 right, -1 none (aim or shot toward the bottom wall).

| Column | Meaning |
|---|---|
| reliability, reliability_condition | that level's sound reliability; the participant's condition |
| wave, trial_in_wave | wave within the level and position in it |
| audio_cond, visibility | valid / invalid / silent; clear / faded blip |
| correct_gate, cue_gate, sensor_gate, sensor_valid | trial structure |
| robot_interval_ms, soa_ms, gap_ms, early_inputs | time since the previous robot appeared (1200 ms; empty for the first robot of a level); bang-to-robot interval; time from this robot's blip to its bang; shots fired in that time |
| others_alive_at_cue, others_alive_at_emerge | other robots on screen at this robot's bang and when it appeared (0 = clean trial) |
| player_x_cue, player_y_cue, cue_dir_deg, moved_px | player position at the bang; direction the bang was played from (degrees clockwise from up, as heard by the player); distance walked during the trial |
| aim_gate_at_cue | where the aim pointed at the bang (live; -1 = near the player) |
| first_aim_ms, first_aim_angle_deg, first_aim_gate | first switch of aim to another gate after the bang, or the first shot (live); first key press (replay) |
| first_aim_to_sound / _target / _sensor | first aim toward the bang, the robot's gate, the blip |
| aim_gate_at_emerge | where the aim pointed when the robot appeared (-1 = not yet aimed) |
| choice_gate, first_shot_ms, first_shot_before_emerge | gate of the first shot, its time from the bang, whether it came before the robot appeared |
| correct, followed_sound, followed_sensor | first shot at the robot's gate / the bang's gate / the blip's gate |
| n_shots, killed, kill_ms, kill_after_emerge_ms, kill_x, kill_y, breach, timeout | outcome (timeout = no shot fired) |
| score, streak, shield | game state after the trial |
| cue_valid, cue_sensor | bang right (1/0, empty if silent); bang and blip agree / conflict / no_cue |
| n_audio_prev, n_valid_prev, r_hat | the proposal's reliability estimate before this trial |
| correct_x/y, cue_x/y, sensor_x/y | screen positions for gaze AOIs |
| t_*_us | timestamps (blip moved, cue, robot appears, first shot, kill, feedback) |

Schedules are generated from the participant ID (same ID, same schedule). Within each level: robot gate balanced over the three gates, visibility balanced within each audio condition, tracker validity exactly 75% within each visibility level. To fix a schedule in advance: run with `-- --make-schedule=P001` (writes `schedules/P001.csv`).

`python tools/analyze.py` merges all sessions into `analysis/trials_all.csv` and writes per-level summaries (first-shot accuracy, shot accuracy, kills, clean trials, sound-following overall and on clean trials, tracker-following on conflict trials, anticipatory shots, valid vs invalid kill times, ratings), condition summaries, localization accuracy, questionnaire answers and a sound-following figure per mode.

## Files

```
config/experiment.cfg       all settings
scripts/main.gd             session flow, trials, waves, score, input, localization test, screenshots
scripts/schedule.gd         schedule generation, reliability assignment, CSV in/out
scripts/data_logger.gd      CSV logging, UDP markers
scripts/arena.gd            deck, walls, gates and doors
scripts/player.gd           player drawing / sprite, shield flash
scripts/robot.gd            robot drawing / sprite
scripts/tracker.gd          motion tracker blip
assets/kenney_audio/        Kenney impact and interface sounds (CC0)
assets/optional/            put the optional Kenney packs here
audio/stimuli/              binaural cue files (generated)
audio/sfx/                  synthesized fallback effects (generated)
tools/make_stimuli.py       renders the cues, effects and ambience
tools/check_cues.py         measures how distinguishable the cues are
tools/measure_visibility.py blip contrast and screen brightness from screenshots
tools/lsl_bridge.py         UDP markers to LSL
tools/merge_gaze.py         Tobii ET5 gaze (eyeTrack.exe) merged with a session, gaze per robot
tools/gaze_group.py         all merged sessions: exclusion, participant means, group plots
tools/analyze.py            merges sessions, summary tables and figures
docs/                       screenshots
```

Command-line options (after `--`): `--autotest` or `--autotest-mode=replay|localization` (fast simulated session; `--autotest-pid=P003` sets the ID), `--make-schedule=<ID>`, `--shots` (screenshots to `data/screenshots/`).

Sounds by Kenney (www.kenney.nl), CC0.
