#!/usr/bin/env python3
"""Render the binaural cue files, fallback sound effects and the ambience for Gate Defence.

Cues
----
audio/stimuli/cue_00.wav, cue_01.wav, cue_02.wav: the three gates as heard from
the centre of the deck (used by the localization test).
audio/stimuli/dir/cue_dir_000.wav ... cue_dir_355.wav: the same bang from every
direction in --step degree steps (default 5). The player can walk around, so
at each bang the game computes the direction from the player to the gate and
plays the nearest file. Every participant hears identical files.

Direction mapping: screen up = straight ahead, screen right = right ear.
Directions come from [cues] angles_deg in config/experiment.cfg (clockwise
from up; default left 270, ahead 0, right 90). Azimuth (SOFA convention,
positive = left) is minus that angle.

The cue is a robot slamming once on a gate: one strike of the Kenney
"impactPlate_light_001" sound (CC0), a metal-plate slam with a sharp attack
and energy from low to high frequencies (both help localization), pitched
down a fourth (--pitch 0.75), with a low 115-to-55 Hz thump mixed in
(--thump-db), soft saturation for loudness (--drive) and a gentle 5 kHz
low-pass (--lowpass) to keep it from sounding harsh, cut to 280 ms,
plus a short shared room echo (identical for every gate, so it never tells which cue is
valid). Files are cut to --max-total-ms (default 300 ms).

Spatialization:
  1. Left/right: interaural time and level differences. Default "enhanced"
     mode exaggerates them (ITD x1.3, ILD up to ~16 dB). --natural uses
     realistic values; --sofa uses measured HRIRs (e.g. SADIE II KEMAR,
     https://www.york.ac.uk/sadie-project/database.html).
  2. Front/back: a brightness code (sounds from ahead are crisp). With three
     frontal gates it mainly separates "ahead" from the sides.
Run tools/check_cues.py afterwards to measure how distinguishable the cues are.

Fallback sound effects (audio/sfx/*.wav, synthesized, mono, used when the
optional Kenney Sci-fi Sounds pack is not installed): laser.wav,
explosion.wav, shield.wav. They are mono so they carry no direction.

A report with azimuths, ITDs, durations and levels is written to
audio/stimuli/stimuli_report.json for the methods section.

Requires: numpy, scipy, soundfile (h5py for --sofa).
"""
import argparse
import configparser
import glob
import json
import os
import sys

import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, lfilter, fftconvolve, resample_poly

FS = 48000
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_TAP = os.path.join(ROOT, "assets", "kenney_audio", "impactPlate_light_001.ogg")


def read_angles(cfg_path):
    """Cue directions in degrees clockwise from straight up ([cues] angles_deg)."""
    cp = configparser.ConfigParser(inline_comment_prefixes=(";",))
    cp.read(cfg_path)
    return [float(a) for a in json.loads(cp["cues"]["angles_deg"])]


def slot_azimuths(angles):
    out = []
    for ang in angles:
        ang = ang % 360.0                              # clockwise from up
        az = (-ang + 180.0) % 360.0 - 180.0            # positive = left
        out.append((ang, az))
    return out


def load_tap(path, max_ms, pitch=1.0, thump_db=None, drive=0.0, lowpass=None):
    """One strike: the recording, optionally pitched down (pitch 0.5 = one
    octave lower, played more slowly) and with a low decaying thump mixed in."""
    import soundfile as sf
    x, sr = sf.read(path, always_2d=True)
    x = x.mean(axis=1)
    if sr != FS:
        x = resample_poly(x, FS, sr)
    if pitch != 1.0:
        x = resample_poly(x, int(round(100 / pitch)), 100)
    thr = 0.02 * np.max(np.abs(x))
    start = max(0, int(np.argmax(np.abs(x) > thr)) - int(0.002 * FS))
    x = x[start: start + int(max_ms / 1000 * FS)].copy()
    x /= np.max(np.abs(x))
    if thump_db is not None:
        t = np.arange(len(x)) / FS
        f = 55 + 60 * np.exp(-t / 0.03)            # 115 Hz falling to 55 Hz
        thump = np.sin(2 * np.pi * np.cumsum(f) / FS) * np.exp(-t / 0.06)
        x = x + thump * 10 ** (thump_db / 20)
    x /= np.max(np.abs(x))
    if drive > 0:
        # Soft saturation: raises loudness (RMS) without raising the peak.
        x = np.tanh(drive * x) / np.tanh(drive)
    if lowpass:
        b, a = butter(2, lowpass / (FS / 2), "low")
        x = lfilter(b, a, x)
    fade = min(int(0.03 * FS), len(x) // 3)
    x[-fade:] *= np.linspace(1, 0, fade)
    return x / np.max(np.abs(x))


def frac_delay(x, d):
    n = np.arange(len(x) + int(np.ceil(d)) + 2)
    return np.interp(n - d, np.arange(len(x)), x, left=0.0, right=0.0)


def brightness_code(y, az, fc=2000.0):
    """Front/back cue: high frequencies boosted for sources in front (top of the
    screen) and cut for sources behind (bottom), varying smoothly with angle.
    About +8 dB above 2 kHz straight ahead, near 0 dB at the sides, -20 dB behind."""
    g = 1.6 - 2.5 * abs(az) / 180.0
    b, a = butter(2, fc / (FS / 2), "high")
    out = np.empty_like(y)
    for ch in range(y.shape[1]):
        out[:, ch] = y[:, ch] + g * lfilter(b, a, y[:, ch])
    return out


def analytic_binaural(x, az, head_radius=0.0875, c=343.0, enhanced=True):
    """Woodworth ITD + head-shadow ILD from the lateral angle. Enhanced mode
    exaggerates both so that neighbouring slots differ more."""
    if abs(az) < 0.5 or abs(abs(az) - 180) < 0.5:
        return np.stack([x, x], axis=1), 0.0
    lateral = abs(az) if abs(az) <= 90 else 180 - abs(az)
    theta = np.deg2rad(lateral)
    itd = head_radius / c * (theta + np.sin(theta)) * (1.3 if enhanced else 1.0)
    near_gain = 10 ** ((2.0 if enhanced else 1.5) * np.sin(theta) / 20)
    far_gain = 10 ** ((-14.0 if enhanced else -6.0) * np.sin(theta) / 20)
    fc = 18000 * (1 - 0.8 * np.sin(theta)) + 1500
    b, a = butter(1, min(fc, FS / 2 - 100) / (FS / 2), "low")
    near = x * near_gain
    far = frac_delay(lfilter(b, a, x) * far_gain, itd * FS)
    near = np.concatenate([near, np.zeros(len(far) - len(near))])
    left, right = (near, far) if az > 0 else (far, near)
    return np.stack([left, right], axis=1), itd


def sofa_binaural(x, az, sofa_path):
    import h5py
    with h5py.File(sofa_path, "r") as f:
        ir = np.array(f["Data.IR"])
        pos = np.array(f["SourcePosition"])
        sr = float(np.array(f["Data.SamplingRate"]).ravel()[0])
    a = np.mod(pos[:, 0], 360)
    t = np.mod(az, 360)
    daz = np.minimum(np.abs(a - t), 360 - np.abs(a - t))
    idx = int(np.argmin(daz ** 2 + (pos[:, 1] * 2) ** 2))
    h = ir[idx]
    if sr != FS:
        h = np.stack([resample_poly(h[0], FS, int(sr)), resample_poly(h[1], FS, int(sr))])
    cc = np.correlate(h[0], h[1], mode="full")
    itd = abs((np.argmax(np.abs(cc)) - (len(h[1]) - 1)) / FS)
    return (np.stack([fftconvolve(x, h[0]), fftconvolve(x, h[1])], axis=1), itd,
            {"measured_az": float(pos[idx, 0]), "measured_el": float(pos[idx, 1])})


def diffuse_echo(x, rt60=0.2, predelay_ms=12, seed=11):
    rng = np.random.default_rng(seed)
    n = int(rt60 * FS)
    env = np.exp(-6.9 * np.arange(n) / FS / rt60)
    b, a = butter(2, 4000 / (FS / 2), "low")
    pre = np.zeros(int(predelay_ms / 1000 * FS))
    chans = []
    for _ in range(2):
        ir = np.concatenate([pre, lfilter(b, a, rng.standard_normal(n)) * env])
        w = fftconvolve(x, ir)
        chans.append(w / np.sqrt(np.mean(w ** 2)))
    return np.stack(chans, axis=1)


def ambience(seconds=20, seed=5):
    """Low station hum: 55 Hz drone with soft filtered noise, seamless loop, mono in both channels."""
    rng = np.random.default_rng(seed)
    n = seconds * FS
    t = np.arange(n) / FS
    hum = 0.5 * np.sin(2 * np.pi * 55 * t) + 0.25 * np.sin(2 * np.pi * 110 * t) + 0.1 * np.sin(2 * np.pi * 165 * t)
    hum *= 1 + 0.15 * np.sin(2 * np.pi * 0.25 * t)
    b, a = butter(2, 600 / (FS / 2), "low")
    noise = lfilter(b, a, rng.standard_normal(n + FS))
    loop = noise[:n].copy()
    loop[:FS] = noise[:FS] * np.linspace(0, 1, FS) + noise[n:n + FS] * np.linspace(1, 0, FS)
    mono = hum + 0.6 * loop / np.max(np.abs(loop))
    st = np.stack([mono, mono], axis=1)
    return st / np.max(np.abs(st)) * 10 ** (-6 / 20)


def sfx():
    """Synthesized mono effects (fallbacks for the optional Kenney Sci-fi Sounds)."""
    rng = np.random.default_rng(3)
    out = {}
    # laser: fast downward chirp
    n = int(0.14 * FS); t = np.arange(n) / FS
    f = 1800 * np.exp(-t / 0.05) + 300
    ph = 2 * np.pi * np.cumsum(f) / FS
    x = (np.sign(np.sin(ph)) * 0.5 + np.sin(ph)) * np.exp(-t / 0.05)
    out["laser"] = x
    # explosion: noise burst, low-passed, with a thump
    n = int(0.6 * FS); t = np.arange(n) / FS
    b, a = butter(2, 1500 / (FS / 2), "low")
    x = lfilter(b, a, rng.standard_normal(n)) * np.exp(-t / 0.15)
    x += 1.5 * np.sin(2 * np.pi * (70 * np.exp(-t / 0.2) + 40) * t) * np.exp(-t / 0.12)
    out["explosion"] = x
    # shield hit: buzzy low tone
    n = int(0.35 * FS); t = np.arange(n) / FS
    x = np.sign(np.sin(2 * np.pi * 90 * t)) * 0.6 * np.exp(-t / 0.12) + 0.4 * np.sin(2 * np.pi * 45 * t) * np.exp(-t / 0.2)
    out["shield"] = x
    for k, v in out.items():
        v = v / np.max(np.abs(v)) * 10 ** (-3 / 20)
        fade = int(0.01 * FS)
        v[-fade:] *= np.linspace(1, 0, fade)
        out[k] = v
    return out


def rms_db(x):
    return float(20 * np.log10(np.sqrt(np.mean(np.square(x))) + 1e-12))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--sofa", help="SOFA HRIR file (e.g. SADIE II D2 KEMAR 48 kHz)")
    ap.add_argument("--tap", default=DEFAULT_TAP, help="recording of a single strike (wav/ogg/flac)")
    ap.add_argument("--pitch", type=float, default=0.75, help="pitch factor for the strike (0.5 = one octave lower)")
    ap.add_argument("--drive", type=float, default=2.5, help="soft saturation amount (0 = off); makes the strike louder at the same peak")
    ap.add_argument("--lowpass", type=float, default=5000.0, help="low-pass filter on the strike (Hz); 0 disables")
    ap.add_argument("--thump-db", type=float, default=-3.0, help="level of the low thump mixed into each strike (dB re strike); -inf disables")
    ap.add_argument("--max-ms", type=float, default=280, help="length of one strike")
    ap.add_argument("--taps", type=int, default=1, help="number of strikes in the cue")
    ap.add_argument("--tap-gap-ms", type=float, default=160, help="onset-to-onset interval between strikes")
    ap.add_argument("--natural", action="store_true", help="realistic (not exaggerated) ITD/ILD in analytic mode")
    ap.add_argument("--no-fb-code", action="store_true", help="disable the front/back brightness code")
    ap.add_argument("--echo-db", type=float, default=-18.0, help="shared echo level re direct sound (dB); -inf disables")
    ap.add_argument("--max-total-ms", type=float, default=300, help="cue files are cut (with fade) to this length")
    ap.add_argument("--peak-dbfs", type=float, default=-1.0)
    ap.add_argument("--config", default=os.path.join(ROOT, "config", "experiment.cfg"))
    ap.add_argument("--step", type=float, default=5.0, help="direction step for audio/stimuli/dir (degrees)")
    args = ap.parse_args()

    angles = read_angles(args.config)
    strike = load_tap(args.tap, args.max_ms, args.pitch, args.thump_db if np.isfinite(args.thump_db) else None, args.drive, args.lowpass or None)
    gap = int(args.tap_gap_ms / 1000 * FS)
    tap = np.zeros(gap * (args.taps - 1) + len(strike))
    for k in range(args.taps):
        tap[k * gap: k * gap + len(strike)] += strike * (1.0 if k == 0 else 0.9)
    tap /= np.max(np.abs(tap))
    echo = diffuse_echo(tap) if np.isfinite(args.echo_db) else None
    out_dir = os.path.join(ROOT, "audio", "stimuli")
    os.makedirs(out_dir, exist_ok=True)
    dir_dir = os.path.join(out_dir, "dir")
    os.makedirs(dir_dir, exist_ok=True)
    for old in glob.glob(os.path.join(out_dir, "cue_*.wav")) + glob.glob(os.path.join(dir_dir, "cue_dir_*.wav")):
        os.remove(old)
    n_fixed = len(angles)
    dir_angles = [k * args.step for k in range(int(round(360.0 / args.step)))]
    angles = angles + dir_angles

    report = {"sample_rate": FS,
              "method": "sofa" if args.sofa else ("analytic_natural" if args.natural else "analytic_enhanced_itd_x1.3_ild_16db"),
              "front_back_brightness_code": not args.no_fb_code, "taps": args.taps, "tap_gap_ms": args.tap_gap_ms,
              "sofa_file": os.path.basename(args.sofa) if args.sofa else None,
              "tap_source": os.path.basename(args.tap), "pitch_factor": args.pitch, "thump_db": args.thump_db, "drive": args.drive, "lowpass_hz": args.lowpass, "strike_ms": args.max_ms, "cue_core_ms": round(len(tap) / FS * 1000, 1),
              "echo_level_db": args.echo_db, "angles_deg": angles[:n_fixed], "direction_step_deg": args.step, "slots": []}
    rendered = []
    for k, (ang, az) in enumerate(slot_azimuths(angles)):
        if args.sofa:
            y, itd, extra = sofa_binaural(tap, az, args.sofa)
        else:
            y, itd = analytic_binaural(tap, az, enhanced=not args.natural)
            extra = {}
        if not args.no_fb_code:
            y = brightness_code(y, az)
        if echo is not None:
            mix = np.zeros((max(len(y), len(echo)), 2))
            mix[: len(y)] += y
            mix[: len(echo)] += echo * np.sqrt(np.mean(y ** 2)) * 10 ** (args.echo_db / 20)
            y = mix
        cut = int(args.max_total_ms / 1000 * FS)
        if len(y) > cut:
            y = y[:cut].copy()
        fade = int(0.02 * FS)
        y[-fade:] *= np.linspace(1, 0, fade)[:, None]
        rendered.append(y)
        report["slots"].append({"slot": k, "screen_angle_deg": round(ang, 2), "azimuth_deg": round(az, 2),
                                "itd_us": round(float(itd) * 1e6, 1), **extra})

    gain = 10 ** (args.peak_dbfs / 20) / max(np.max(np.abs(r)) for r in rendered)
    for k, y in enumerate(rendered):
        y = y * gain
        if k >= n_fixed:
            ang = angles[k]
            wavfile.write(os.path.join(dir_dir, "cue_dir_%03d.wav" % int(round(ang))), FS, (y * 32767).astype(np.int16))
            continue
        path = os.path.join(out_dir, "cue_%02d.wav" % k)
        wavfile.write(path, FS, (y * 32767).astype(np.int16))
        report["slots"][k].update({"file": os.path.basename(path), "duration_ms": round(len(y) / FS * 1000, 1),
                                   "rms_dbfs_left": round(rms_db(y[:, 0]), 2), "rms_dbfs_right": round(rms_db(y[:, 1]), 2)})
        print("%s  angle %6.1f  az %6.1f  ITD %5.0f us  L %.1f  R %.1f dBFS" % (
            os.path.basename(path), report["slots"][k]["screen_angle_deg"], report["slots"][k]["azimuth_deg"],
            report["slots"][k]["itd_us"], report["slots"][k]["rms_dbfs_left"], report["slots"][k]["rms_dbfs_right"]))
    print("wrote %d direction files to audio/stimuli/dir/ (every %g degrees)" % (len(dir_angles), args.step))
    report["slots"] = report["slots"][:n_fixed]
    with open(os.path.join(out_dir, "stimuli_report.json"), "w") as f:
        json.dump(report, f, indent=2)

    amb = ambience()
    wavfile.write(os.path.join(ROOT, "audio", "ambience_loop.wav"), FS, (amb * 32767).astype(np.int16))
    print("wrote audio/ambience_loop.wav")
    sfx_dir = os.path.join(ROOT, "audio", "sfx")
    os.makedirs(sfx_dir, exist_ok=True)
    for k, v in sfx().items():
        wavfile.write(os.path.join(sfx_dir, k + ".wav"), FS, (np.stack([v, v], axis=1) * 32767).astype(np.int16))
        print("wrote audio/sfx/%s.wav" % k)
    print("Open the project in Godot afterwards so it re-imports the files.")
    if not args.sofa:
        print("Note: analytic placeholder used. For data collection, render with --sofa.", file=sys.stderr)


if __name__ == "__main__":
    main()
