#!/usr/bin/env python3
r"""Combine the gaze results of all participants (after tools/merge_gaze.py).

Usage (from the game folder):
    python tools/gaze_group.py
    python tools/gaze_group.py --mode live --max-accuracy 3.0 --min-coverage 0.75

Reads every data/*_trials_gaze.csv, *_gaze_validation.csv and
*_gaze_timecourse.csv (autotest sessions are skipped unless --include-autotest).

Writes to analysis/:
    gaze_participants.csv     one row per session: data quality and exclusion
    gaze_trials_all.csv       every robot of every session, with gaze columns
                              (input for mixed-effects models)
    gaze_timecourse_all.csv   50 ms time-course bins of every robot
    gaze_participant_means.csv  per participant x reliability x bang condition
                              (input for repeated-measures analyses)
    gaze_group_first_gaze.png   first gaze to the bang's gate by reliability
    gaze_group_validity.png     cost of an invalid bang by reliability
    gaze_group_timecourse.png   gaze on the bang's / robot's gate over time
    gaze_group_learning.png     following the bang vs the running reliability estimate

Exclusion (per session, reported, never deleted): mean validation accuracy above
--max-accuracy degrees, or mean gaze coverage below --min-coverage. Trials used
for gaze measures: main levels, clean (one robot on screen), gaze_ok.

Group plots show the mean of participant means with +-1 standard error.
Reliability, not level number, is on the x-axis, because the low levels take
different reliabilities for different participants.
"""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent


def parse_args():
    ap = argparse.ArgumentParser(description="Combine gaze results of all participants.")
    ap.add_argument("--data", default=str(ROOT / "data"))
    ap.add_argument("--out", default=str(ROOT / "analysis"))
    ap.add_argument("--mode", default="live", help="live, replay or all (default live)")
    ap.add_argument("--max-accuracy", type=float, default=3.0)
    ap.add_argument("--min-coverage", type=float, default=0.75)
    ap.add_argument("--include-autotest", action="store_true")
    return ap.parse_args()


def mean_se(df, by, col):
    """Mean of participant means and its standard error."""
    g = df.groupby(by)[col]
    return pd.DataFrame({"mean": g.mean(), "se": g.std(ddof=1) / np.sqrt(g.count()), "n": g.count()})


def main():
    a = parse_args()
    data, out = Path(a.data), Path(a.out)
    out.mkdir(exist_ok=True)

    parts, trials, tcs = [], [], []
    for f in sorted(data.glob("*_trials_gaze.csv")):
        base = str(f)[: -len("_trials_gaze.csv")]
        sess_file = Path(base + "_session.json")
        session = json.loads(sess_file.read_text()) if sess_file.exists() else {}
        if session.get("autotest") and not a.include_autotest:
            continue
        name = Path(base).name
        tr = pd.read_csv(f)
        tr["session"] = name
        if a.mode != "all" and tr["mode"].iloc[0] != a.mode:
            continue
        main_tr = tr[tr["block"] != "practice"]
        row = {"session": name, "pid": tr["pid"].iloc[0], "mode": tr["mode"].iloc[0],
               "reliability_condition": tr["reliability_condition"].iloc[0],
               "gaze_coverage": main_tr["gaze_coverage"].mean(),
               "n_trials": len(main_tr),
               "n_clean_good": int(((main_tr["clean"] == 1) & (main_tr["gaze_ok"] == 1)).sum())}
        vf = Path(base + "_gaze_validation.csv")
        if vf.exists():
            v = pd.read_csv(vf)
            v0 = v[v["tag"] == "start"] if (v["tag"] == "start").any() else v
            row.update(val_accuracy_deg=v0["accuracy_deg"].mean(), val_worst_deg=v0["accuracy_deg"].max(),
                       val_precision_rms_deg=v0["rms_s2s_deg"].mean(), val_arrival_ms=v0["arrival_ms"].median(),
                       val_data_loss_pct=v0["data_loss_pct"].mean())
            later = v[v["tag"] != "start"]
            if len(later):
                row["val_accuracy_later_deg"] = later["accuracy_deg"].mean()   # drift check
        parts.append(row)
        trials.append(tr)
        tf = Path(base + "_gaze_timecourse.csv")
        if tf.exists():
            tcs.append(pd.read_csv(tf).assign(session=name))

    if not parts:
        print(f"No merged sessions in {data}. Run tools/merge_gaze.py for each session first.")
        return

    P = pd.DataFrame(parts)
    P["exclude_accuracy"] = (P.get("val_accuracy_deg", pd.Series(np.nan, index=P.index)) > a.max_accuracy).astype(int)
    P["exclude_coverage"] = (P["gaze_coverage"] < a.min_coverage).astype(int)
    P["exclude"] = ((P["exclude_accuracy"] + P["exclude_coverage"]) > 0).astype(int)
    P.round(3).to_csv(out / "gaze_participants.csv", index=False)

    T = pd.concat(trials, ignore_index=True).merge(P[["session", "exclude"]], on="session")
    T.to_csv(out / "gaze_trials_all.csv", index=False)
    if tcs:
        TC = pd.concat(tcs, ignore_index=True).merge(P[["session", "exclude"]], on="session")
        TC.to_csv(out / "gaze_timecourse_all.csv", index=False)

    print(f"{len(P)} sessions ({a.mode}); excluded {int(P['exclude'].sum())} "
          f"(accuracy > {a.max_accuracy} deg: {int(P['exclude_accuracy'].sum())}, "
          f"coverage < {a.min_coverage:.0%}: {int(P['exclude_coverage'].sum())})")
    cols = [c for c in ["pid", "val_accuracy_deg", "val_precision_rms_deg", "val_arrival_ms",
                        "gaze_coverage", "n_clean_good", "exclude"] if c in P]
    print(P[cols].round(2).to_string(index=False))

    # ---- analysed trials and participant means ----
    A = T[(T["exclude"] == 0) & (T["block"] != "practice") & (T["clean"] == 1) & (T["gaze_ok"] == 1)].copy()
    if A.empty:
        print("No trials left after exclusion.")
        return
    A["rel_pct"] = (100 * A["reliability"]).round().astype(int)
    measures = ["first_gaze_to_sound", "first_gaze_to_target", "first_gaze_to_sensor",
                "first_gaze_before_emerge", "first_gaze_ms", "gaze_to_target_ms", "target_after_emerge_ms",
                "dwell_sound_pct", "dwell_target_pct", "dwell_sensor_pct", "dwell_centre_pct",
                "pre_cue_centre_pct", "pre_cue_sensor_gate_pct", "at_cue_on_sensor_gate",
                "n_gate_switches", "visited_wrong_gate", "gaze_aim_lead_ms", "gaze_aim_same_gate"]
    measures = [m for m in measures if m in A]
    PM = A.groupby(["pid", "rel_pct", "audio_cond"])[measures].mean()
    PM.insert(0, "n_trials", A.groupby(["pid", "rel_pct", "audio_cond"]).size())
    conf = A[A["cue_sensor"] == "conflict"].groupby(["pid", "rel_pct"])[["first_gaze_to_sound", "first_gaze_to_sensor"]].mean()
    conf.columns = ["conflict_followed_sound", "conflict_followed_sensor"]
    PM = PM.reset_index().merge(conf.reset_index(), on=["pid", "rel_pct"], how="left")
    PM.round(3).to_csv(out / "gaze_participant_means.csv", index=False)

    rels = sorted(A["rel_pct"].unique(), reverse=True)
    xlab = [f"{r}%" for r in rels]
    n_p = A["pid"].nunique()

    # 1. first gaze to the bang's gate
    fig, ax = plt.subplots(figsize=(8, 4.8))
    for i, c in enumerate(["valid", "invalid"]):
        s = mean_se(PM[PM["audio_cond"] == c], "rel_pct", "first_gaze_to_sound").reindex(rels)
        xs = np.arange(len(rels)) + (i - 0.5) * 0.38
        ax.bar(xs, 100 * s["mean"], 0.38, yerr=100 * s["se"], capsize=3, label=f"{c} bang")
    s = mean_se(PM.dropna(subset=["conflict_followed_sound"]).drop_duplicates(["pid", "rel_pct"]),
                "rel_pct", "conflict_followed_sound").reindex(rels)
    ax.errorbar(np.arange(len(rels)), 100 * s["mean"], yerr=100 * s["se"], fmt="ko-", ms=5,
                label="conflict trials: followed bang over blip")
    ax.axhline(100 / 3, color="0.6", ls=":", lw=1)
    ax.set_xticks(range(len(rels)), xlab)
    ax.set_xlabel("bang reliability")
    ax.set_ylabel("first gaze to the bang's gate (%)")
    ax.set_ylim(0, 110)
    ax.legend(frameon=False, fontsize=8)
    ax.set_title(f"Following the bang ({n_p} participants, mean ± SE)")
    fig.savefig(out / "gaze_group_first_gaze.png", dpi=150, bbox_inches="tight")
    plt.close(fig)

    # 2. validity cost: invalid minus valid time to the robot's gate, per participant
    w = PM.pivot_table(index=["pid", "rel_pct"], columns="audio_cond", values="gaze_to_target_ms")
    if {"valid", "invalid"} <= set(w.columns):
        w["cost"] = w["invalid"] - w["valid"]
        w = w.dropna(subset=["cost"]).reset_index()
        fig, ax = plt.subplots(figsize=(7, 4.5))
        rl = [r for r in rels if r in set(w["rel_pct"])]
        for k, r in enumerate(rl):
            v = w[w["rel_pct"] == r]["cost"]
            ax.scatter(np.full(len(v), k) + np.random.default_rng(k).uniform(-0.08, 0.08, len(v)), v, s=14, color="0.6")
            ax.errorbar(k, v.mean(), yerr=v.std(ddof=1) / np.sqrt(len(v)) if len(v) > 1 else 0, fmt="o", color="C3", ms=8, capsize=4)
        ax.axhline(0, color="0.5", lw=0.8)
        ax.set_xticks(range(len(rl)), [f"{r}%" for r in rl])
        ax.set_xlabel("bang reliability (levels with invalid bangs)")
        ax.set_ylabel("invalid − valid: time for eyes to reach robot (ms)")
        ax.set_title("Cost of a wrong bang (dots: participants)")
        fig.savefig(out / "gaze_group_validity.png", dpi=150, bbox_inches="tight")
        plt.close(fig)

    # 3. time course, participant means
    if tcs:
        D = TC[(TC["exclude"] == 0) & (TC["clean"] == 1) & (TC["gaze_ok"] == 1) & (TC["epoch"] > 0)].copy()
        D["rel_pct"] = (100 * D["reliability"]).round().astype(int)
        fig, axes = plt.subplots(1, len(rels), figsize=(3.8 * len(rels), 3.8), sharey=True, squeeze=False)
        for ax, r in zip(axes[0], rels):
            d = D[D["rel_pct"] == r]
            for c, col, style, lab in [("valid", "on_sound", "-", "valid: bang's gate"),
                                       ("invalid", "on_sound", "--", "invalid: bang's gate"),
                                       ("invalid", "on_target", ":", "invalid: robot's gate")]:
                pm = d[d["audio_cond"] == c].groupby(["pid", "bin_ms"])[col].mean().reset_index()
                if pm.empty:
                    continue
                s = mean_se(pm, "bin_ms", col)
                x = s.index + 25
                ax.plot(x, 100 * s["mean"], style, label=lab)
                ax.fill_between(x, 100 * (s["mean"] - s["se"]), 100 * (s["mean"] + s["se"]), alpha=0.15)
            ax.axvline(0, color="0.5", lw=0.8)
            ax.axvline(300, color="0.5", lw=0.8, ls=":")
            ax.set_title(f"{r}% reliable", fontsize=10)
            ax.set_xlabel("ms from bang (robot at 300)")
        axes[0][0].set_ylabel("% of gaze samples")
        axes[0][0].set_ylim(0, 105)
        axes[0][-1].legend(frameon=False, fontsize=8, loc="upper right")
        fig.suptitle(f"Where the eyes were after the bang ({n_p} participants, mean ± SE)")
        fig.tight_layout()
        fig.savefig(out / "gaze_group_timecourse.png", dpi=150, bbox_inches="tight")
        plt.close(fig)

    # 4. learning: following the bang vs the running reliability estimate (low levels)
    L = A[(A["reliability"] < 1) & A["audio_cond"].isin(["valid", "invalid"]) & A["r_hat"].notna()].copy()
    if len(L) > 10:
        L["r_bin"] = pd.cut(L["r_hat"], np.linspace(0, 1, 6), include_lowest=True)
        pm = L.groupby(["pid", "r_bin"], observed=True)["first_gaze_to_sound"].mean().reset_index()
        s = mean_se(pm, "r_bin", "first_gaze_to_sound")
        fig, ax = plt.subplots(figsize=(6.5, 4.5))
        mids = [iv.mid for iv in s.index]
        ax.errorbar(mids, 100 * s["mean"], yerr=100 * s["se"], fmt="o-", capsize=3)
        ax.plot([0, 1], [0, 100], color="0.7", ls=":", lw=1, label="matching")
        ax.set_xlabel("running estimate of bang reliability (r_hat) before the robot")
        ax.set_ylabel("first gaze to the bang's gate (%)")
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 105)
        ax.legend(frameon=False, fontsize=8)
        ax.set_title("Do the eyes track how reliable the bang has been?")
        fig.savefig(out / "gaze_group_learning.png", dpi=150, bbox_inches="tight")
        plt.close(fig)

    print(f"\nSaved to {out}: gaze_participants.csv, gaze_trials_all.csv, gaze_timecourse_all.csv, "
          "gaze_participant_means.csv and four gaze_group_*.png plots")


if __name__ == "__main__":
    main()
