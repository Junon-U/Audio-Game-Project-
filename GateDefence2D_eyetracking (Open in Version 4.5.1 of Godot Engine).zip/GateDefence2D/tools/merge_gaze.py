#!/usr/bin/env python3
r"""Merge a Tobii Eye Tracker 5 recording (enhanced-tobii-eyetracker) with a
Gate Defence session, and compute gaze measures per robot.

Both programs run on the same PC. The game logs every event with the PC clock
(unix_time in *_events.csv); eyeTrack.exe logs every gaze sample with the PC
clock (human_time) and the tracker clock (tobii_timestamp_us). Matching the
two PC clocks puts gaze on the game's timeline (t_us).

Usage (from the game folder):
    python tools/merge_gaze.py                     # newest session in data/
    python tools/merge_gaze.py data/P001_live_2026-10-20_15-30-47_events.csv
Options:
    --gaze-dir DIR        folder with gaze_data_*.txt
                          (default: Documents/enhanced-tobii-eyetracker/data)
    --screen-cm W H       visible screen size in cm (default 34.5 21.5)
    --distance-cm D       eye-to-screen distance (default 50)
    --screen-px W H       screen resolution, if not in _session.json
    --centre-radius PX    gaze closer than this to the player counts as
                          "centre", not a gate (game pixels, default 200)

Then combine participants with: python tools/gaze_group.py

Writes next to the session files:
    *_gaze.csv              every gaze sample on the game clock, in game pixels
    *_gaze_validation.csv   accuracy, precision and arrival time per validation dot
    *_trials_gaze.csv       the trials file plus the gaze columns below
    *_gaze_timecourse.csv   share of gaze on each gate role, 50 ms bins from the bang
    *_gaze_conditions.csv   per level and bang condition: the main measures
    *_gaze_heatmap.png      where players looked after the bangs
    *_gaze_summary.png      first gaze to the bang's gate, per level and condition
    *_gaze_timecourse.png   gaze on the bang's and the robot's gate over time
    *_gaze_validity.png     time for the eyes to reach the robot, valid vs invalid bang

Gate areas: the left, top and right quarters around the player, beyond the
centre radius. Codes as in the game: 0 left, 1 ahead, 2 right, -1 bottom,
-2 centre (player and tracker ring). Times in ms from the bang; for silent
robots, from when the bang would have been.

GAZE COLUMNS
  Data quality
    gaze_n, gaze_coverage       samples in the 1.5 s after the bang; share of expected
    gaze_ok                     1 if coverage >= 0.5 and gaze was recorded at the bang
  Before the bang (blip on screen, bang not yet heard)
    pre_cue_centre_pct          % of samples on the player / tracker ring
    pre_cue_sensor_gate_pct     % of samples on the gate the blip points to
    gaze_gate_at_cue            gate area at the bang
    at_cue_on_sensor_gate       1 if that was the blip's gate (acted on the blip early)
  First gaze shift after the bang
    first_gaze_gate, first_gaze_ms
    first_gaze_before_emerge    1 if before the robot appeared (anticipatory)
    first_gaze_to_sound / _target / _sensor
  Reaching the robot
    gaze_to_target_ms           first time the eyes were on the robot's gate (0 if already there)
    target_after_emerge_ms      same, from the robot's appearance (negative = before it)
    gaze_gate_at_emerge
  Dwell, bang to 600 ms after it (the robot appears at 300 ms)
    dwell_sound_pct, dwell_target_pct, dwell_sensor_pct, dwell_centre_pct
  Search
    n_gate_switches             changes between gate areas in the 1.5 s after the bang
    visited_wrong_gate          1 if the eyes went to a gate other than the robot's
  Eyes and hands (live mode)
    gaze_aim_lead_ms            first aim time minus first gaze time (positive = eyes first)
    gaze_aim_same_gate          1 if first gaze and first aim went to the same gate
  Trial type
    clean                       no other robot on screen at bang or appearance
"""
import argparse
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

REF_W, REF_H = 1920.0, 1080.0
WINDOW_MS = 1500        # analysis window after the bang
DWELL_MS = 600          # dwell window after the bang
BIN_MS = 50             # time-course bins
TC_FROM, TC_TO = -300, 1500


def parse_args():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("events", nargs="?", help="session *_events.csv (default: newest)")
    ap.add_argument("--gaze-dir", default=str(Path.home() / "Documents" / "enhanced-tobii-eyetracker" / "data"))
    ap.add_argument("--screen-cm", nargs=2, type=float, default=[34.5, 21.5])
    ap.add_argument("--distance-cm", type=float, default=50.0)
    ap.add_argument("--screen-px", nargs=2, type=int)
    ap.add_argument("--centre-radius", type=float, default=200.0)
    return ap.parse_args()


def find_session(arg):
    if arg:
        p = Path(arg)
    else:
        data = Path(__file__).resolve().parent.parent / "data"
        files = sorted(data.glob("*_events.csv"), key=lambda f: f.stat().st_mtime)
        if not files:
            sys.exit(f"No *_events.csv in {data}")
        p = files[-1]
    return Path(str(p)[: -len("_events.csv")])


def local_to_unix_us(series):
    """'YYYY-MM-DD HH:MM:SS.mmm' in local time -> unix microseconds."""
    naive = pd.to_datetime(series, format="%Y-%m-%d %H:%M:%S.%f")
    as_utc_us = (naive - pd.Timestamp("1970-01-01")) // pd.Timedelta("1us")
    # datetime.timestamp() reads a naive time as local time, which gives the UTC offset
    first = naive.iloc[0].to_pydatetime()
    offset_us = round(first.timestamp() * 1e6) - int(as_utc_us.iloc[0])
    return as_utc_us + offset_us


def load_gaze(gaze_dir, start_unix, end_unix):
    """Pick the gaze file that covers most of the session."""
    best, best_overlap = None, 0.0
    for f in Path(gaze_dir).glob("gaze_data_*.txt"):
        try:
            g = pd.read_csv(f, sep="\t")
        except Exception:
            continue
        if len(g) < 10:
            continue
        g["wall_us"] = local_to_unix_us(g["human_time"])
        lo, hi = g["wall_us"].min() / 1e6, g["wall_us"].max() / 1e6
        overlap = max(0.0, min(hi, end_unix) - max(lo, start_unix))
        if overlap > best_overlap:
            best, best_overlap = (f, g), overlap
    if best is None or best_overlap < 0.5 * (end_unix - start_unix):
        sys.exit("No gaze recording covers this session. Was eyeTrack.exe running before the game "
                 f"started? Looked in: {gaze_dir}")
    return best


def pct(mask):
    return 100.0 * float(np.mean(mask)) if len(mask) else np.nan


def main():
    a = parse_args()
    base = find_session(a.events)
    events = pd.read_csv(f"{base}_events.csv")
    trials = pd.read_csv(f"{base}_trials.csv")
    session = json.loads(Path(f"{base}_session.json").read_text())
    time_scale = 0.1 if session.get("autotest") else 1.0     # autotest runs 10x fast
    ms = lambda v: v * 1000 * time_scale                      # experiment ms -> game us
    to_ms = lambda us: us / 1000 / time_scale                 # game us -> experiment ms
    print(f"session: {base.name}")

    # ---- 1. clocks: game t_us -> unix; tracker -> unix -> game t_us ----
    events["unix_us"] = (events["unix_time"] * 1e6).round()
    game_off = np.median(events["unix_us"] - events["t_us"])
    gaze_file, gaze = load_gaze(a.gaze_dir, events["unix_time"].min(), events["unix_time"].max())
    t0 = gaze["tobii_timestamp_us"].iloc[0]
    steady = gaze[gaze["tobii_timestamp_us"] > t0 + 1_000_000]      # skip buffered start burst
    tobii_off = np.median(steady["wall_us"] - steady["tobii_timestamp_us"])
    gaze["t_us"] = gaze["tobii_timestamp_us"] + tobii_off - game_off
    gaze = gaze.sort_values("t_us").reset_index(drop=True)
    rate = 1e6 / np.median(np.diff(gaze["tobii_timestamp_us"])) * time_scale
    print(f"gaze:    {gaze_file.name}  ({rate:.1f} Hz)")

    # ---- 2. screen (normalised) -> game reference frame (1920x1080 pixels) ----
    if a.screen_px:
        sw, sh = a.screen_px
    elif session.get("screen_px") and min(session["screen_px"]) > 100:
        sw, sh = session["screen_px"]
    else:
        sys.exit("Screen resolution unknown: pass --screen-px, e.g. --screen-px 2560 1600")
    if session.get("fullscreen") is False:
        print("WARNING: the game was not fullscreen; gaze positions will be wrong.")
    scale = min(sw / REF_W, sh / REF_H)
    off_x, off_y = (sw - REF_W * scale) / 2, (sh - REF_H * scale) / 2
    gaze["x"] = (gaze["x_position"] * sw - off_x) / scale
    gaze["y"] = (gaze["y_position"] * sh - off_y) / scale
    cm_per_ref = (a.screen_cm[0] / sw) * scale

    def to_eye(x, y):
        """Game pixels -> unit vectors from the eye (eye opposite screen centre)."""
        sx = (np.asarray(x, float) * scale + off_x - sw / 2) / scale * cm_per_ref
        sy = (np.asarray(y, float) * scale + off_y - sh / 2) / scale * cm_per_ref
        v = np.stack([sx, sy, np.full_like(sx, a.distance_cm)], -1)
        return v / np.linalg.norm(v, axis=-1, keepdims=True)

    def angle_deg(x1, y1, x2, y2):
        d = np.clip(np.sum(to_eye(x1, y1) * to_eye(x2, y2), axis=-1), -1, 1)
        return np.degrees(np.arccos(d))

    cx, cy = session.get("centre_px", [960, 540])
    dx, dy = gaze["x"] - cx, gaze["y"] - cy
    ang = (np.degrees(np.arctan2(dx, -dy)) + 360) % 360     # clockwise from up
    sector = np.select([(ang >= 315) | (ang < 45), (ang >= 45) & (ang < 135),
                        (ang >= 225) & (ang < 315)], [1, 2, 0], default=-1)
    gaze["gate"] = np.where(np.hypot(dx, dy) < a.centre_radius, -2, sector)

    gaze_out = gaze[["t_us", "x", "y", "gate"]].copy()
    gaze_out.insert(1, "unix_time", (gaze["t_us"] + game_off) / 1e6)
    gaze_out.round({"x": 1, "y": 1, "unix_time": 6}).to_csv(f"{base}_gaze.csv", index=False)

    t = gaze["t_us"].to_numpy()
    gx, gy, ggate = gaze["x"].to_numpy(), gaze["y"].to_numpy(), gaze["gate"].to_numpy()

    def window(start_us, end_us):
        i, j = np.searchsorted(t, [start_us, end_us])
        return slice(i, j)

    def gate_at(t_us, max_age_ms=100):
        i = np.searchsorted(t, t_us, side="right") - 1
        if i < 0 or (t_us - t[i]) > ms(max_age_ms):
            return np.nan
        return ggate[i]

    # ---- 3. validation dots ----
    vp = events[events["event"] == "validation_point"]
    point_ms = float(session.get("config", {}).get("validation", {}).get("point_ms", 1200))
    val_rows = []
    for _, e in vp.iterrows():
        d = json.loads(e["details"])
        w = window(e["t_us"] + ms(400), e["t_us"] + ms(point_ms - 50))
        row = {"tag": d["tag"], "index": d["index"], "x_target": d["x"], "y_target": d["y"],
               "n_samples": w.stop - w.start,
               "expected": round((point_ms - 450) / 1000 * rate)}
        if row["n_samples"] > 0:
            mx, my = gx[w].mean(), gy[w].mean()
            row.update(mean_x=mx, mean_y=my, accuracy_deg=float(angle_deg(mx, my, d["x"], d["y"])))
            s2s = angle_deg(gx[w][:-1], gy[w][:-1], gx[w][1:], gy[w][1:])
            row["rms_s2s_deg"] = float(np.sqrt(np.mean(s2s ** 2))) if len(s2s) else np.nan
            row["std_deg"] = float(np.sqrt(np.mean(angle_deg(gx[w], gy[w], mx, my) ** 2)))
            w2 = window(e["t_us"], e["t_us"] + ms(point_ms))
            near = np.nonzero(angle_deg(gx[w2], gy[w2], d["x"], d["y"]) < 3.0)[0]
            row["arrival_ms"] = to_ms(t[w2][near[0]] - e["t_us"]) if len(near) else np.nan
        val_rows.append(row)
    val = pd.DataFrame(val_rows)
    if len(val):
        val["data_loss_pct"] = (100 * (1 - val["n_samples"] / val["expected"])).clip(0, 100)
        val.round(3).to_csv(f"{base}_gaze_validation.csv", index=False)
        for tag, v in val.groupby("tag"):
            print(f"validation '{tag}': accuracy {v['accuracy_deg'].mean():.2f} deg mean, "
                  f"{v['accuracy_deg'].max():.2f} worst; precision {v['rms_s2s_deg'].mean():.3f} deg RMS-S2S; "
                  f"eyes reached the dot after {v['arrival_ms'].median():.0f} ms (median)")

    # ---- 4. gaze per robot ----
    tr = trials.copy()
    cue_t = tr["t_cue_us"].astype(float).copy()
    silent = cue_t.isna()
    cue_t[silent] = tr.loc[silent, "t_emerge_us"] - ms(tr.loc[silent, "soa_ms"].fillna(300))
    expected = rate * WINDOW_MS / 1000
    rows, tc_rows = [], []
    for i, r in tr.iterrows():
        tc, te, ts = cue_t[i], float(r["t_emerge_us"]), float(r["t_scene_us"])
        out = {}
        if np.isnan(tc):
            rows.append(out)
            continue
        cue_g = r["cue_gate"] if r["cue_gate"] >= 0 else np.nan
        tgt_g, sen_g = r["correct_gate"], r["sensor_gate"]
        w = window(tc, tc + ms(WINDOW_MS))
        gw, tw = ggate[w], t[w]
        at_cue = gate_at(tc)
        out["gaze_n"] = len(gw)
        out["gaze_coverage"] = min(1.0, len(gw) / expected)
        out["gaze_ok"] = int(out["gaze_coverage"] >= 0.5 and not np.isnan(at_cue))

        # before the bang
        if not np.isnan(ts) and tc > ts:
            wp = ggate[window(ts, tc)]
            out["pre_cue_centre_pct"] = pct(wp == -2)
            out["pre_cue_sensor_gate_pct"] = pct(wp == sen_g)
        out["gaze_gate_at_cue"] = at_cue
        out["at_cue_on_sensor_gate"] = np.nan if np.isnan(at_cue) else int(at_cue == sen_g)

        # first shift to a gate after the bang
        moved = np.nonzero((gw >= 0) & (gw != at_cue))[0]
        if len(moved):
            k = moved[0]
            fg = gw[k]
            out["first_gaze_gate"] = fg
            out["first_gaze_ms"] = to_ms(tw[k] - tc)
            out["first_gaze_before_emerge"] = int(tw[k] < te) if not np.isnan(te) else np.nan
            out["first_gaze_to_sound"] = np.nan if np.isnan(cue_g) else int(fg == cue_g)
            out["first_gaze_to_target"] = int(fg == tgt_g)
            out["first_gaze_to_sensor"] = int(fg == sen_g)

        # reaching the robot's gate
        if at_cue == tgt_g:
            out["gaze_to_target_ms"] = 0.0
        else:
            on_t = np.nonzero(gw == tgt_g)[0]
            if len(on_t):
                out["gaze_to_target_ms"] = to_ms(tw[on_t[0]] - tc)
        if "gaze_to_target_ms" in out and not np.isnan(te):
            out["target_after_emerge_ms"] = out["gaze_to_target_ms"] - to_ms(te - tc)
        out["gaze_gate_at_emerge"] = gate_at(te) if not np.isnan(te) else np.nan

        # dwell, bang to 600 ms
        gd = ggate[window(tc, tc + ms(DWELL_MS))]
        if len(gd):
            out["dwell_sound_pct"] = np.nan if np.isnan(cue_g) else pct(gd == cue_g)
            out["dwell_target_pct"] = pct(gd == tgt_g)
            out["dwell_sensor_pct"] = pct(gd == sen_g)
            out["dwell_centre_pct"] = pct(gd == -2)

        # search
        gates_only = gw[gw >= 0]
        out["n_gate_switches"] = int(np.sum(gates_only[1:] != gates_only[:-1])) if len(gates_only) else 0
        out["visited_wrong_gate"] = int(np.any((gw >= 0) & (gw != tgt_g)))

        # eyes and hands
        if r.get("mode") == "live" and "first_gaze_ms" in out and not pd.isna(r.get("first_aim_ms")):
            out["gaze_aim_lead_ms"] = float(r["first_aim_ms"]) - out["first_gaze_ms"]
            out["gaze_aim_same_gate"] = int(out["first_gaze_gate"] == r["first_aim_gate"])
        rows.append(out)

        # time course: share of samples on each role per 50 ms bin
        wt = window(tc + ms(TC_FROM), tc + ms(TC_TO))
        rel = to_ms(t[wt] - tc)
        bins = (np.floor(rel / BIN_MS) * BIN_MS).astype(int)
        gt = ggate[wt]
        for b in np.unique(bins):
            m = bins == b
            tc_rows.append({"trial_global": r["trial_global"], "bin_ms": b, "n": int(m.sum()),
                            "on_sound": np.nan if np.isnan(cue_g) else float(np.mean(gt[m] == cue_g)),
                            "on_target": float(np.mean(gt[m] == tgt_g)),
                            "on_sensor": float(np.mean(gt[m] == sen_g)),
                            "on_centre": float(np.mean(gt[m] == -2))})

    tr = pd.concat([tr, pd.DataFrame(rows, index=tr.index)], axis=1)
    tr["clean"] = ((tr["others_alive_at_cue"] == 0) & (tr["others_alive_at_emerge"] == 0)).astype(int)
    tr.to_csv(f"{base}_trials_gaze.csv", index=False)

    keep = ["trial_global", "pid", "mode", "epoch", "reliability", "audio_cond", "visibility",
            "cue_sensor", "r_hat", "clean"]
    tc_df = pd.DataFrame(tc_rows)
    if len(tc_df):
        tc_df = tc_df.merge(tr[keep + ["gaze_ok"]], on="trial_global")
        tc_df.round(4).to_csv(f"{base}_gaze_timecourse.csv", index=False)

    # ---- 5. condition summary (clean trials with good gaze, practice excluded) ----
    an = tr[(tr["block"] != "practice") & (tr["clean"] == 1) & (tr["gaze_ok"] == 1)]
    main_trials = tr[tr["block"] != "practice"]
    print(f"trials:  {len(main_trials)} robots, gaze coverage {100 * main_trials['gaze_coverage'].mean():.0f}%, "
          f"{len(an)} clean with good gaze")

    def summarise(g):
        return pd.Series({
            "n": len(g),
            "first_gaze_to_sound_pct": 100 * g["first_gaze_to_sound"].mean(),
            "first_gaze_to_target_pct": 100 * g["first_gaze_to_target"].mean(),
            "anticipatory_pct": 100 * g["first_gaze_before_emerge"].mean(),
            "first_gaze_ms_median": g["first_gaze_ms"].median(),
            "gaze_to_target_ms_median": g["gaze_to_target_ms"].median(),
            "dwell_sound_pct": g["dwell_sound_pct"].mean(),
            "dwell_target_pct": g["dwell_target_pct"].mean(),
            "n_gate_switches_mean": g["n_gate_switches"].mean(),
            "gaze_aim_lead_ms_median": g["gaze_aim_lead_ms"].median() if "gaze_aim_lead_ms" in g else np.nan,
        })

    if len(an):
        cond = an.groupby(["epoch", "reliability", "audio_cond"]).apply(summarise, include_groups=False).reset_index()
        conf = an[an["cue_sensor"] == "conflict"].groupby(["epoch", "reliability"]).agg(
            conflict_n=("first_gaze_gate", "size"),
            conflict_followed_sound_pct=("first_gaze_to_sound", lambda s: 100 * s.mean()),
            conflict_followed_sensor_pct=("first_gaze_to_sensor", lambda s: 100 * s.mean())).reset_index()
        cond = cond.merge(conf, on=["epoch", "reliability"], how="left")
        num = [c for c in cond.columns if c not in ("epoch", "reliability", "audio_cond")]
        cond[num] = cond[num].round(1)
        cond.to_csv(f"{base}_gaze_conditions.csv", index=False)
        with pd.option_context("display.width", 200, "display.max_columns", 30):
            print("\n" + cond[["epoch", "reliability", "audio_cond", "n", "first_gaze_to_sound_pct",
                               "anticipatory_pct", "gaze_to_target_ms_median",
                               "conflict_followed_sound_pct"]].to_string(index=False))

    # ---- 6. plots ----
    levels = sorted(an["epoch"].unique()) if len(an) else []
    rel = an.groupby("epoch")["reliability"].first() if len(an) else pd.Series(dtype=float)
    lvl_label = lambda e: f"Level {e}\n{100 * rel[e]:.0f}% reliable"

    # heatmap
    in_trials = np.zeros(len(t), bool)
    for tc in cue_t.dropna():
        in_trials[window(tc, tc + ms(WINDOW_MS))] = True
    fig, ax = plt.subplots(figsize=(12, 7))
    h = ax.hist2d(gx[in_trials], gy[in_trials], bins=[96, 54], range=[[0, REF_W], [0, REF_H]],
                  cmap="magma", cmin=1)
    fig.colorbar(h[3], ax=ax, label="gaze samples")
    hs = float(session.get("config", {}).get("arena", {}).get("half_size_px", 440))
    ax.add_patch(plt.Rectangle((cx - hs, cy - hs), 2 * hs, 2 * hs, fill=False, ec="0.5", lw=1))
    ax.add_patch(plt.Circle((cx, cy), a.centre_radius, fill=False, ec="0.5", ls="--"))
    for g in session.get("gates", []):
        ax.plot(g["aoi_x"], g["aoi_y"], "c^", ms=12)
        ax.annotate(g["name"], (g["aoi_x"], g["aoi_y"]), xytext=(8, 8), textcoords="offset points", color="c")
    for deg in (45, 135, 225, 315):
        rr = np.radians(deg)
        ax.plot([cx, cx + 900 * np.sin(rr)], [cy, cy - 900 * np.cos(rr)], color="0.6", lw=0.8, ls=":")
    ax.set_xlim(0, REF_W)
    ax.set_ylim(REF_H, 0)
    ax.set_aspect("equal")
    ax.set_title(f"{base.name}: gaze in the 1.5 s after each bang (game pixels)")
    fig.savefig(f"{base}_gaze_heatmap.png", dpi=130, bbox_inches="tight")
    plt.close(fig)

    if not len(an):
        print("No clean trials with good gaze: plots skipped.")
        return

    # first gaze to the bang's gate
    s = an[an["audio_cond"].isin(["valid", "invalid"])].groupby(["epoch", "audio_cond"])["first_gaze_to_sound"].agg(["mean", "count"])
    fig, ax = plt.subplots(figsize=(9, 5))
    for i, c in enumerate(["valid", "invalid"]):
        sub = s.xs(c, level="audio_cond").reindex(levels) if c in s.index.get_level_values(1) else pd.DataFrame(index=levels, columns=["mean", "count"])
        xs = np.arange(len(levels)) + (i - 0.5) * 0.38
        ax.bar(xs, 100 * sub["mean"].astype(float), 0.38, label=f"{c} bang")
        for x, m, n in zip(xs, sub["mean"], sub["count"]):
            if pd.notna(m):
                ax.text(x, 100 * m + 1.5, f"n={int(n)}", ha="center", fontsize=8)
    ax.set_xticks(range(len(levels)), [lvl_label(e) for e in levels])
    ax.set_ylabel("first gaze to the bang's gate (%)")
    ax.set_ylim(0, 110)
    ax.axhline(100 / 3, color="0.6", ls=":", lw=1)
    ax.legend(frameon=False)
    ax.set_title("Do the eyes follow the bang? (clean trials)")
    fig.savefig(f"{base}_gaze_summary.png", dpi=130, bbox_inches="tight")
    plt.close(fig)

    # time course
    tcd = tc_df[(tc_df["clean"] == 1) & (tc_df["gaze_ok"] == 1) & (tc_df["epoch"] > 0)]
    if len(tcd):
        fig, axes = plt.subplots(1, len(levels), figsize=(4 * len(levels), 3.8), sharey=True, squeeze=False)
        for ax, e in zip(axes[0], levels):
            d = tcd[tcd["epoch"] == e]
            for c, col, style, lab in [("valid", "on_sound", "-", "valid: bang's gate (= robot's)"),
                                       ("invalid", "on_sound", "--", "invalid: bang's gate"),
                                       ("invalid", "on_target", ":", "invalid: robot's gate"),
                                       ("silent", "on_target", "-.", "silent: robot's gate")]:
                m = d[d["audio_cond"] == c].groupby("bin_ms")[col].mean()
                if len(m):
                    ax.plot(m.index + BIN_MS / 2, 100 * m.values, style, label=lab)
            ax.axvline(0, color="0.5", lw=0.8)
            ax.axvline(300, color="0.5", lw=0.8, ls=":")
            ax.set_title(lvl_label(e).replace("\n", ", "), fontsize=10)
            ax.set_xlabel("ms from bang (robot at 300)")
        axes[0][0].set_ylabel("% of gaze samples")
        axes[0][0].set_ylim(0, 105)
        axes[0][-1].legend(frameon=False, fontsize=8, loc="upper left")
        fig.suptitle("Where the eyes were after the bang (clean trials)")
        fig.tight_layout()
        fig.savefig(f"{base}_gaze_timecourse.png", dpi=130, bbox_inches="tight")
        plt.close(fig)

    # validity cost: time to the robot's gate, valid vs invalid
    v = an[an["audio_cond"].isin(["valid", "invalid"])].groupby(["epoch", "audio_cond"])["gaze_to_target_ms"].median().unstack()
    if len(v):
        fig, ax = plt.subplots(figsize=(8, 4.5))
        for i, c in enumerate(["valid", "invalid"]):
            if c in v:
                ax.bar(np.arange(len(v)) + (i - 0.5) * 0.38, v[c].reindex(v.index), 0.38, label=f"{c} bang")
        ax.set_xticks(range(len(v)), [lvl_label(e) for e in v.index])
        ax.axhline(300, color="0.5", ls=":", lw=1)
        ax.text(len(v) - 0.5, 305, "robot appears", ha="right", fontsize=8, color="0.4")
        ax.set_ylabel("eyes reach the robot's gate (ms after bang, median)")
        ax.legend(frameon=False)
        ax.set_title("Cost of a wrong bang (clean trials)")
        fig.savefig(f"{base}_gaze_validity.png", dpi=130, bbox_inches="tight")
        plt.close(fig)

    print(f"\nSaved in {base.parent}: _gaze.csv, _gaze_validation.csv, _trials_gaze.csv, "
          f"_gaze_timecourse.csv, _gaze_conditions.csv and four plots")


if __name__ == "__main__":
    main()
