#!/usr/bin/env python3
"""Measure the motion tracker blip's visibility for each visibility level from
the screenshots made with `-- --shots` (data/screenshots/preview_*.png, blip
pointing at the left gate). Reports the blip's luminance contrast against the
floor next to it and the mean screen luminance (0-255 pixel values; confirm
with a photometer).

Usage: python tools/measure_visibility.py [tracker_radius_px] [blip_px]"""
import os
import sys
import numpy as np
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
shots = os.path.join(ROOT, "data", "screenshots")
cx, cy = 960, 540
radius = float(sys.argv[1]) if len(sys.argv) > 1 else 130.0   # tracker_radius_px
blip = float(sys.argv[2]) if len(sys.argv) > 2 else 22.0      # tracker_blip_px
bx = int(cx - radius)
h = int(blip)
for level in ["clear", "faded"]:
    img = np.asarray(Image.open(os.path.join(shots, "preview_%s.png" % level)).convert("L"), float)
    box = img[cy - h: cy + h, bx - h: bx + h]
    mark = box[box > np.percentile(box, 85)].mean()            # brightest part of the blip
    floor = img[cy - h: cy + h, bx - 5 * h: bx - 3 * h].mean()  # floor outside the ring
    print("%-6s blip %.1f  floor %.1f  Weber contrast %.2f  screen mean %.2f" % (
        level, mark, floor, (mark - floor) / max(floor, 1), img.mean()))
