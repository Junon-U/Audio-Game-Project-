#!/usr/bin/env python3
"""Forward Gate Defence event markers (JSON over UDP) to a Lab Streaming Layer
marker stream, so they can be recorded together with the eye tracker in
LabRecorder.

Start this BEFORE the game:
    python tools/lsl_bridge.py
then start LabRecorder and select the streams "GateDefenceMarkers" and your
eye tracker's gaze stream.

Each marker is the JSON message sent by the game, e.g.
    {"event": "cue_on", "trial": 12, "t_us": 81234567, "pid": "P001", "audio_cond": "invalid", "cue_gate": 2}
The LSL timestamp is taken on arrival (localhost UDP adds well under 1 ms).
A local copy is also written to markers_<time>.csv for checking.

Test without the game:  python tools/lsl_bridge.py --selftest
Requires: pip install pylsl
"""
import argparse
import json
import socket
import time

from pylsl import StreamInfo, StreamOutlet, local_clock


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=12345)
    ap.add_argument("--name", default="GateDefenceMarkers")
    ap.add_argument("--selftest", action="store_true", help="send three test markers to ourselves")
    args = ap.parse_args()

    info = StreamInfo(args.name, "Markers", 1, 0, "string", "gatedefence_markers_v1")
    info.desc().append_child_value("source", "Gate Defence (Godot) via UDP")
    outlet = StreamOutlet(info)

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((args.host, args.port))
    sock.settimeout(0.5)

    log_path = time.strftime("markers_%Y%m%d_%H%M%S.csv")
    log = open(log_path, "w", encoding="utf-8")
    log.write("lsl_time,message\n")
    print(f"LSL outlet '{args.name}' ready; listening on udp://{args.host}:{args.port}; log: {log_path}")

    if args.selftest:
        tx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        for i in range(3):
            tx.sendto(json.dumps({"event": "selftest", "trial": i}).encode(), (args.host, args.port))

    # pylsl calls stay on the main thread (required on Linux).
    try:
        while True:
            try:
                data, _ = sock.recvfrom(65535)
            except socket.timeout:
                continue
            ts = local_clock()
            msg = data.decode("utf-8", errors="replace")
            outlet.push_sample([msg], ts)
            log.write(f"{ts:.6f},\"{msg.replace(chr(34), chr(34) * 2)}\"\n")
            log.flush()
            try:
                ev = json.loads(msg)
                print(f"{ts:.3f}  {ev.get('event')}  trial={ev.get('trial')}")
            except json.JSONDecodeError:
                print(f"{ts:.3f}  {msg}")
    except KeyboardInterrupt:
        pass
    finally:
        log.close()
        sock.close()


if __name__ == "__main__":
    main()
