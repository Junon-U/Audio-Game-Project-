#!/usr/bin/env python3
"""Merge Gate Defence sessions and produce first-pass tables and figures.

Usage:
    python tools/analyze.py                 # reads data/, writes analysis/
    python tools/analyze.py --data DIR --out DIR --include-autotest

Outputs (in analysis/):
  trials_all.csv            every robot from every live/replay session, with derived
                            columns, ready for mixed models (R lme4 / Python)
  summary_by_level.csv      per participant x mode x level: first-shot accuracy, kills,
                            sound-following, tracker-following on conflict trials,
                            anticipatory aim/shots, valid vs invalid cost, ratings
  summary_by_condition.csv  by audio condition x visibility x level
  ratings.csv               level-end ratings next to the actual reliability
  questionnaire.csv         questionnaire answers, one row per participant x mode
  localization.csv          localization accuracy per participant and direction
  sound_following_<mode>.png  running sound-following rate across trials, by condition

Derived columns in trials_all.csv:
  r_hat_check         proposal estimate, recomputed (alpha0 = beta0 = 1, silent excluded)
  r_hat_recent        estimate from the last --window audio trials only (a faster-
                      adapting alternative for the model comparison)
  conflict            1 if the bang and the tracker pointed to different gates
  anticipatory        1 if the first shot came before the robot appeared
  half                first / second half of the level
  clean               1 if no other robot was on screen at this robot's bang or appearance

The key behavioural measures:
  choice_gate / correct     gate of the first shot, and whether it was the robot's gate
  followed_sound            first shot at the gate the bang came from (audio trials)
  first_aim_gate (live)     direction the aim first moved after the bang
  aim_gate_at_emerge (live) where the aim pointed when the robot appeared (-1 = not yet aimed)
  kill_after_emerge_ms      time from the robot appearing to its destruction
Gaze measures need the eye-tracking stream: align it to the cue_on and robot_on
markers in the XDF file recorded by LabRecorder and use the AOI positions in
trials_all.csv (correct_x/y, cue_x/y, sensor_x/y) or in *_session.json. The
bang leads the robot by 50 to 100 ms, so compare first-saccade latency and
direction after cue_on and after robot_on across valid, invalid and silent trials.
"""
import argparse
import glob
import os
import sys

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load(pattern, include_autotest):
    frames = []
    for f in sorted(glob.glob(pattern)):
        name = os.path.basename(f)
        if name.startswith("AUTOTEST") and not include_autotest:
            continue
        d = pd.read_csv(f)
        d["session_file"] = name
        frames.append(d)
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def add_estimates(t, window):
    out = []
    for _, s in t.groupby("session_file", sort=False):
        s = s.sort_values("trial_global").copy()
        na = nv = 0
        recent = []
        r_hat, r_recent = [], []
        for _, row in s.iterrows():
            if row["epoch"] > 0:
                r_hat.append((1 + nv) / (2 + na))
                r_recent.append((1 + sum(recent[-window:])) / (2 + len(recent[-window:])))
                if row["cue_gate"] >= 0:
                    v = int(row["cue_gate"] == row["correct_gate"])
                    na += 1
                    nv += v
                    recent.append(v)
            else:
                r_hat.append(np.nan)
                r_recent.append(np.nan)
        s["r_hat_check"] = r_hat
        s["r_hat_recent"] = r_recent
        out.append(s)
    return pd.concat(out)


def mean_or_nan(x):
    x = pd.to_numeric(x, errors="coerce").dropna()
    return x.mean() if len(x) else np.nan


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", default=os.path.join(ROOT, "data"))
    ap.add_argument("--out", default=os.path.join(ROOT, "analysis"))
    ap.add_argument("--window", type=int, default=10, help="audio trials in r_hat_recent")
    ap.add_argument("--include-autotest", action="store_true")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    t = load(os.path.join(args.data, "*_trials.csv"), args.include_autotest)
    if t.empty:
        sys.exit("No *_trials.csv files found in %s" % args.data)
    loc = t[t["block"] == "localization"].copy()
    t = t[t["block"] != "localization"].copy()

    # ---- derived columns
    t = add_estimates(t, args.window)
    if "r_hat" in t and t["r_hat"].notna().any():
        diff = (t["r_hat"] - t["r_hat_check"]).abs().max()
        if diff > 1e-3:
            print("Warning: logged r_hat differs from recomputation by up to %.4f" % diff)
    t["conflict"] = ((t["cue_gate"] >= 0) & (t["cue_gate"] != t["sensor_gate"])).astype(int)
    t["anticipatory"] = pd.to_numeric(t["first_shot_before_emerge"], errors="coerce")
    # Robots come at a fixed beat and can overlap. A "clean" trial had no other
    # robot on screen at its bang or when it appeared, so its first aim and
    # first shot can only be a response to its own bang.
    if "others_alive_at_cue" in t:
        t["clean"] = ((pd.to_numeric(t["others_alive_at_cue"], errors="coerce").fillna(0) == 0)
                      & (pd.to_numeric(t["others_alive_at_emerge"], errors="coerce").fillna(0) == 0)).astype(int)
    else:
        t["clean"] = 1
    n_level = t.groupby(["session_file", "block"])["trial_in_block"].transform("max")
    t["half"] = np.where(t["trial_in_block"] <= n_level / 2, "first", "second")
    t.to_csv(os.path.join(args.out, "trials_all.csv"), index=False)

    main_t = t[t["epoch"] > 0]
    audio = main_t[main_t["cue_gate"] >= 0]

    # ---- per level
    rows = []
    for (pid, mode, ep), g in main_t.groupby(["pid", "mode", "epoch"]):
        shot = g[g["timeout"] == 0]
        a = shot[shot["cue_gate"] >= 0]
        conf = shot[shot["conflict"] == 1]
        valid = g[g["audio_cond"] == "valid"]
        invalid = g[g["audio_cond"] == "invalid"]
        rows.append({
            "pid": pid, "mode": mode, "level": ep,
            "reliability": g["reliability"].iloc[0],
            "reliability_condition": g["reliability_condition"].iloc[0],
            "n_robots": len(g),
            "first_shot_accuracy": shot["correct"].mean(),
            "shot_accuracy": g["killed"].sum() / g["n_shots"].sum() if g["n_shots"].sum() else np.nan,
            "kill_rate": g["killed"].mean(),
            "breaches": int(g["breach"].sum()),
            "no_shot": int(g["timeout"].sum()),
            "clean_trials": int(g["clean"].sum()),
            "follow_sound": mean_or_nan(a["followed_sound"]),
            "follow_sound_clean": mean_or_nan(a.loc[a["clean"] == 1, "followed_sound"]),
            "follow_sound_first_half": mean_or_nan(a.loc[a["half"] == "first", "followed_sound"]),
            "follow_sound_second_half": mean_or_nan(a.loc[a["half"] == "second", "followed_sound"]),
            "follow_tracker_on_conflict": mean_or_nan(conf["followed_sensor"]) if len(conf) else np.nan,
            "anticipatory_shots": mean_or_nan(shot["anticipatory"]),
            "first_aim_to_sound": mean_or_nan(g["first_aim_to_sound"]),
            "kill_after_emerge_valid_ms": mean_or_nan(valid["kill_after_emerge_ms"]),
            "kill_after_emerge_invalid_ms": mean_or_nan(invalid["kill_after_emerge_ms"]),
            "kill_after_emerge_silent_ms": mean_or_nan(g.loc[g["audio_cond"] == "silent", "kill_after_emerge_ms"]),
            "invalid_cue_cost_ms": (mean_or_nan(invalid["kill_after_emerge_ms"]) - mean_or_nan(valid["kill_after_emerge_ms"]))
            if len(invalid) else np.nan,
            "final_score": g["score"].iloc[-1],
        })
    by_level = pd.DataFrame(rows)

    # ---- ratings
    ratings = load(os.path.join(args.data, "*_ratings.csv"), args.include_autotest)
    if not ratings.empty:
        wide = ratings.pivot_table(index=["pid", "mode", "epoch"], columns="item", values="value", aggfunc="last").reset_index()
        wide = wide.rename(columns={"epoch": "level"})
        by_level = by_level.merge(wide, on=["pid", "mode", "level"], how="left")
        ratings.to_csv(os.path.join(args.out, "ratings.csv"), index=False)
    by_level.round(4).to_csv(os.path.join(args.out, "summary_by_level.csv"), index=False)

    # ---- by condition
    tmp = main_t.copy()
    for c in ["followed_sound", "followed_sensor", "kill_after_emerge_ms", "anticipatory"]:
        tmp[c] = pd.to_numeric(tmp[c], errors="coerce")
    cond = (tmp.groupby(["epoch", "audio_cond", "visibility"])
            .agg(n=("correct", "size"), first_shot_accuracy=("correct", "mean"), kill_rate=("killed", "mean"),
                 follow_sound=("followed_sound", "mean"), follow_tracker=("followed_sensor", "mean"),
                 anticipatory=("anticipatory", "mean"), kill_after_emerge_ms=("kill_after_emerge_ms", "mean"))
            .reset_index().rename(columns={"epoch": "level"}))
    cond.round(4).to_csv(os.path.join(args.out, "summary_by_condition.csv"), index=False)

    # ---- questionnaire
    q = load(os.path.join(args.data, "*_questionnaire.csv"), args.include_autotest)
    if not q.empty:
        q.pivot_table(index=["pid", "mode"], columns="item", values="response", aggfunc="last").reset_index() \
            .to_csv(os.path.join(args.out, "questionnaire.csv"), index=False)

    # ---- localization
    if not loc.empty:
        names = {0: "left", 1: "ahead", 2: "right"}
        l = loc.assign(direction=loc["cue_gate"].map(names)).groupby(["pid", "direction"])["correct"].agg(["mean", "size"]).reset_index()
        l.rename(columns={"mean": "accuracy", "size": "n"}).to_csv(os.path.join(args.out, "localization.csv"), index=False)

    # ---- figures: running sound-following by reliability condition, one per mode
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        aud = audio[audio["timeout"] == 0].copy()
        aud["followed_sound"] = pd.to_numeric(aud["followed_sound"], errors="coerce")
        for mode_name, am in aud.groupby("mode"):
            a = am.copy()
            a["k"] = a.groupby("session_file").cumcount()
            a["follow_run"] = a.groupby("session_file")["followed_sound"].transform(lambda x: x.rolling(10, min_periods=3).mean())
            conds = sorted(a["reliability_condition"].unique())
            fig, axes = plt.subplots(len(conds), 1, figsize=(9, 2.2 * len(conds)), sharex=True, squeeze=False)
            for ax, c in zip(axes[:, 0], conds):
                sub = a[a["reliability_condition"] == c]
                for _, s_ in sub.groupby("session_file"):
                    ax.plot(s_["k"], s_["follow_run"], color="0.6", lw=0.8)
                mean = sub.groupby("k")["follow_run"].mean()
                ax.plot(mean.index, mean.values, color="black", lw=2)
                first = sub[sub["session_file"] == sub["session_file"].iloc[0]]
                for ep, e in first.groupby("epoch"):
                    ax.axvline(e["k"].min(), color="0.85", lw=1)
                    ax.hlines(e["reliability"].iloc[0], e["k"].min(), e["k"].max(), colors="tab:orange", lw=1.5)
                r = first.groupby("epoch")["reliability"].first().tolist()
                n = sub["pid"].nunique()
                ax.set_title("Condition %d: reliability %s (n = %d)" % (c, " / ".join("%d%%" % round(x * 100) for x in r), n),
                             fontsize=9, loc="left")
                ax.set_ylim(0, 1.05)
                ax.set_ylabel("first shot at bang")
            axes[-1, 0].set_xlabel("audio trial (shot fired)")
            fig.suptitle("%s: running proportion of first shots at the bang's gate (10-trial window); "
                         "grey = participants, black = mean, orange = actual reliability" % mode_name.capitalize(), fontsize=9)
            fig.tight_layout()
            fig.savefig(os.path.join(args.out, "sound_following_%s.png" % mode_name), dpi=130)
            plt.close(fig)
    except ImportError:
        print("matplotlib not installed; skipping the figures")

    n_p = main_t["pid"].nunique()
    print("Merged %d trials from %d participant(s), %d session(s). Output: %s" % (
        len(t), n_p, t["session_file"].nunique(), args.out))


if __name__ == "__main__":
    main()
