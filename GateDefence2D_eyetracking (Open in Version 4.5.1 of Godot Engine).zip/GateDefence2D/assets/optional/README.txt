Unzip the optional Kenney packs into this folder (see README).
